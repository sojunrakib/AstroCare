"use strict";
/* ---------------- utilities ---------------- */
const $ = s => document.querySelector(s);
const el = (t, a = {}, h = '') => { const e = document.createElement(t); for (const k in a) { if (k === 'class') e.className = a[k]; else if (k.startsWith('on')) e[k] = a[k]; else e.setAttribute(k, a[k]); } if (h != null) e.innerHTML = h; return e; };
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const fmt = (v, d = 1) => v == null || isNaN(v) ? '–' : Number(v).toFixed(d);
const pb = t => `<span class="pb ${t}">${String(t).replace('_', ' ')}</span>`;
const chip = (cls, txt) => `<span class="chip ${cls}"><i></i>${txt}</span>`;
const css = v => getComputedStyle(document.documentElement).getPropertyValue(v).trim();
const median = a => { const s = [...a].sort((x, y) => x - y), m = s.length >> 1; return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2; };

/* ---------------- API ---------------- */
const API = {
  async get(path, q = {}) {
    const qs = new URLSearchParams(Object.entries(q).filter(([, v]) => v != null)).toString();
    const r = await fetch('/api' + path + (qs ? '?' + qs : ''));
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(j.detail || r.statusText);
    return j;
  },
  async post(path, body) {
    const r = await fetch('/api' + path, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(j.detail || r.statusText);
    return j;
  }
};
const showErr = (host, e) => { if (host) host.innerHTML = `<div class="err">Could not load from the backend: ${esc(e.message)}. Is <code>python run.py</code> running?</div>`; console.error(e); };

/* ---------------- state + navigation ---------------- */
const VIEWS = [['home', 'Home', null], ['console', 'Console', 'mission'], ['radiation', 'Radiation', 'mission'], ['blood', 'Blood', 'mission'],
  ['microbiome', 'Microbiome', 'i4'], ['immune', 'Immune', 'i4'], ['telomere', 'Telomere', 'i4'], ['recovery', 'Recovery', 'i4'],
  ['bodymind', 'Body & Mind', 'mission'], ['actions', 'Actions', 'any'], ['evidence', 'Evidence', 'any'], ['about', 'About', null]];
const S = { view: 'home', persona: 'SIM-A', i4: 'C001', day: 21, lastKind: 'mission', playing: false, timer: null, sig: 'hrv', selFlag: null,
  shield: 'habitat', meta: null, seen: new Set(), stormKey: null };
const RENDER = {}; // view id -> render function (registered by views/*.js)

function crewKind(v = S.view) {
  const k = (VIEWS.find(x => x[0] === v) || [])[2];
  if (k === 'any') return S.lastKind;
  return k || S.lastKind;
}
const subject = () => crewKind() === 'i4' ? S.i4 : S.persona;

function fillCrewSelect() {
  const who = $('#who'), kind = crewKind(), m = S.meta;
  if (!m) return;
  const list = kind === 'i4' ? m.i4_crew.map(c => [c.id, `${c.id} · Inspiration4`]) : m.personas.map(p => [p.id, `${p.id} · ${p.role}`]);
  const want = kind === 'i4' ? S.i4 : S.persona;
  if (who.dataset.kind !== kind) {
    who.innerHTML = ''; const og = el('optgroup', { label: kind === 'i4' ? 'Inspiration4 crew' : 'Mission crew' });
    list.forEach(([v, t]) => og.appendChild(el('option', { value: v }, t))); who.appendChild(og); who.dataset.kind = kind;
  }
  who.value = want;
  document.querySelectorAll('.kindsw').forEach(sw => {
    sw.innerHTML = `<button data-k="mission" class="${kind === 'mission' ? 'on' : ''}">Mission crew · SIM-A–D</button><button data-k="i4" class="${kind === 'i4' ? 'on' : ''}">Inspiration4 crew · C001–C004</button>`;
    sw.querySelectorAll('button').forEach(b => b.onclick = () => { S.lastKind = b.dataset.k; fillCrewSelect(); render(); });
  });
}

function go(v) {
  if (!VIEWS.some(x => x[0] === v)) v = 'home';
  S.view = v;
  const k = (VIEWS.find(x => x[0] === v) || [])[2];
  if (k === 'mission' || k === 'i4') S.lastKind = k;
  document.querySelectorAll('.view').forEach(x => x.classList.toggle('on', x.id === v));
  document.querySelectorAll('#tabs button').forEach(b => b.classList.toggle('on', b.dataset.v === v));
  if (location.hash.slice(1) !== v) history.replaceState(null, '', '#' + v);
  window.scrollTo({ top: 0 });
  fillCrewSelect();
  render();
  if (window.threeRun) threeRun(v === 'home');
}

function render() { const f = RENDER[S.view]; if (f) Promise.resolve(f()).catch(e => console.error(e)); }

function toast(h) { const t = $('#toast'); t.innerHTML = h; t.style.display = 'block'; clearTimeout(toast.t); toast.t = setTimeout(() => t.style.display = 'none', 4200); }

let EVID = [];
const evLink = id => {
  if (!id) return '<span class="muted">rule only</span>';
  return EVID.some(x => x.id === id) ? `<a href="#evidence" onclick="S.hlEv='${id}';go('evidence');return false;">${id}</a>` : `<span class="muted">${esc(id)}</span>`;
};
const evById = id => EVID.find(x => x.id === id);
