"use strict";
/* 3D hero scene (from the prototype). Uses Three.js r149 from js/vendor. */
function mulberry32(a){return function(){a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};}
(function three(){
  if(typeof THREE==='undefined'){return;}
  const canvas=$('#three');let renderer;try{renderer=new THREE.WebGLRenderer({canvas,antialias:true,alpha:false});}catch(e){$('#hero').style.background='radial-gradient(circle at 70% 50%,#13254d,#050814 60%)';return;}
  renderer.setPixelRatio(Math.min(2,window.devicePixelRatio||1));renderer.outputEncoding=THREE.sRGBEncoding;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.1;
  const scene=new THREE.Scene();scene.background=new THREE.Color(0x03050d);
  const cam=new THREE.PerspectiveCamera(42,1,0.1,2000);cam.position.set(0,1.2,16);
  scene.add(new THREE.AmbientLight(0x4a5a80,0.55));
  const sun=new THREE.DirectionalLight(0xfff3e0,2.2);sun.position.set(-12,6,8);scene.add(sun);
  const rim=new THREE.DirectionalLight(0x6fb1ff,1.2);rim.position.set(10,-2,-8);scene.add(rim);
  // stars
  const sg=new THREE.BufferGeometry();const N=4500;const pos=new Float32Array(N*3),col=new Float32Array(N*3);const rr=mulberry32(9);
  for(let i=0;i<N;i++){const u=rr()*2-1,t=rr()*Math.PI*2,R=300+rr()*500;const s=Math.sqrt(1-u*u);pos[i*3]=R*s*Math.cos(t);pos[i*3+1]=R*u;pos[i*3+2]=R*s*Math.sin(t);const w=0.6+rr()*0.4;const tint=rr();col[i*3]=w*(tint>0.8?0.8:1);col[i*3+1]=w*0.95;col[i*3+2]=w*(tint<0.2?0.8:1);}
  sg.setAttribute('position',new THREE.BufferAttribute(pos,3));sg.setAttribute('color',new THREE.BufferAttribute(col,3));
  const stars=new THREE.Points(sg,new THREE.PointsMaterial({size:1.3,sizeAttenuation:false,vertexColors:true,transparent:true,opacity:.9}));scene.add(stars);
  // Earth with procedural texture
  function noiseTex(w,h,fn){const c=document.createElement('canvas');c.width=w;c.height=h;const g=c.getContext('2d');const img=g.createImageData(w,h);for(let y=0;y<h;y++)for(let x=0;x<w;x++){const [r,gg,b,a]=fn(x/w,y/h);const i=(y*w+x)*4;img.data[i]=r;img.data[i+1]=gg;img.data[i+2]=b;img.data[i+3]=a;}g.putImageData(img,0,0);const t=new THREE.CanvasTexture(c);t.encoding=THREE.sRGBEncoding;return t;}
  const perm=[];const pr=mulberry32(42);for(let i=0;i<512;i++)perm[i]=Math.floor(pr()*256);
  const hash=(x,y,z)=>perm[(perm[(perm[x&255]+y)&255]+z)&255]/255;
  const lerp=(a,b,t)=>a+(b-a)*t,sm=t=>t*t*(3-2*t);
  function vnoise(x,y,z){const X=Math.floor(x),Y=Math.floor(y),Z=Math.floor(z);const fx=sm(x-X),fy=sm(y-Y),fz=sm(z-Z);const c=(i,j,k)=>hash(X+i,Y+j,Z+k);return lerp(lerp(lerp(c(0,0,0),c(1,0,0),fx),lerp(c(0,1,0),c(1,1,0),fx),fy),lerp(lerp(c(0,0,1),c(1,0,1),fx),lerp(c(0,1,1),c(1,1,1),fx),fy),fz);}
  const fbm=(x,y,z)=>{let s=0,a=0.5,f=1;for(let o=0;o<5;o++){s+=a*vnoise(x*f,y*f,z*f);a*=0.5;f*=2;}return s;};
  const sph=(u,v)=>{const th=u*Math.PI*2,ph=v*Math.PI;return [Math.sin(ph)*Math.cos(th),Math.cos(ph),Math.sin(ph)*Math.sin(th)];};
  const earthTex=noiseTex(512,256,(u,v)=>{const [x,y,z]=sph(u,v);const n=fbm(x*2.2+5,y*2.2+5,z*2.2+5);const lat=Math.abs(v-0.5)*2;if(lat>0.86)return [235,242,250,255];if(n>0.53){const k=(n-0.53)*4;return [Math.round(60+k*120),Math.round(110+k*60-lat*20),Math.round(55+k*30),255];}const d=Math.max(0,0.53-n)*3;return [Math.round(12+20*(1-d)),Math.round(45+50*(1-d)),Math.round(110+60*(1-d)),255];});
  const cloudTex=noiseTex(512,256,(u,v)=>{const [x,y,z]=sph(u,v);const n=fbm(x*3+11,y*3+11,z*3+11);const a=Math.max(0,(n-0.52)*3.2);return [255,255,255,Math.round(Math.min(1,a)*210)];});
  const earth=new THREE.Group();earth.position.set(7.5,-4.2,-9);scene.add(earth);
  const eMesh=new THREE.Mesh(new THREE.SphereGeometry(6,96,64),new THREE.MeshStandardMaterial({map:earthTex,roughness:0.85,metalness:0.0}));earth.add(eMesh);
  const cMesh=new THREE.Mesh(new THREE.SphereGeometry(6.08,96,64),new THREE.MeshStandardMaterial({map:cloudTex,transparent:true,depthWrite:false}));earth.add(cMesh);
  const atmo=new THREE.Mesh(new THREE.SphereGeometry(6.6,64,48),new THREE.ShaderMaterial({transparent:true,side:THREE.BackSide,blending:THREE.AdditiveBlending,depthWrite:false,uniforms:{},vertexShader:'varying vec3 vN;void main(){vN=normalize(normalMatrix*normal);gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0);}',fragmentShader:'varying vec3 vN;void main(){float i=pow(0.72-dot(vN,vec3(0.0,0.0,1.0)),2.6);gl_FragColor=vec4(0.35,0.62,1.0,1.0)*i*1.4;}'}));earth.add(atmo);
  earth.rotation.z=0.35;
  // moon
  const moonTex=noiseTex(256,128,(u,v)=>{const [x,y,z]=sph(u,v);const n=fbm(x*4+2,y*4+2,z*4+2);const g=Math.round(120+n*110);return [g,g,g-4,255];});
  const moon=new THREE.Mesh(new THREE.SphereGeometry(0.9,48,32),new THREE.MeshStandardMaterial({map:moonTex,roughness:1}));moon.position.set(13,9,-34);scene.add(moon);
  // astronaut
  const astro=new THREE.Group();scene.add(astro);astro.position.set(2.4,0.6,2);
  const white=new THREE.MeshStandardMaterial({color:0xeef1f6,roughness:0.55,metalness:0.05});
  const grey=new THREE.MeshStandardMaterial({color:0x9aa3b5,roughness:0.6});
  const dark=new THREE.MeshStandardMaterial({color:0x2a3142,roughness:0.5});
  const visorM=new THREE.MeshStandardMaterial({color:0xd9a441,metalness:0.55,roughness:0.18,emissive:0x5a3a0c,emissiveIntensity:0.9});
  const helmet=new THREE.Mesh(new THREE.SphereGeometry(0.62,48,32),white);helmet.position.y=1.28;astro.add(helmet);
  const visor=new THREE.Mesh(new THREE.SphereGeometry(0.64,48,32,Math.PI*0.14,Math.PI*0.72,Math.PI*0.28,Math.PI*0.42),visorM);visor.position.set(0,1.28,0.0);astro.add(visor);
  const reflection=new THREE.Mesh(new THREE.SphereGeometry(0.645,32,16,Math.PI*0.5+0.15,0.35,Math.PI*0.32,0.18),new THREE.MeshBasicMaterial({color:0xffffff,transparent:true,opacity:.35}));reflection.position.copy(visor.position);astro.add(reflection);
  const ring=new THREE.Mesh(new THREE.TorusGeometry(0.42,0.08,16,40),grey);ring.rotation.x=Math.PI/2;ring.position.y=0.78;astro.add(ring);
  const torso=new THREE.Mesh(new THREE.CapsuleGeometry(0.55,0.7,8,24),white);torso.position.y=0.15;torso.scale.set(1,1,0.8);astro.add(torso);
  const pack=new THREE.Mesh(new THREE.BoxGeometry(1.0,1.15,0.45),white);pack.position.set(0,0.28,-0.55);astro.add(pack);
  const pack2=new THREE.Mesh(new THREE.BoxGeometry(0.8,0.3,0.1),grey);pack2.position.set(0,0.55,-0.79);astro.add(pack2);
  const panel=new THREE.Mesh(new THREE.BoxGeometry(0.46,0.3,0.1),dark);panel.position.set(0,0.28,0.43);astro.add(panel);
  const lights=[];[[-0.13,0x3cff8a],[0,0x6fb1ff],[0.13,0xfab219]].forEach(([x,c])=>{const m=new THREE.Mesh(new THREE.SphereGeometry(0.035,12,8),new THREE.MeshBasicMaterial({color:c}));m.position.set(x,0.32,0.49);astro.add(m);lights.push(m);});
  const ecg=new THREE.Mesh(new THREE.PlaneGeometry(0.36,0.08),new THREE.MeshBasicMaterial({color:0x3cff8a,transparent:true,opacity:.8}));ecg.position.set(0,0.2,0.485);astro.add(ecg);
  const limb=(r,l,x,y,rz,rx)=>{const g=new THREE.Group();const m=new THREE.Mesh(new THREE.CapsuleGeometry(r,l,6,16),white);m.position.y=-l/2;g.add(m);const cuff=new THREE.Mesh(new THREE.TorusGeometry(r*0.95,0.035,8,20),grey);cuff.rotation.x=Math.PI/2;cuff.position.y=-l*0.55;g.add(cuff);const end=new THREE.Mesh(new THREE.SphereGeometry(r*1.05,16,12),grey);end.position.y=-l-r*0.4;g.add(end);g.position.set(x,y,0);g.rotation.z=rz;g.rotation.x=rx||0;astro.add(g);return g;};
  const armL=limb(0.19,0.75,-0.72,0.55,-0.7,0.2),armR=limb(0.19,0.75,0.72,0.55,0.9,-0.3);
  const legL=limb(0.23,0.85,-0.28,-0.5,0.08,0.25),legR=limb(0.23,0.85,0.28,-0.5,-0.14,-0.15);
  astro.rotation.set(0.15,-0.55,0.12);astro.scale.setScalar(1.35);
  // tether
  const tetherPts=[];for(let i=0;i<=40;i++){const t=i/40;tetherPts.push(new THREE.Vector3(2.4-0.3-t*9,0.9+Math.sin(t*Math.PI)*-1.4-t*1.5,1.6-t*6));}
  const tether=new THREE.Line(new THREE.BufferGeometry().setFromPoints(tetherPts),new THREE.LineBasicMaterial({color:0xbfc8da,transparent:true,opacity:.45}));scene.add(tether);
  // health scan rings
  const scanMat=new THREE.MeshBasicMaterial({color:0x6fb1ff,transparent:true,opacity:.5,side:THREE.DoubleSide});
  const scan=new THREE.Mesh(new THREE.RingGeometry(1.35,1.38,96),scanMat);scan.rotation.x=Math.PI/2;astro.add(scan);
  const orbit=new THREE.Mesh(new THREE.TorusGeometry(2.1,0.006,8,160),new THREE.MeshBasicMaterial({color:0x9085e9,transparent:true,opacity:.55}));orbit.rotation.x=Math.PI/2.4;astro.add(orbit);
  const dataDots=[];for(let i=0;i<4;i++){const d=new THREE.Mesh(new THREE.SphereGeometry(0.05,12,8),new THREE.MeshBasicMaterial({color:[0x5fd3a6,0xf2c75c,0x8dbdf5,0xb9b1ff][i]}));astro.add(d);dataDots.push(d);}
  // particles (solar wind)
  const pg=new THREE.BufferGeometry();const PN=600;const pp=new Float32Array(PN*3);for(let i=0;i<PN;i++){pp[i*3]=-40+rr()*80;pp[i*3+1]=-15+rr()*30;pp[i*3+2]=-30+rr()*30;}pg.setAttribute('position',new THREE.BufferAttribute(pp,3));
  const parts=new THREE.Points(pg,new THREE.PointsMaterial({color:0xffc98a,size:0.06,transparent:true,opacity:.55}));scene.add(parts);
  // HUD lines
  const huds=[['hud1',()=>dataDots[0]],['hud2',()=>dataDots[1]],['hud3',()=>dataDots[2]],['hud4',()=>dataDots[3]]];const svg=$('#hudsvg');
  let mx=0,my=0;window.addEventListener('mousemove',e=>{mx=e.clientX/window.innerWidth-0.5;my=e.clientY/window.innerHeight-0.5;});
  function resize(){const h=$('#hero');const w=h.clientWidth,hh=h.clientHeight;renderer.setSize(w,hh,false);cam.aspect=w/hh;cam.updateProjectionMatrix();const narrow=w<760;astro.position.x=narrow?0.6:2.6;astro.position.y=narrow?2.4:0.6;astro.scale.setScalar(narrow?1.05:1.35);earth.position.set(narrow?4.5:7.5,narrow?-1.5:-4.2,-9);}
  window.addEventListener('resize',resize);resize();
  let running=true,raf=0;const clock=new THREE.Clock();const v=new THREE.Vector3();
  let lastW=0;
  function loop(){raf=requestAnimationFrame(loop);const hero0=$('#hero');if(!hero0.clientWidth)return;if(hero0.clientWidth!==lastW||!isFinite(cam.aspect)){resize();lastW=hero0.clientWidth;}const t=clock.getElapsedTime();
    eMesh.rotation.y=t*0.03;cMesh.rotation.y=t*0.038;moon.position.x=13+Math.sin(t*0.05)*1.5;stars.rotation.y=t*0.003;
    astro.position.y+=Math.sin(t*0.8)*0.0025;astro.rotation.y=-0.55+Math.sin(t*0.25)*0.25+mx*0.3;astro.rotation.x=0.15+Math.sin(t*0.35)*0.06+my*0.12;astro.rotation.z=0.12+Math.sin(t*0.3)*0.05;
    armL.rotation.z=-0.7+Math.sin(t*0.9)*0.08;armR.rotation.z=0.9+Math.sin(t*0.7+1)*0.1;legL.rotation.x=0.25+Math.sin(t*0.6)*0.08;legR.rotation.x=-0.15+Math.sin(t*0.6+2)*0.08;
    const beat=(t*1.15)%1;lights[0].material.color.setHex(beat<0.12?0x9dffc3:0x2fd97a);ecg.material.opacity=0.4+0.6*Math.max(0,1-beat*4);
    lights[2].visible=Math.sin(t*2)>0;
    const sc=(t*0.45)%1;scan.position.y=-1.1+sc*2.9;scan.material.opacity=0.55*Math.sin(sc*Math.PI);scan.scale.setScalar(0.85+0.25*Math.sin(sc*Math.PI));
    orbit.rotation.z=t*0.15;dataDots.forEach((d,i)=>{const a=t*0.35+i*Math.PI/2;d.position.set(Math.cos(a)*2.1,Math.sin(a)*2.1*Math.cos(Math.PI/2.4)*0+0.4+Math.sin(a+i)*0.5,Math.sin(a)*2.1*0.45);});
    const p=pg.attributes.position;for(let i=0;i<PN;i++){p.array[i*3]+=0.05+(i%7)*0.004;if(p.array[i*3]>40)p.array[i*3]=-40;}p.needsUpdate=true;
    cam.position.x+=(mx*1.6-cam.position.x)*0.03;cam.position.y+=(1.2-my*1.0-cam.position.y)*0.03;cam.lookAt(0.5,0.2,0);
    renderer.render(scene,cam);
    // HUD
    const hero=$('#hero');const W=hero.clientWidth,H=hero.clientHeight;let lines='';astro.getWorldPosition(v);v.project(cam);const ax=(v.x*0.5+0.5)*W,ay=(-v.y*0.5+0.5)*H;const off=[[190,-200],[240,-70],[240,50],[190,170]];
    huds.forEach(([id,fn],i)=>{fn().getWorldPosition(v);v.project(cam);const x=(v.x*0.5+0.5)*W,y=(-v.y*0.5+0.5)*H;const e=document.getElementById(id);const narrow=W<800;const ox=narrow?off[i][0]*0.45:off[i][0],oy=off[i][1];const bx=Math.max(8,Math.min(W-175,ax+ox)),by=Math.max(8,Math.min(H-60,ay+oy));e.style.left=bx+'px';e.style.top=by+'px';e.style.opacity=W<560&&i>1?0:1;lines+=`<line x1="${x}" y1="${y}" x2="${bx}" y2="${by+18}" stroke="rgba(111,177,255,.45)" stroke-width="1"/><circle cx="${x}" cy="${y}" r="3" fill="#9cc6ff"/>`;});svg.setAttribute('viewBox',`0 0 ${W} ${H}`);svg.innerHTML=lines;}
  window.threeRun=on=>{if(on&&!running){running=true;clock.start();loop();}else if(!on&&running){running=false;cancelAnimationFrame(raf);}};
  loop();
})();
