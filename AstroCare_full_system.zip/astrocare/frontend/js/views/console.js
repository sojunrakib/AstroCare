"use strict";
/* M9 Crew Health Console */
let V = null, liveTimer = null, liveBuf = [], RULES9 = null;
const SIGS = { hrv: 'HRV (RMSSD)', hr: 'Resting heart rate', rr: 'Respiratory rate', spo2: 'SpO2' };

RENDER.console = async function () {
  const slider = $('#dayslider');
  slider.min = S.meta.mission_days[0]; slider.max = S.meta.mission_days.at(-1);
  slider.value = S.day; $('#daybadge').textContent = `MISSION DAY ${S.day}`;
  try { V = await API.get('/vitals/' + S.persona, { day: S.day }); } catch (e) { return showErr($('#vitalhead'), e); }
  if (S.view !== 'console') return;
  drawConsole();
  if (!RULES9) { RULES9 = await API.get('/vitals/rules'); drawRules(); }
  startLive();
};

function drawConsole() {
  const v = V, today = v.today;
  $('#daybadge').textContent = `MISSION DAY ${v.day} · ${v.date}`;
  const vh = $('#vitalhead'); vh.innerHTML = '';
  ['hrv', 'hr', 'rr', 'spo2'].forEach(k => {
    const t = today[k]; const fl = t.flag;
    const zt = t.z != null ? `z ${t.z > 0 ? '+' : ''}${fmt(t.z, 1)}` : (t.quality === 'insufficient_baseline' ? 'building baseline' : 'no z');
    vh.appendChild(el('div', { class: 'vital' + (fl && t.alert_enabled ? ' flag' : '') },
      `<div class="lab"><span>${t.name}</span><span>${zt}</span></div><div class="val">${t.value == null ? '—' : fmt(t.value, 1)} <small>${t.unit}</small></div><div class="small muted">baseline ${t.median != null ? fmt(t.median, 1) : '–'} ${t.unit}${fl && !t.alert_enabled ? ' · flag shown, no alert' : ''}</div>`));
  });
  const co2 = v.cabin_co2.find(x => x.day === v.day);
  vh.appendChild(el('div', { class: 'vital' }, `<div class="lab"><span>Cabin CO2</span><span>context</span></div><div class="val">${co2 && co2.co2 != null ? fmt(co2.co2, 1) : '—'} <small>mmHg</small></div><div class="small muted">${v.day > 0 ? 'environment telemetry' : 'on Earth'}</div>`));

  // daily chart
  const sig = S.sig, ser = v.series[sig], days = ser.map(r => r.day);
  const alertOn = sig !== 'spo2';
  lineChart($('#cvDaily'), {
    x: days.map(d => 'D' + d), xname: 'Mission', series: [{ name: SIGS[sig], y: ser.map(r => r.value), color: css('--blue'), dots: true,
      flags: ser.map(r => r.flag ? (alertOn ? true : 'muted') : false), unit: v.measures[sig].unit, dec: 1 }],
    band: ser.map(r => r.lo != null ? [r.lo, r.hi] : null), now: days.indexOf(v.day), xticks: 10,
    tipExtra: i => { const r = ser[i]; return r.value != null && r.median != null ? `<div class="muted">median ${fmt(r.median, 2)} · z ${fmt(r.z, 2)} · n ${r.n}${r.flag ? ' · <span style="color:#ec835a">flagged</span>' : ''}</div>` : `<div class="muted">${r.quality.replace('_', ' ')}</div>`; }
  });
  lineChart($('#cvCO2'), { x: v.cabin_co2.map(r => 'D' + r.day), series: [{ name: 'Cabin CO2', y: v.cabin_co2.map(r => r.co2), color: '#c3c9d8', unit: 'mmHg', width: 1.5 }], now: days.indexOf(v.day), xticks: 8 });

  // feed
  const feed = $('#feed'); feed.innerHTML = '';
  const evs = [...v.flags].reverse();
  $('#flagcount').textContent = `${v.active_flags.length} today · ${v.flags.length} so far`;
  if (v.quality.length) v.quality.forEach(q => feed.appendChild(el('div', { class: 'flag q' }, `<div class="row"><span class="t">${q.rule_id} · Not enough data</span><span class="sp"></span>${chip('st-none', 'Paused')}</div><div class="d">${q.measure}: ${q.why}</div>`)));
  if (!evs.length && !v.quality.length) feed.innerHTML = '<div class="muted small">No flags yet. Press ▶ Play mission or ⚡ Jump to HRV event.</div>';
  evs.forEach(f => {
    const key = f.crew_id + f.measure + f.mission_day; const isNew = !S.seen.has(key); S.seen.add(key);
    const today = f.mission_day === v.day;
    const d = el('div', { class: 'flag' + (f.alert_enabled ? '' : ' noalert') + (today ? '' : ' cleared') + (isNew && S.playing ? ' newflag' : ''), tabindex: 0 },
      `<div class="row"><span class="t">${f.measure} · ${f.status.split('(')[1].replace(')', '')}</span><span class="sp"></span>${f.alert_enabled ? chip(today ? 'st-serious' : 'st-none', today ? 'Alert · today' : 'Day ' + f.mission_day) : chip('st-none', 'No alert')}</div><div class="d">Day ${f.mission_day} · ${f.value} · ${f.rule_id}</div>`);
    d.onclick = () => { S.selFlag = key; drawExplain(f); };
    feed.appendChild(d);
    if (isNew && S.playing && f.alert_enabled && today) toast(`<b>${f.measure} changed from own baseline</b><br><span class="small">${f.crew_id} · mission day ${f.mission_day} · ${f.value}. Open the explanation card.</span>`);
  });
  let sel = evs.find(f => f.crew_id + f.measure + f.mission_day === S.selFlag) || v.active_flags.find(f => f.alert_enabled) || null;
  drawExplain(sel);
  const ss = $('#sigsel');
  if (!ss.options.length) { Object.entries(SIGS).forEach(([k, n]) => ss.appendChild(el('option', { value: k }, n))); ss.onchange = () => { S.sig = ss.value; $('#siglab').textContent = SIGS[S.sig]; drawConsole(); }; }
  ss.value = S.sig; $('#siglab').textContent = SIGS[S.sig];
}

function drawExplain(f) {
  const box = $('#explain');
  if (!f) { box.className = 'muted small'; box.innerHTML = 'No flag selected. When the rule fires, its explanation appears here: what changed, when, which rule fired, and the evidence behind it.'; return; }
  box.className = '';
  const ev = evById(f.evidence_id);
  const pct = (f.value_num - f.median) / f.median * 100;
  const later = V.flags.filter(x => x.measure === f.measure && x.mission_day > f.mission_day).map(x => x.mission_day);
  box.innerHTML = `<div class="exp">
   <div>What changed</div><div>${f.measure} ${f.value} vs own 30-day median ${fmt(f.median, 2)} ${f.unit} (${pct > 0 ? '+' : ''}${pct.toFixed(0)}%, modified z = ${fmt(f.z, 2)}).</div>
   <div>When</div><div>Mission day ${f.mission_day} (${f.date}).${later.length ? ' Also flagged on day ' + later.join(', ') + '.' : ''}</div>
   <div>Rule fired</div><div><b>${f.rule_id}</b> · ${f.why} · rules_v1</div>
   <div>Context</div><div>Cabin CO2 ${f.cabin_co2 != null ? fmt(f.cabin_co2, 1) + ' mmHg' : 'n/a (pre-flight)'} that day. Shown as context, not as a cause.</div>
   <div>Evidence</div><div>${ev ? `${esc(ev.source)} ${esc(ev.what)} · ${evLink(ev.id)}` : 'No published support linked: monitoring only.'}</div>
   <div>Not a diagnosis</div><div>This flag says "worth checking". It does not identify a cause or a condition.</div>
   <div>Status type</div><div>${pb('DERIVED')} deviation · ${esc(f.confidence)}</div>
   <div>Recommended action</div><div>"${esc(f.action)}" ${f.alert_enabled ? '(R09)' : '(alert disabled for SpO2)'}</div></div>`;
}

function drawRules() {
  $('#ruletable').innerHTML = '<tr><th>Rule</th><th>Applies to</th><th>Fires when</th><th>Alert</th><th>Action</th><th>Evidence</th></tr>' +
    RULES9.rules.map(r => `<tr><td><b>${r.rule_id}</b> ${esc(r.name)}</td><td>${esc(r.applies_to)}</td><td>${esc(r.fires_when)}</td><td>${esc(r.alert)}</td><td>${esc(r.action)}</td><td>${evLink(r.evidence_id)}</td></tr>`).join('');
}

function startLive() {
  if (liveTimer) return;
  liveBuf = [];
  const tick = async () => {
    if (S.view !== 'console') { clearInterval(liveTimer); liveTimer = null; return; }
    try {
      const r = await API.get(`/vitals/${S.persona}/live`, { day: S.day });
      if (!liveBuf.length) r.samples.forEach(s => liveBuf.push(s.hr)); else liveBuf.push(r.samples.length ? r.samples.at(-1).hr : null);
      while (liveBuf.length > 90) liveBuf.shift();
      lineChart($('#cvLive'), { x: liveBuf.map((_, i) => i - liveBuf.length + 1 + 's'), series: [{ name: 'Heart rate', y: liveBuf, color: '#ff6b7d', unit: 'bpm', dec: 0 }], ymin: 40, ymax: 110, xticks: 6, noHover: true });
    } catch (e) { /* backend restarting */ }
  };
  tick(); liveTimer = setInterval(tick, 1000);
}

function setDay(d) { S.day = d; render(); }

function initConsoleControls() {
  const days = () => S.meta.mission_days;
  $('#dayslider').oninput = e => { let d = +e.target.value; if (d === 0) d = 1; setDay(d); };
  $('#playbtn').onclick = () => {
    S.playing = !S.playing; $('#playbtn').textContent = S.playing ? '❚❚ Pause' : '▶ Play mission'; clearInterval(S.timer);
    if (S.playing) S.timer = setInterval(() => {
      const ds = days(), i = ds.indexOf(S.day);
      if (i >= ds.length - 1) { $('#playbtn').click(); return; }
      S.day = ds[i + 1]; if (S.view === 'console') RENDER.console();
    }, +$('#speed').value);
  };
  $('#speed').onchange = () => { if (S.playing) { $('#playbtn').click(); $('#playbtn').click(); } };
  $('#jumpbtn').onclick = () => { S.persona = 'SIM-A'; S.sig = 'hrv'; S.day = 21; S.selFlag = null; fillCrewSelect(); render(); toast('<b>HRV (RMSSD) below own range</b><br><span class="small">SIM-A · mission days 20–21.</span>'); };
  $('#resetbtn').onclick = () => { if (S.playing) $('#playbtn').click(); S.day = -15; S.selFlag = null; S.seen.clear(); render(); };
}
