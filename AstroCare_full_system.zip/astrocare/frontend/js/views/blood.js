"use strict";
/* M3 blood biodosimeter */
let M3 = null;

RENDER.blood = async function () {
  try {
    if (!M3) { M3 = await API.get('/blood/info'); initBlood(); drawValidation(); }
    await runBlood();
  } catch (e) { showErr($('#m3out'), e); }
};

function initBlood() {
  const s = $('#bloodProf');
  M3.demo_profiles.forEach(p => s.appendChild(el('option', { value: p.id }, `${p.label}`)));
  s.value = 'eva'; s.onchange = runBlood; $('#hrs').oninput = runBlood;
  $('#m3run').onclick = runOwn;
  $('#m3file').onchange = e => { const f = e.target.files[0]; if (!f) return; f.text().then(t => { $('#m3json').value = t; runOwn(); }); };
}

function windowText(h) {
  if (h >= 20 && h <= 28) return chip('st-good', 'Inside M3-24h window (20–28 h)');
  const tp = Math.round(h);
  if ([1, 2, 6].includes(tp) && Math.abs(h - tp) <= 0.5) return chip(tp === 1 ? 'st-warn' : 'st-good', `Inside M3-early ${tp} h window (±0.5 h)${tp === 1 ? ' · exploratory' : ''}`);
  return chip('st-warn', 'Outside validated window') + '<div class="small muted" style="margin-top:6px">Models exist only for 1 h, 2 h, 6 h and 20–28 h after exposure.</div>';
}

async function runBlood() {
  const h = +$('#hrs').value; $('#hrsLab').textContent = h;
  $('#windowMsg').innerHTML = windowText(h);
  const r = await API.post('/blood/predict', { demo_profile: $('#bloodProf').value, hours_since_exposure: h });
  if (S.view !== 'blood') return;
  $('#m3out').className = '';
  $('#m3out').innerHTML = m3Result(r);
  const c = r.comparison;
  $('#m3disc').innerHTML = `<table><tr><th>Source</th><th>Estimate</th></tr><tr><td>M2 physical dose</td><td>${esc(r.profile.physical)} ${pb('ESTIMATED')}</td></tr><tr><td>M3 biological response</td><td>${r.status === 'ML_PREDICTED' ? (r.dose_gy_xray_equivalent != null ? fmt(r.dose_gy_xray_equivalent, 2) + ' Gy' : r.dose_class_gy + ' Gy class') : 'no estimate'} ${pb('ML_PREDICTED')}</td></tr></table>
    <p class="small" style="margin:10px 0 0">${chip(c.cls, c.text)}${c.action ? `<br><br>"${esc(c.action)}" (${c.rule_id})` : ''}</p><p class="small muted">If M2 said low but M3 said high, rule R12 would ask for a repeat blood assessment.</p>`;
}

function m3Result(r) {
  if (r.status !== 'ML_PREDICTED') return `<div class="kpi" style="font-size:20px">No output</div><p class="small">"${esc(r.message || r.status)}"</p>`;
  if (r.dose_class_gy != null) {
    const probs = Object.entries(r.probabilities); const best = r.dose_class_gy;
    return `<div class="small muted">${r.model_id} · dose class</div><div class="kpi">${best} Gy<small>p = ${fmt(r.probabilities[String(best)], 2)}</small></div>` +
      probs.map(([c, p]) => `<div class="row small" style="margin:4px 0"><span style="width:60px">${c} Gy</span><div style="flex:1;height:10px;background:#1a2440;border-radius:5px;overflow:hidden"><div style="width:${p * 100}%;height:100%;background:${+c === best ? '#9085e9' : '#3d4f7a'}"></div></div><span style="width:40px;text-align:right">${fmt(p, 2)}</span></div>`).join('') +
      `<div class="small" style="margin-top:8px">Reliability: <b>${esc(r.reliability)}</b> · ${r.n_genes} genes · ${evLink(r.evidence_id)}</div><div class="small muted">0.15 and 0.30 Gy are often confused.</div>`;
  }
  const rng = r.below_validated_range ? chip('st-none', `Below the ${r.valid_dose_range_gy[0]} Gy the model can resolve`) : r.above_validated_range ? chip('st-warn', `Above validated range (under-reads high doses)`) : chip('st-good', `Within validated range ${r.valid_dose_range_gy.join('–')} Gy`);
  return `<div class="small muted">${r.model_id} · regression</div><div class="kpi">${fmt(r.dose_gy_xray_equivalent, 2)}<small>Gy (X-ray-equivalent)</small></div><div class="small">± mean LODO error: ${r.interval_gy.join('–')} Gy</div><div style="margin:8px 0">${rng}</div><div class="small muted">${esc(r.caveat)} · ${r.n_genes} genes · ${evLink(r.evidence_id)}</div>`;
}

async function runOwn() {
  const out = $('#m3own');
  let body; try { body = JSON.parse($('#m3json').value || '{}'); } catch (e) { out.innerHTML = '<div class="err">That is not valid JSON.</div>'; return; }
  try { const r = await API.post('/blood/predict', body); out.innerHTML = m3Result(r) + `<div style="margin-top:6px">${r.n_missing ? `<span class="small muted">Missing probes: ${r.missing.join(', ')}${r.n_missing > 20 ? '…' : ''}</span>` : ''}</div>`; }
  catch (e) { out.innerHTML = `<div class="err">${esc(e.message)}</div>`; }
}

function drawValidation() {
  const m = M3.models, d = M3.data, card = id => M3.cards.find(c => c.card_id === id) || {};
  const v24 = m['24h'].validation;
  $('#m3valid').innerHTML = `
  <div class="grid g2" style="margin-top:16px">
    <div class="card"><h3><span>M3-24h · leave-one-donor-out</span><span class="pb ML_PREDICTED">Real validation</span></h3>
      <div class="cv" id="cvLodo" style="height:260px"></div>
      <p class="small" style="margin:6px 0 0">Exposed samples: mean error <b>${v24.exposed.MAE_gy} Gy</b>, ${v24.exposed['within_0.5gy_pct']}% within 0.5 Gy (n ${v24.exposed.n}, 11 donors). ${esc(card('M3-24H').known_limits)}</p></div>
    <div class="card"><h3><span>Neutron test · frozen 24 h model</span><span class="pb CONTEXT">Radiation-quality caveat</span></h3>
      <div class="cv" id="cvNeut" style="height:260px"></div>
      <p class="small" style="margin:6px 0 0">${esc(card('M3-NEUTRON').what_it_shows)}. ${esc(card('M3-NEUTRON').meaning)}.</p></div>
  </div>
  <div class="grid g3" style="margin-top:16px">${['1h', '2h', '6h'].map(tp => { const mm = m['early_' + tp]; const c = card('M3-EARLY-' + tp.toUpperCase());
    return `<div class="card"><h3><span>M3-early ${tp}</span><span class="chip">${tp === '1h' ? 'exploratory' : 'study-specific'}</span></h3>${confusion(d['early_' + tp + '_lodo_predictions'], mm.classes_dose_gy, 'true_dose_gy', 'pred_dose_gy')}
    <p class="small" style="margin:8px 0 0">Balanced accuracy (exposed) <b>${mm.validation.balanced_accuracy_exposed}</b> vs chance ${mm.validation.chance_exposed} · ${mm.validation.n_donors} donors · ${mm.n_features} genes</p><p class="small muted" style="margin:4px 0 0">${esc(c.reliability || '')}. Top genes: ${(c.top_genes || []).map(g => `<span class="gene">${g}</span>`).join(' ')}</p></div>`; }).join('')}</div>
  <div class="grid g2" style="margin-top:16px">
    <div class="card"><h3><span>M3-24h genes (stability selection)</span><span class="pb DERIVED">Derived</span></h3>
      <table><tr><th>Gene</th><th>Probe</th><th>Selected in</th><th>Weight</th></tr>${d['24h_genes_v2'].map(g => `<tr><td><span class="gene">${g.gene_symbol}</span></td><td class="muted">${g.source_feature_id}</td><td>${Math.round(g.stability_freq * 100)}% of bootstraps</td><td>${(+g.coef).toFixed(3)}</td></tr>`).join('')}</table>
      <p class="small muted" style="margin:8px 0 0">ASTN2, GRIN3B and C3orf52 are likely spurious (small weights). Mostly p53-pathway genes.</p></div>
    <div class="card"><h3><span>Independent check and window rule</span><span class="pb CONTEXT">Context</span></h3>
      <p class="small" style="margin-top:0"><b>${esc(card('M3-EXTERNAL').title)}:</b> ${esc(card('M3-EXTERNAL').what_it_shows)}. ${esc(card('M3-EXTERNAL').meaning)}.</p>
      <p class="small"><b>${esc(card('M3-WINDOW-RULE').title)}:</b> ${esc(card('M3-WINDOW-RULE').rule)}.</p>
      <p class="small muted" style="margin:0">All M3 models are trained on ex vivo irradiated Earth blood, not astronauts.</p></div>
  </div>`;
  const pts = d['24h_lodo_predictions'].map(r => ({ x: +r.dose_gy, y: +r.pred_gy, c: +r.dose_gy > 2 ? css('--serious') : css('--violet'), tip: `${r.donor_id}: ${r.dose_gy} Gy → ${(+r.pred_gy).toFixed(2)} Gy` }));
  scatterChart($('#cvLodo'), { points: pts, xlabel: 'Physical dose (Gy)', ylabel: 'Predicted (Gy)' });
  const np = d.neutron_test_v2.map(r => ({ x: +r.dose_gy, y: +r.pred_xray_equiv_gy, c: css('--orange'), tip: `${r.donor_id}: ${r.dose_gy} Gy neutron → ${(+r.pred_xray_equiv_gy).toFixed(2)} Gy X-ray-eq.` }));
  scatterChart($('#cvNeut'), { points: np, xlabel: 'Neutron dose (Gy)', ylabel: 'X-ray-equivalent reading (Gy)', lines: [{ slope: 1, color: 'rgba(255,255,255,.35)', label: '1:1' }, { slope: m['24h'].neutron_slope, color: css('--orange'), label: `slope ${m['24h'].neutron_slope.toFixed(2)}` }] });
}
