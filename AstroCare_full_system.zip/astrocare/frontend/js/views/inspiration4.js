"use strict";
/* Inspiration4 replay: M4 microbiome, M7 immune, M8 telomere, M6 recovery (real crew C001-C004) */

RENDER.microbiome = async function () {
  const host = $('#microBody');
  let r; try { r = await API.get('/microbiome/' + S.i4); } catch (e) { return showErr(host, e); }
  const c = r.card, clf = r.classifier;
  const lo = 0.5, hi = 1.6, pos = v => ((v - lo) / (hi - lo) * 100).toFixed(1) + '%';
  host.className = '';
  host.innerHTML = `
  <div class="grid g4">
    <div class="card"><h3><span>Status · ${c.crew_id}</span></h3><div style="margin:6px 0">${chip(c.status.startsWith('Within') ? 'st-good' : 'st-warn', esc(c.status))}</div>${pb(c.status_type)} <span class="chip">${esc(c.tier.replace('_', ' · '))}</span></div>
    <div class="card"><h3><span>In-flight distance</span></h3><div class="kpi">${fmt(c.value, 2)}</div><div class="small muted">${esc(c.value_label)} · own range ${c.baseline_range.join('–')}</div></div>
    <div class="card"><h3><span>After landing</span></h3><div class="kpi">${esc(c.trend.split(':')[1] || c.trend)}</div><div class="small muted">${esc(c.trend.split(':')[0])} (back near own baseline)</div></div>
    <div class="card"><h3><span>Confidence</span></h3><div class="kpi" style="font-size:20px">Low</div><div class="small muted">${esc(c.confidence)}</div></div>
  </div>
  <div class="grid g2" style="margin-top:16px">
    <div class="card"><h3><span>All crew · in-flight distance vs own pre-flight range</span><span class="pb DERIVED">Derived</span></h3>
      ${r.all_cards.map(k => `<div class="row small" style="margin-top:8px"><b style="width:46px">${k.crew_id}</b><div style="flex:1"><div class="rangebar"><div class="rb" style="left:${pos(k.baseline_range[0])};width:calc(${pos(k.baseline_range[1])} - ${pos(k.baseline_range[0])})"></div><div class="rv" style="left:${pos(k.value)}"></div></div></div><span style="width:120px;text-align:right">${fmt(k.value, 2)} · ${k.trend}</span></div>`).join('')}
      <div class="legend" style="margin-top:10px"><span><i class="band"></i>Own pre-flight range</span><span><i style="background:var(--aqua);height:10px;width:4px"></i>In-flight median</span><span class="muted">axis ${lo}–${hi}</span></div>
      <div class="kv" style="margin-top:12px"><div>Sites (Tier A)</div><div>${c.sites.join(', ')}</div><div>Rule</div><div>${c.rule_id} · decisions ${c.decision_ids.join(', ')}</div><div>Source</div><div>${esc(c.source)} · ${evLink('EV-OSD-572')}</div><div>Why</div><div>${esc(c.why)}</div></div>
      <div class="note warn" style="margin-top:10px"><b>QC:</b> ${esc(c.qc_note)}</div></div>
    <div class="card"><h3><span>Team notebook figure</span><span class="pb DERIVED">Real data</span></h3><img class="fig" src="${r.figures[0].src}" alt="M4 Tier A change from baseline"><p class="figcap">${esc(r.figures[0].caption)}</p></div>
  </div>
  <div class="grid g2" style="margin-top:16px">
    <div class="card"><h3><span>Exploratory classifier (not a prediction model)</span><span class="chip">${esc(clf.validation)}</span></h3>
      <table><tr><th>Model</th><th>AUROC</th><th>Chance (95th pct)</th></tr>${clf.models.map(m => `<tr><td>${esc(m.model)}</td><td>${m.AUROC}</td><td>${m.chance_95th ?? '–'}</td></tr>`).join('')}</table>
      <p class="small" style="margin:8px 0 0">${esc(clf.conclusion)}</p>
      <img class="fig" style="margin-top:10px" src="${r.figures[2].src}" alt="Classifier AUROC"><p class="figcap">${esc(r.figures[2].caption)}</p></div>
    <div class="card"><h3><span>Contamination check</span><span class="pb DERIVED">QC</span></h3><img class="fig" src="${r.figures[1].src}" alt="In-flight-only taxa"><p class="figcap">${esc(r.figures[1].caption)}</p>
      <p class="small" style="margin:10px 0 0">Recommendation: "Continue longitudinal microbiome monitoring." (R30)</p></div>
  </div>`;
};

function moduleCards(r) {
  if (!r.loaded) return `<div class="card"><h3><span>${esc(r.title)} · ${r.crew_id}</span>${pb('CONTEXT')}</h3>
    <div class="note warn"><b>Card file not loaded.</b> Put <code>${esc(r.file_expected.split('/').pop())}</code> into <code>backend/data/cards/</code> and reload this page. Any list of card objects with <code>crew_id</code>, <code>status</code> and <code>status_type</code> is shown here.</div>
    <p class="small" style="margin:12px 0 4px"><b>Team result</b> (${esc(r.summary_source)}):</p><p class="small" style="margin:0">${esc(r.team_summary)}</p>
    <p class="small muted" style="margin:10px 0 0">Evidence: ${evLink(r.evidence_id)} · rule ${r.rule_id}</p></div>`;
  if (!r.cards.length) return `<div class="card"><p class="small muted">No cards for ${r.crew_id} in the loaded file.</p></div>`;
  const skip = new Set(['crew_id', 'module', 'status_type', 'is_simulated', 'banner']);
  return `<div class="grid g2">${r.cards.map(c => `<div class="card"><h3><span>${esc(c.domain || c.measure || c.title || r.title)}</span>${pb(c.status_type || 'DERIVED')}</h3>
    ${c.status ? `<div style="margin:4px 0 8px">${chip(/changed/i.test(c.status) ? 'st-warn' : /within|back/i.test(c.status) ? 'st-good' : 'st-none', esc(c.status))}</div>` : ''}
    <div class="kv">${Object.entries(c).filter(([k]) => !skip.has(k) && k !== 'status').map(([k, v]) => `<div>${esc(k.replace(/_/g, ' '))}</div><div>${esc(typeof v === 'object' ? JSON.stringify(v) : v)}</div>`).join('')}</div></div>`).join('')}</div>`;
}

function zColor(z, k) { if (z == null) return '#222a3d'; const t = Math.max(-1, Math.min(1, z / (2 * k))); const a = Math.abs(t); const c = t > 0 ? [217, 89, 38] : [28, 92, 171]; return `rgb(${Math.round(40 + (c[0] - 40) * a)},${Math.round(46 + (c[1] - 46) * a)},${Math.round(60 + (c[2] - 60) * a)})`; }

function chanceTable(rows, tps) {
  const panels = [...new Set(rows.map(r => r.panel))];
  return `<table><tr><th>Panel</th>${tps.map(t => `<th>${t}</th>`).join('')}</tr>${panels.map(p => { const rr = rows.filter(r => r.panel === p);
    return `<tr><td>${esc(rr[0].label)}<div class="muted small">${rr[0].osd}</div></td>${tps.map(t => { const x = rr.find(r => r.timepoint === t);
      return `<td>${x.above_chance ? chip('st-warn', `${x.n_flagged}/${x.n_tested}`) : `<span class="muted">${x.n_flagged}/${x.n_tested}</span>`}<div class="muted small">expected ${x.expected}${x.above_chance ? ' · p ' + (x.p_value < 0.0001 ? '< 0.0001' : x.p_value) : ''}</div></td>`; }).join('')}</tr>`; }).join('')}</table>`;
}

RENDER.immune = async function () {
  const host = $('#immBody');
  let r; try { r = await API.get('/immune/' + S.i4); } catch (e) { return showErr(host, e); }
  host.className = '';
  const cal = r.panels, h = r.heatmap;
  const r1 = r.rows.filter(x => x.timepoint === 'R+1'), worst = r.rows.filter(x => x.above_chance);
  host.innerHTML = `
  <div class="grid g4">
    <div class="card"><h3><span>Immune status · ${r.crew_id}</span></h3><div style="margin:6px 0">${chip(r.changed ? 'st-warn' : 'st-good', r.changed ? 'Changed from own baseline' : 'No change beyond chance')}</div>${pb('DERIVED')} <span class="chip">${r.rule_id}</span></div>
    <div class="card"><h3><span>Changed at R+1</span></h3><div class="kpi">${r1.reduce((a, x) => a + x.n_flagged, 0)}<small>of ${r1.reduce((a, x) => a + x.n_tested, 0)} analytes</small></div><div class="small muted">expected by chance ≈ ${fmt(r1.reduce((a, x) => a + x.expected, 0), 0)}</div></div>
    <div class="card"><h3><span>Timepoints above chance</span></h3><div class="kpi">${worst.length}<small>of ${r.rows.length} panel × timepoint</small></div><div class="small muted">${worst.map(x => x.timepoint + ' ' + x.label.split('(')[0].trim()).join(' · ') || 'none'}</div></div>
    <div class="card"><h3><span>In flight</span></h3><div class="kpi" style="font-size:20px">No measurement</div><div class="small muted">${esc(r.in_flight)}</div></div>
  </div>
  <div class="card" style="margin-top:16px"><h3><span>Analytes outside own pre-flight variation, by timepoint</span><span class="pb DERIVED">Real data · derived</span></h3>
    <div class="tablewrap" style="max-height:none">${chanceTable(r.rows, ['R+1', 'R+45', 'R+82', 'R+194'])}</div>
    <p class="small muted" style="margin:8px 0 0">Thresholds |z| &gt; k: ${cal.map(c => `${esc(c.label.split('(')[0].trim())} k = ${c.threshold_k} (pre-flight false-flag rate ${fmt(c.preflight_false_flag_rate * 100, 1)}%, ${c.n_analytes} analytes)`).join(' · ')}. Highlighted cells have more flags than chance (one-sided binomial p &lt; 0.05).</p></div>
  <div class="grid g2" style="margin-top:16px">
    <div class="card"><h3><span>Largest changes · ${esc(h.label)}</span><span class="pb DERIVED">z vs own baseline</span></h3>
      <div class="legend"><span><i style="background:#1c5cab;height:10px"></i>Lower than own baseline</span><span><i style="background:#d95926;height:10px"></i>Higher</span><span>outlined = |z| &gt; ${h.threshold_k}</span></div>
      <table class="cm" style="width:100%"><tr><th style="text-align:left">Analyte</th>${h.timepoints.map(t => `<th>${t}</th>`).join('')}</tr>${h.rows.map(x => `<tr><td style="text-align:left">${esc(x.analyte)}</td>${x.z.map(z => `<td style="background:${zColor(z, h.threshold_k)};${z != null && Math.abs(z) > h.threshold_k ? 'outline:2px solid #fab219;outline-offset:-2px' : ''}">${z == null ? '–' : fmt(z, 1)}</td>`).join('')}</tr>`).join('')}</table></div>
    <div class="card"><h3><span>Blood counts vs own pre-flight range</span><span class="pb MEASURED">Real data</span></h3>
      <div class="legend"><span><i style="background:var(--blue)"></i>Lymphocytes</span><span><i style="background:var(--orange)"></i>Neutrophils</span><span><i style="background:var(--aqua)"></i>Monocytes</span><span><i class="band"></i>Lymphocyte pre-flight range</span></div>
      <div class="cv" id="cvCBC" style="height:300px"></div><p class="small muted" style="margin:6px 0 0">${esc(r.cbc[0] ? r.cbc[0].unit : '')} · OSD-569. Lab reference ranges are not used for flags.</p></div>
  </div>
  ${r.notebook_cards ? `<div class="card" style="margin-top:16px"><h3><span>Team notebook cards (m7_cards.json)</span>${pb('DERIVED')}</h3>${moduleCards({ loaded: true, cards: r.notebook_cards, title: 'M7', crew_id: r.crew_id })}</div>` : ''}`;
  const cols = [css('--blue'), css('--orange'), css('--aqua')];
  if (r.cbc.length) lineChart($('#cvCBC'), { x: r.cbc[0].timepoints, series: r.cbc.map((s, i) => ({ name: s.analyte, y: s.values, color: cols[i], dots: true, unit: s.unit, dec: 2 })),
    band: r.cbc[0].timepoints.map(() => r.cbc[0].preflight_range), xticks: 7, ymin: 0 });
};

RENDER.telomere = async function () {
  const host = $('#teloBody');
  let r; try { r = await API.get('/telomere/' + S.i4); } catch (e) { return showErr(host, e); }
  host.className = '';
  const arrow = d => d === 'up' ? '<span style="color:#5fd3a6;font-size:34px;line-height:1">▲</span>' : d === 'down' ? '<span style="color:#ec835a;font-size:34px;line-height:1">▼</span>' : '<span style="color:#8dbdf5;font-size:34px;line-height:1">●</span>';
  const dots = (n, d) => n == null ? '<span class="small muted">all 4 crew sampled</span>' : [0, 1, 2, 3].map(i => `<span title="crew member" style="display:inline-block;width:14px;height:14px;border-radius:50%;margin-right:5px;background:${i < n ? (d === 'up' ? '#5fd3a6' : '#ec835a') : '#3d4f7a'}"></span>`).join('') + `<span class="small" style="margin-left:4px"><b>${n} of 4</b> crew</span>`;
  host.innerHTML = `
  <div class="card"><h3><span>What happened to telomeres on Inspiration4</span>${pb('CONTEXT')}</h3>
    <div class="grid g3" style="margin-top:8px">${r.phases.map((p, i) => `<div class="box" style="position:relative;padding:16px">
      <div class="crewkind">${esc(p.phase)}</div>
      <div class="row" style="margin:10px 0 6px;gap:12px">${arrow(p.direction)}<b style="font-size:16px">${esc(p.finding)}</b></div>
      <div style="margin:8px 0">${dots(p.crew_changed, p.direction)}</div>
      <div class="row" style="gap:5px;margin-top:8px">${p.timepoints.map(t => `<span class="gene">${t}</span>`).join('')}</div>
      ${i < r.phases.length - 1 ? '<div style="position:absolute;right:-14px;top:50%;transform:translateY(-50%);color:var(--accent);font-weight:700;font-size:20px;z-index:2">→</div>' : ''}</div>`).join('')}</div>
    <p class="small muted" style="margin:12px 0 0">Relative telomere length by qPCR on dried blood spots (a ratio, not a length in kb). The study reports how many crew changed, not which ones, so the same picture applies to every crew member.</p></div>
  <div class="grid g2" style="margin-top:16px">
    <div class="card"><h3><span>Same pattern as the NASA Twins Study</span>${pb('CONTEXT')}</h3>
      <table><tr><th>Who</th><th>In flight</th><th>After return</th></tr>${r.comparison.map(c => `<tr><td>${esc(c.who)}</td><td>${esc(c.in_flight)}</td><td>${esc(c.after)}</td></tr>`).join('')}</table>
      <p class="small muted" style="margin:8px 0 0">The change appeared even on a 3-day mission.</p></div>
    <div class="card"><h3><span>Other findings from the same study</span>${pb('CONTEXT')}</h3>
      <table>${r.statements.filter(x => ['Genome', 'cfDNA', 'Interpretation'].includes(x.topic)).map(x => `<tr><td class="muted" style="width:110px">${esc(x.topic)}</td><td>${esc(x.text)}</td></tr>`).join('')}</table></div>
  </div>
  <div class="card" style="margin-top:16px"><h3><span>Why AstroCare shows context here, not a chart per person</span></h3>
    <p class="small" style="margin-top:0">${esc(r.why_context_only)}</p>
    <p class="small" style="margin:0">"Continue longitudinal telomere monitoring and compare with recovery measurements." (R40)</p>
    <p class="small" style="margin:10px 0 0">Source: <a href="${r.link}" target="_blank" rel="noopener">${esc(r.citation)} ↗</a> · ${evLink(r.evidence_id)}</p></div>`;
};

RENDER.recovery = async function () {
  let r; try { r = await API.get('/recovery/' + S.i4); } catch (e) { return showErr($('#recMods'), e); }
  const cls = s => /changed/i.test(s) ? 'st-warn' : /no measurement|context/i.test(s) ? 'st-none' : 'st-good';
  $('#recTable').innerHTML = '<tr><th>Indicator</th><th>Status</th><th>Detail (flagged / tested)</th><th>Type</th><th>Source</th></tr>' +
    r.rows.map(x => `<tr><td>${esc(x.indicator)}</td><td>${chip(cls(x.status), esc(x.status))}</td><td class="small">${esc(x.detail)}</td><td>${pb(x.status_type)}</td><td class="muted small">${esc(x.source)}</td></tr>`).join('');
  const m = r.m6, t = m.totals, all = r.m6_all.totals;
  const ch = m.changes;
  $('#recMods').innerHTML = `<div class="grid g3">
    <div class="card"><h3><span>M6 · ${r.crew_id}</span><span class="chip">${m.rule_id}</span></h3><div class="kpi">${t.back_r82}<small>of ${t.followed_r82} R+1 changes back by R+82</small></div>
      <div style="margin:8px 0">${chip(t.flagged_r1 ? (m.back_fraction_r82 >= 0.75 ? 'st-good' : 'st-warn') : 'st-good', esc(m.status))} ${pb('DERIVED')}</div>
      <div class="small muted">Back by R+45: ${t.back_r45} · R+82: ${t.back_r82} · R+194: ${t.back_r194}</div></div>
    <div class="card"><h3><span>All four crew</span></h3><div class="kpi">${all.back_r82}<small>of ${all.followed_r82} back by R+82</small></div><div class="small muted">${fmt(r.m6_all.back_fraction_r82 * 100, 0)}% · team notebook reported 35 of 39 with its own thresholds</div></div>
    <div class="card"><h3><span>Bone context</span>${pb('CONTEXT')}</h3><p class="small" style="margin:0">Lost bone is regained only slowly after long missions (about half within ~9 months). Context only; no individual bone forecast (${evLink('EV-BONE')}).</p><p class="small" style="margin:8px 0 0">"Continue longitudinal recovery monitoring." (R70)</p></div></div>
  <div class="card" style="margin-top:16px"><h3><span>R+1 changes and what happened next · ${r.crew_id}</span><span class="pb DERIVED">Real data</span></h3>
    ${ch.length ? `<div class="tablewrap"><table><tr><th>Analyte</th><th>Panel</th>${r.timepoints.map(x => `<th>${x} z</th>`).join('')}<th>Back by R+82</th></tr>${ch.map(c => `<tr><td>${esc(c.analyte)}</td><td class="small muted">${esc(c.panel_label)}</td>${r.timepoints.map(x => `<td style="background:${zColor(c.z[x], c.threshold_k)}">${c.z[x] == null ? '–' : fmt(c.z[x], 1)}</td>`).join('')}<td>${c.back['R+82'] == null ? chip('st-none', 'no sample') : c.back['R+82'] ? chip('st-good', 'back') : chip('st-warn', 'not yet')}</td></tr>`).join('')}</table></div>` : '<p class="small muted">No analyte moved beyond own variation at R+1.</p>'}
    <p class="small muted" style="margin:8px 0 0">${esc(m.note)}</p></div>`;
};
