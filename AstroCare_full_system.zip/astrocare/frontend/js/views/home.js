"use strict";
const MODS = [
  ['M1', 'Radiation storm forecaster', 'Calibrated logistic regression on flare size · DONKI + GOES, tested 2024–2026.', 'Tier 1 · ML', 'radiation'],
  ['M2', 'Crew dose estimator', 'Dose behind shielding · MSL/RAD background rate.', 'Estimated', 'radiation'],
  ['M3', 'Blood biodosimeter', 'Blood gene response to radiation · OSD-1012 (24 h), OSD-410 (1/2/6 h).', 'Tier 1 · ML', 'blood'],
  ['M4', 'Microbiome drift', 'Distance from own pre-flight swabs · OSD-572, Tier A sites.', 'Tier 2 · trend', 'microbiome'],
  ['M5', 'Brain evidence + behaviour', 'Mouse evidence as context; self-reports and reaction test.', 'Tier 3/4', 'bodymind'],
  ['M6', 'Recovery trajectory', 'Do R+1 lab changes return to own variation? R+45 to R+194 · OSD-575, 569.', 'Tier 2 · trend', 'recovery'],
  ['M7', 'Immune monitoring', 'Cytokines, NULISA panel and blood counts vs own pre-flight baseline · OSD-575, 569.', 'Tier 2 · trend', 'immune'],
  ['M8', 'Telomere context', 'Published Inspiration4 findings (Garcia-Medina et al. 2024); no per-crew values.', 'Tier 3 · context', 'telomere'],
  ['M9', 'Crew Health Console', 'Daily vitals, fixed baseline rule, evidence for every flag.', 'Tier 4 · rules', 'console']];

RENDER.home = async function () {
  const g = $('#modgrid');
  if (!g.children.length) MODS.forEach(m => {
    const c = el('div', { class: 'card mod', tabindex: 0 }, `<div class="row"><span class="num">${m[0]}</span><span class="sp"></span><span class="chip">${m[3]}</span></div><h3 style="margin-top:8px">${m[1]}</h3><div class="small muted">${m[2]}</div>`);
    c.onclick = () => go(m[4]); c.onkeydown = e => { if (e.key === 'Enter') go(m[4]); }; g.appendChild(c);
  });
  try {
    const [v, d, mb, m1] = await Promise.all([API.get('/vitals/SIM-A', { day: S.day }), API.get('/radiation/SIM-A/dose', { day: S.day }),
      API.get('/microbiome/C001'), API.get('/radiation/m1/summary')]);
    $('#h1v').textContent = `${fmt(v.today.hrv.value, 0)} ms · day ${v.day}`;
    $('#h2v').textContent = `${fmt(d.cumulative_msv, 1)} mSv`;
    $('#h3v').textContent = mb.card.status;
    $('#h4v').textContent = `${m1.test_results.storms_caught} of ${m1.test_results.storms_caught + m1.test_results.storms_missed} (2024–26)`;
    $('#statEv').textContent = EVID.length || 14;
  } catch (e) { console.warn(e); }
};
