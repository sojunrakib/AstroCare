"use strict";
/* M1 (test-set replay + live model) and M2 (mission dose) */
let M1 = null, M1S = null;

RENDER.radiation = async function () {
  try {
    if (!M1) { [M1, M1S] = await Promise.all([API.get('/radiation/m1/summary'), API.get('/radiation/m1/storms')]); drawM1Static(); }
    drawM1Timeline();
    await drawMission();
  } catch (e) { showErr($('#m1real'), e); }
};

function drawM1Static() {
  const t = M1.test_results;
  const host = $('#m1real');
  host.innerHTML = `
  <div class="grid g4">
    <div class="card"><h3><span>Storms warned (test 2024–26)</span><span class="pb ML_PREDICTED">ML predicted</span></h3><div class="kpi">${t.storms_caught}<small>of ${t.storms_caught + t.storms_missed}</small></div><div class="small muted">Recall ${t['Recall_%']}% (95% CI ${M1.test_recall_95ci[0]}–${M1.test_recall_95ci[1]}%)</div></div>
    <div class="card"><h3><span>False alerts</span></h3><div class="kpi">${t.false_alerts}<small>flares</small></div><div class="small muted">≈ ${M1.false_alerts_per_month} per month · ${t['False_alarm_%']}% of alerts</div></div>
    <div class="card"><h3><span>Ranking skill</span></h3><div class="kpi">${t['ROC-AUC']}<small>ROC-AUC</small></div><div class="small muted">PR-AUC ${t['PR-AUC']} (95% CI ${M1.test_pr_auc_95ci.join('–')}) · Brier ${t.Brier}</div></div>
    <div class="card"><h3><span>Try the model</span><span class="pb ML_PREDICTED">Live</span></h3><div class="row"><input type="text" id="flareIn" value="X1.0" style="width:90px" aria-label="Flare class"><button class="btn sm" id="flareBtn">Forecast</button></div><div id="flareOut" class="small" style="margin-top:8px"></div></div>
  </div>
  <div class="grid g-console" style="margin-top:16px">
    <div class="card"><h3><span>Replay: flares around <span id="stormLab"></span></span><span class="pb ML_PREDICTED">Real test-set output</span></h3>
      <div class="legend"><span><i style="background:var(--violet)"></i>SEP probability (48 h) per flare</span><span><i style="background:var(--serious)"></i>Flare that produced a storm</span><span><i style="background:var(--warn)"></i>Alert threshold ${M1.threshold}</span></div>
      <div class="cv" id="cvM1" style="height:250px"></div>
      <p class="small muted" style="margin:6px 0 0">${esc(M1.alert_rule_plain)}. Target: ${esc(M1.target)}.</p></div>
    <div class="card"><h3><span>All ${M1S.storms.length} test storms</span><span class="chip">click to replay</span></h3>
      <div class="tablewrap" style="max-height:300px"><table id="stormTable"></table></div></div>
  </div>
  <div class="grid g2" style="margin-top:16px">
    <div class="card"><h3><span>Why M1 is an ML model, and what it cannot do</span><span class="chip">Tier 1 · ML</span></h3>
      <p class="small" style="margin-top:0">Model chosen by cross-validation on training data only: ${esc(M1.model)} (features: ${M1.features.join(', ')}). Train ${M1.train.period} (${M1.train.flares} flares, ${M1.train.storms} storms) · test ${M1.test.period} (${M1.test.flares} forecast points, ${M1.test.storms} storms).</p>
      <div class="small"><b>Limitations:</b><ul style="margin:4px 0 0 18px;padding:0">${M1.limitations.map(x => `<li>${esc(x)}</li>`).join('')}</ul></div>
      <div class="small" style="margin-top:6px"><b>Excluded:</b> ${M1.excluded.map(esc).join(' · ')}</div></div>
    <div class="card"><h3><span>Cross-validation comparison (training period)</span></h3>
      <table><tr><th>Model</th><th>PR-AUC</th><th>ROC-AUC</th><th>Brier</th></tr>${Object.entries(M1.cv_comparison).map(([k, v]) => `<tr${k === M1.model ? ' class="sel"' : ''}><td>${esc(k)}${k === M1.model ? ' ✓ chosen' : ''}</td><td>${v['PR-AUC']}</td><td>${v['ROC-AUC']}</td><td>${v.Brier}</td></tr>`).join('')}</table>
      <p class="small muted" style="margin:8px 0 0">The simplest model had the best PR-AUC on training CV, so it was kept. Coefficients are exported to <code>backend/data/m1/m1_model_export.json</code>.</p></div>
  </div>`;
  $('#stormTable').innerHTML = '<tr><th>Date</th><th>Flare</th><th>Probability</th><th>Warned</th></tr>' + M1S.storms.map(s =>
    `<tr class="click" data-k="${s.event_key}"><td>${s.date}</td><td>${s.flare_class}</td><td>${fmt(s.sep_probability_48h, 3)}</td><td>${s.caught ? chip('st-good', 'warned') : chip('st-serious', 'missed')}</td></tr>`).join('');
  $('#stormTable').querySelectorAll('tr.click').forEach(tr => tr.onclick = () => { S.stormKey = tr.dataset.k; drawM1Timeline(); });
  if (!S.stormKey) S.stormKey = (M1S.storms.find(s => s.date.startsWith('2024-05')) || M1S.storms[0]).event_key;
  const run = async () => {
    const out = $('#flareOut');
    try { const r = await API.post('/radiation/m1/predict', { flare_class: $('#flareIn').value });
      out.innerHTML = `<b>${fmt(r.sep_probability_48h * 100, 1)}%</b> SEP probability in 48 h · ${r.alert ? chip('st-warn', 'Alert') : chip('st-good', 'No alert')}<div class="muted" style="margin-top:4px">${esc(r.caveat)}</div>`;
    } catch (e) { out.innerHTML = `<span class="err">${esc(e.message)}</span>`; }
  };
  $('#flareBtn').onclick = run; $('#flareIn').onkeydown = e => { if (e.key === 'Enter') run(); }; run();
}

async function drawM1Timeline() {
  const s = M1S.storms.find(x => x.event_key === S.stormKey); if (!s) return;
  $('#stormLab').textContent = `${s.date} (${s.flare_class}, ${s.caught ? 'warned' : 'missed'})`;
  $('#stormTable').querySelectorAll('tr.click').forEach(tr => tr.classList.toggle('sel', tr.dataset.k === S.stormKey));
  const t = await API.get('/radiation/m1/timeline', { around: s.time, days: 4 });
  const f = t.flares;
  lineChart($('#cvM1'), { x: f.map(r => r.time.slice(5, 16).replace('T', ' ')), series: [{ name: 'SEP probability', y: f.map(r => r.sep_probability_48h), color: css('--violet'), dots: true, flags: f.map(r => r.storm), dec: 3 }],
    hlines: [{ y: t.threshold, color: css('--warn'), label: 'alert ' + t.threshold }], ymin: 0, xticks: 6,
    tipExtra: i => `<div class="muted">${f[i].flare_class} · ${f[i].forecast_point}${f[i].storm ? ' · <b style="color:#ec835a">storm</b>' : ''}${f[i].alert ? ' · alert' : ''}</div>` });
}

async function drawMission() {
  const shield = $('#shield'); shield.value = S.shield;
  shield.onchange = () => { S.shield = shield.value; drawMission(); };
  const [f1, d] = await Promise.all([API.get('/radiation/forecast', { day: S.day }), API.get(`/radiation/${S.persona}/dose`, { day: S.day, location: S.shield })]);
  if (S.view !== 'radiation') return;
  $('#radPersona').textContent = `${S.persona} · mission day ${d.day}`; $('#radDay').textContent = d.day;
  $('#sepP').textContent = fmt(f1.sep_probability_48h * 100, 1) + '%';
  $('#sepWhy').innerHTML = `${esc(f1.why)}${f1.alert ? '<br>' + chip('st-warn', 'M1 alert') : ''}`;
  $('#doseRate').textContent = d.dose_rate_usv_h != null ? fmt(d.dose_rate_usv_h, 0) : '–';
  $('#doseLoc').textContent = `µSv/h · ${d.location_today}`;
  $('#doseCum').textContent = fmt(d.cumulative_msv, 1);
  $('#doseLim').textContent = `mSv cumulative · ${fmt(d.pct_career_limit, 1)}% of NASA's ${d.career_limit_msv} mSv career limit · storm adds ${fmt(d.storm_dose_msv, 1)} mSv`;
  $('#radStatus').innerHTML = chip(d.status.cls, d.status.text);
  $('#stormbtn').textContent = `⚡ Go to storm day (D${d.storm.onset_day})`;
  $('#stormbtn').onclick = () => { S.day = d.storm.onset_day; drawMission(); };
  lineChart($('#cvFlux'), { x: d.flux.map(p => p.label), series: [{ name: '≥10 MeV flux', y: d.flux.map(p => p.pfu), color: css('--violet'), unit: 'pfu', dec: 1 }], log: true,
    hlines: [{ y: 10, color: css('--warn'), label: '10 pfu' }], xticks: 6, ymin: 0.1, ymax: 5000 });
  const cols = [css('--blue'), css('--orange'), css('--aqua'), css('--magenta')];
  const ids = Object.keys(d.crew_series);
  $('#doseLegend').innerHTML = ids.map((k, i) => `<span><i style="background:${cols[i]}"></i>${k}${d.eva_persona.includes(k) ? ' (EVA during storm)' : ''}</span>`).join('');
  const days = d.crew_series[ids[0]].map(r => r.day).filter(x => x > 0);
  lineChart($('#cvDose'), { x: days.map(x => 'D' + x), xname: 'Mission', series: ids.map((k, i) => ({ name: k, y: d.crew_series[k].filter(r => r.day > 0).map(r => r.cumulative_msv), color: cols[i], unit: 'mSv', dec: 1, width: d.eva_persona.includes(k) ? 2.5 : 2 })), xticks: 8, now: days.indexOf(d.day) });
  const m = d.method;
  $('#m2method').innerHTML = `Dose-equivalent rate = <b>${m.gcr_msv_per_day} mSv/day</b> galactic cosmic-ray background (MSL/RAD cruise, ${evLink('EV-RAD-MSL')}) + <b>${m.sep_coefficient}</b> mSv/day per pfu of ≥10 MeV proton flux × shielding factor (habitat ${m.shielding.habitat}, shelter ${m.shielding.shelter}, EVA ${m.shielding.eva}). ${pb('ESTIMATED')}`;
}
