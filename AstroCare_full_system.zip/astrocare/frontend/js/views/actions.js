"use strict";
RENDER.actions = async function () {
  const sid = subject();
  let r; try { r = await API.get('/actions/' + sid, { day: S.day, location: S.shield }); } catch (e) { return showErr($('#actList'), e); }
  if (S.view !== 'actions') return;
  $('#actCount').textContent = `${r.actions.length} recommendations · ${sid}${r.kind === 'mission' ? ' · day ' + r.day : ''}`;
  $('#actScope').innerHTML = r.kind === 'mission' ? 'Mission crew member at the current mission day' : 'Inspiration4 crew (NASA OSDR data)';
  $('#actList').innerHTML = r.actions.map(a => `<div class="act"><span class="pri">P${a.priority} · ${a.rule_id}</span><div><div class="rec">${esc(a.text)}</div><div class="why"><b>Why:</b> ${esc(a.why)}</div><div class="small muted" style="margin-top:3px">${esc(a.module)} · ${pb(a.status_type)}</div></div><div class="small">${evLink(a.evidence_id)}</div></div>`).join('') +
    `<div class="card small muted">Priority 1 = notices and data-quality rules (run first) · 2 = status rules · 3 = routine. The engine never names a condition, never suggests medication or dosing, and never replaces the flight surgeon. Rule texts live in <code>backend/data/reference/rules_v1.json</code>.</div>`;
};
