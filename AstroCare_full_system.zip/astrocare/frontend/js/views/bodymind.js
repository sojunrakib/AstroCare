"use strict";
/* Context, bone, behaviour self-report, reaction test, M5 brain context */
const SL = [['sleep', 'Sleep last night', 'h', 3, 10, 0.5, 6.8], ['stress', 'Stress', '1–5', 1, 5, 1, 2], ['mood', 'Mood', '1–5', 1, 5, 1, 4], ['fatigue', 'Fatigue', '1–5', 1, 5, 1, 2]];

RENDER.bodymind = async function () {
  const pid = S.persona;
  try {
    const [cx, beh, bone, brain] = await Promise.all([API.get(`/mission/${pid}/context`, { day: S.day }), API.get('/selfreport/' + pid), API.get('/bone/' + pid, { day: S.day }), API.get('/brain')]);
    if (S.view !== 'bodymind') return;
    $('#ctxTiles').innerHTML = cx.tiles.map(t => `<div class="card"><div class="small muted">${esc(t.label)}</div><div class="kpi" style="font-size:22px">${esc(t.value)}</div>${pb(t.status_type)}</div>`).join('');
    drawBone(bone); drawBehaviour(beh);
    $('#brainCard').innerHTML = `<h3><span>${esc(brain.title)} · M5</span>${pb('CONTEXT')}</h3><p class="small" style="margin:0">${esc(brain.text)} ${evLink(brain.evidence_id)}</p>`;
  } catch (e) { showErr($('#ctxTiles'), e); }
};

function drawBone(b) {
  const bo = $('#boneOut');
  if (!b.scan) bo.innerHTML = `${chip('st-none', esc(b.status))}<p class="small" style="margin:8px 0 0">${b.rule_id ? '"Obtain a bone measurement per mission protocol." (R60) · ' : ''}${b.microgravity_days} days of microgravity; no scan entered.</p><p class="small muted">Published context: lost bone is regained slowly after long missions (${evLink('EV-BONE')}).</p>`;
  else bo.innerHTML = `<div class="kpi">${b.pct_change > 0 ? '+' : ''}${fmt(b.pct_change, 1)}%<small>${esc(b.scan.site)}</small></div>${pb('MEASURED')} ${pb('DERIVED')}<p class="small" style="margin:8px 0 0">Pre-flight ${b.scan.preflight} → latest ${b.scan.latest} g/cm². ${esc(b.note)}</p>`;
}

function drawBehaviour(b) {
  const sd = $('#sliders');
  if (!sd.innerHTML) {
    SL.forEach(([k, n, u, mn, mx, st, dv]) => sd.appendChild(el('div', { style: 'margin:6px 0' }, `<div class="row small"><span>${n}</span><span class="sp"></span><b id="sv_${k}">${dv}</b>&nbsp;<span class="muted">${u}</span></div><input type="range" class="range" id="s_${k}" min="${mn}" max="${mx}" step="${st}" value="${dv}">`)));
    SL.forEach(([k]) => $('#s_' + k).oninput = e => $('#sv_' + k).textContent = e.target.value);
  }
  const d = b.delta_vs_baseline, sgn = v => (v >= 0 ? '+' : '') + fmt(v, 1);
  $('#behStatus').innerHTML = `<div class="small">Sleep ${sgn(d.sleep)} h · Stress ${sgn(d.stress)} · Mood ${sgn(d.mood)} · Fatigue ${sgn(d.fatigue)} vs own first 7 entries</div><div style="margin-top:6px">${chip(b.status_cls, esc(b.status))}</div>${b.recommendation ? `<p class="small" style="margin:6px 0 0">"${esc(b.recommendation.text)}" (${b.recommendation.rule_id})</p>` : ''}`;
  const h = b.history, xs = h.map(x => 'E' + x.entry), base = h.slice(0, 7);
  lineChart($('#cvSleep'), { x: xs, series: [{ name: 'Sleep', y: h.map(x => x.sleep), color: css('--blue'), dots: true, unit: 'h' }], band: xs.map(() => [Math.min(...base.map(x => x.sleep)), Math.max(...base.map(x => x.sleep))]), xticks: 5 });
  lineChart($('#cvStress'), { x: xs, series: [{ name: 'Stress', y: h.map(x => x.stress), color: css('--orange'), dots: true, dec: 0 }], ymin: 1, ymax: 5, xticks: 5 });
  lineChart($('#cvMood'), { x: xs, series: [{ name: 'Mood', y: h.map(x => x.mood), color: css('--aqua'), dots: true, dec: 0 }], ymin: 1, ymax: 5, xticks: 5 });
  const rx = b.reaction;
  if (rx.latest_ms && !$('#pvtOut').dataset.live) $('#pvtOut').innerHTML = `Last saved median <b>${rx.latest_ms} ms</b>${rx.baseline_ms ? ` · own baseline ${rx.baseline_ms} ms` : ''} ${pb('MEASURED')}<br><span class="muted">${esc(rx.note)}</span>`;
}

function initBodyControls() {
  $('#saveCheck').onclick = async () => {
    const e = {}; SL.forEach(([k]) => e[k] = +$('#s_' + k).value);
    try { const b = await API.post('/selfreport/' + S.persona, e); drawBehaviour(b); toast('<b>Entry saved</b><br><span class="small">Self-reported · compared with your first 7 entries.</span>'); }
    catch (err) { toast('<b>Not saved</b><br>' + esc(err.message)); }
  };
  $('#bmdBtn').onclick = async () => {
    const pre = +$('#bmdPre').value, now = +$('#bmdNow').value;
    if (!(pre > 0 && now > 0)) return toast('<b>Enter both scans</b><br><span class="small">Pre-flight and latest BMD in g/cm².</span>');
    try { drawBone(await API.post('/bone/' + S.persona, { site: $('#boneSite').value, preflight: pre, latest: now })); } catch (err) { toast('<b>Not saved</b><br>' + esc(err.message)); }
  };
  $('#bmdClear').onclick = async () => drawBone(await API.post('/bone/' + S.persona, { clear: true }));
  // reaction test
  const box = $('#pvt'), out = $('#pvtOut'); let trials = [], state = 'idle', t0 = 0, to = null;
  const next = () => { state = 'wait'; box.className = 'pvt'; box.textContent = 'Wait for green…'; to = setTimeout(() => { state = 'go'; box.className = 'pvt go'; box.textContent = 'CLICK!'; t0 = performance.now(); }, 1200 + Math.random() * 2200); };
  const hit = async () => {
    if (state === 'idle') { trials = []; out.dataset.live = '1'; next(); return; }
    if (state === 'wait') { clearTimeout(to); box.className = 'pvt early'; box.textContent = 'Too early · retrying'; setTimeout(next, 800); return; }
    if (state === 'go') {
      const rt = Math.round(performance.now() - t0); trials.push(rt); out.innerHTML = `Trial ${trials.length}: <b>${rt} ms</b>`;
      if (trials.length >= 5) {
        state = 'idle'; box.className = 'pvt'; box.textContent = 'Done · click to repeat';
        try { const r = await API.post('/reaction/' + S.persona, { trials_ms: trials });
          out.innerHTML = `Median reaction time <b>${r.latest_ms} ms</b> (${trials.join(', ')} ms) ${pb('MEASURED')}${r.baseline_ms ? `<br>Own baseline (first 3 runs): ${r.baseline_ms} ms${r.change_ms != null ? ` · change ${r.change_ms > 0 ? '+' : ''}${r.change_ms} ms` : ''}` : ''}<br><span class="muted">${esc(r.note)}</span>`;
        } catch (err) { out.innerHTML = `<span class="err">${esc(err.message)}</span>`; }
      } else next();
    }
  };
  box.onclick = hit; box.onkeydown = e => { if (e.key === ' ' || e.key === 'Enter') { e.preventDefault(); hit(); } };
}
