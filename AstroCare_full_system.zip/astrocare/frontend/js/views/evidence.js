"use strict";
RENDER.evidence = async function () {
  const types = S.meta.status_types;
  $('#stLegend').innerHTML = Object.entries(types).map(([k, v]) => `<span>${pb(k)} <span class="small muted">${esc(v)}</span></span>`).join('');
  $('#evTable').innerHTML = '<tr><th>ID</th><th>Supports</th><th>Source</th><th>What it supports</th><th>Access</th></tr>' + EVID.map(e =>
    `<tr id="ev_${e.id}" class="${S.hlEv === e.id ? 'hl' : ''}"><td><b>${e.id}</b></td><td>${e.supports.map(esc).join(', ')}</td><td>${e.link ? `<a href="${e.link}" target="_blank" rel="noopener">${esc(e.source)} ↗</a>` : esc(e.source)}</td><td>${esc(e.what)}</td><td>${esc(e.access)}</td></tr>`).join('');
  if (S.hlEv) { const row = document.getElementById('ev_' + S.hlEv); if (row) row.scrollIntoView({ block: 'center' }); setTimeout(() => { S.hlEv = null; }, 100); }
  const sid = subject();
  try {
    const r = await API.get('/indicators/' + sid, { day: S.day, location: S.shield });
    $('#provWho').textContent = `${sid}${r.kind === 'mission' ? ' · day ' + r.day : ' · Inspiration4'}`;
    $('#provCount').textContent = `${r.n} records`;
    $('#provTable').innerHTML = '<tr><th>Indicator</th><th>Value</th><th>Status type</th><th>Source</th><th>Method</th><th>Window</th><th>Module</th></tr>' +
      r.records.map(p => `<tr><td>${esc(p.indicator)}</td><td><b>${esc(p.value ?? '–')}</b> ${esc(p.unit)}</td><td>${pb(p.status_type)}</td><td>${esc(p.source)}</td><td>${esc(p.method)}</td><td>${esc(p.validity_window)}</td><td>${esc(p.module)}</td></tr>`).join('');
  } catch (e) { showErr($('#provTable'), e); }
};

RENDER.about = async function () {
  if ($('#gateTable').innerHTML) return;
  try {
    const r = await API.get('/about');
    $('#gateTable').innerHTML = '<tr><th>Domain</th><th>Human data found</th><th>Tier</th><th>Component</th></tr>' + r.evidence_gate.map(x => `<tr>${x.map(c => `<td>${esc(c)}</td>`).join('')}</tr>`).join('');
  } catch (e) { showErr($('#gateTable'), e); }
};
