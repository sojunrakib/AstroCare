"use strict";
/* Boot: load metadata + evidence registry from the backend, build tabs, start on the URL hash. */
(async function boot() {
  const tabs = $('#tabs');
  VIEWS.forEach(([id, n]) => { const b = el('button', { 'data-v': id }, n); b.onclick = () => go(id); tabs.appendChild(b); });
  try {
    S.meta = await API.get('/meta');
    EVID = (await API.get('/evidence')).evidence;
  } catch (e) {
    document.querySelector('main').insertAdjacentHTML('afterbegin', `<div class="err" style="margin-bottom:14px"><b>Backend not reachable.</b> Start it with <code>python run.py</code> in the project folder, then open <a href="http://127.0.0.1:8000">http://127.0.0.1:8000</a>. Opening index.html directly from disk will not work. (${esc(e.message)})</div>`);
    return;
  }
  document.title = `${S.meta.app} Crew Health Console`;
  $('#appname').textContent = S.meta.app; $('#herotitle').textContent = S.meta.app; $('#appsub').textContent = S.meta.subtitle.toUpperCase();
  $('#foot').textContent = `${S.meta.app} v${S.meta.version} · ${S.meta.project} · NASA Space Apps Challenge 2026 · not for clinical use`;
  S.day = S.meta.mission.default_day;
  $('#who').onchange = () => { const v = $('#who').value; if (crewKind() === 'i4') S.i4 = v; else S.persona = v; S.selFlag = null; render(); };
  initConsoleControls(); initBodyControls();
  window.addEventListener('hashchange', () => { const v = location.hash.slice(1); if (v && v !== S.view) go(v); });
  window.addEventListener('resize', () => { clearTimeout(window._rz); window._rz = setTimeout(() => { if (S.view !== 'home') render(); }, 200); });
  const start = location.hash.slice(1);
  go(VIEWS.some(v => v[0] === start) ? start : 'home');
})();
