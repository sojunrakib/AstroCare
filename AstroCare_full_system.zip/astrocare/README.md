# AstroCare: Crew Health Console (HomeBound · NASA Space Apps 2026)

The full system built from the AstroCare prototype: a Python backend (M1–M9 modules, rule engine, provenance),
a frontend with 12 pages, and a test suite. It runs offline and needs no internet.

---

## দ্রুত শুরু (VS Code-এ)

**ধাপ ১ — ফোল্ডার খুলুন**
zip ফাইলটা extract করুন। তারপর VS Code-এ **File → Open Folder** দিয়ে `astrocare` ফোল্ডারটা খুলুন।

**ধাপ ২ — Python আছে কিনা দেখুন**
VS Code-এ Terminal খুলুন (**Terminal → New Terminal**), তারপর লিখুন:
```
python --version
```
Python 3.9 বা তার নতুন সংস্করণ লাগবে। Windows-এ `python` কাজ না করলে `py` লিখে দেখুন।

**ধাপ ৩ — চালান (কিছু install করার দরকার নেই)**
```
python run.py
```
ব্রাউজারে নিজে থেকেই **http://127.0.0.1:8000** খুলবে। না খুললে লিংকটা কপি করে ব্রাউজারে বসান।
বন্ধ করতে Terminal-এ **Ctrl + C** চাপুন।

**ধাপ ৪ (ঐচ্ছিক) — FastAPI দিয়ে চালান**
```
pip install -r requirements.txt
python run.py
```
তখন **http://127.0.0.1:8000/docs**-এ সব API নিজে হাতে পরীক্ষা করার পাতা পাবেন।
FastAPI install না থাকলে `run.py` নিজে থেকেই Python-এর built-in server ব্যবহার করে। দুটোর API হুবহু এক।

**ধাপ ৫ — টেস্ট চালান**
```
python -m unittest discover -s backend/tests -v
```
সব টেস্ট `OK` দেখাবে (26টা)।

VS Code-এর **Run and Debug** প্যানেলেও তিনটা তৈরি করা কমান্ড আছে: server চালানো, টেস্ট চালানো, আর simulated vitals আবার তৈরি করা।

> মনে রাখবেন: `index.html` সরাসরি double-click করে খুললে কাজ করবে না। পাতাগুলো backend থেকে ডেটা আনে, তাই আগে `python run.py` চালু থাকতে হবে।

### M6, M7, M8 কীভাবে কাজ করে
M7 (Immune) আর M6 (Recovery) এখন অ্যাপের ভেতরেই rule দিয়ে হিসাব হয়, NASA OSDR-এর আসল lab ডেটা থেকে (`backend/data/i4/`)।
M8 (Telomere) প্রকাশিত গবেষণাপত্রের context card, কারণ প্রতি crew-এর telomere মান কোথাও প্রকাশিত নেই।
ডেটা কোথা থেকে এসেছে আর কীভাবে যাচাই করা হয়েছে, তা `backend/data/i4/SOURCES.md`-এ লেখা আছে।
আপনার Drive-এ OSDR থেকে নামানো একই নামের ফাইল থাকলে সেগুলো দিয়ে বদলে দিন, তারপর টেস্ট চালান।

---

## Data source of each module

| Part | Data | Status type |
|---|---|---|
| M1 storm forecaster | Real model + real 2024–2026 test-set predictions (DONKI / GOES) | ML_PREDICTED |
| M2 dose | GCR rate from MSL/RAD (1.8 mSv/day); storm term uses an uncalibrated demo coefficient | ESTIMATED |
| M3 biodosimeter | Real models (OSD-1012, OSD-410) and real validation; demo blood profiles are synthetic | ML_PREDICTED on TELEMETRY input |
| M4 microbiome | Real Inspiration4 cards, classifier summary and figures (OSD-572) | DERIVED |
| M5 brain | Context text only (mouse studies) | CONTEXT |
| M7 immune | Real OSDR lab panels (Eve 71-plex, NULISA 203-target, CBC); rule M7-DEV-v1 computed in the app | DERIVED |
| M6 recovery | Same panels + CMP + Eve cardiovascular; rule M6-TRAJ-v2 computed in the app | DERIVED |
| M8 telomere | Published statements (Garcia-Medina et al. 2024); no per-crew values exist | CONTEXT |
| M9 vitals | Simulated personas SIM-A to SIM-D; rule M9-FLAG-v1 from the notebook | TELEMETRY |
| Behaviour, reaction test, bone | Entered in the app (14 simulated history entries per persona) | SELF_REPORTED / MEASURED |

The two kinds of subject are never mixed. Mission personas (SIM-A to SIM-D) drive Console, Radiation, Blood and
Body & Mind. Inspiration4 crew (C001 to C004, real) drive Microbiome, Immune, Telomere and Recovery. The crew
selector and the banner switch automatically with the page.

### About the M9 telemetry
The M9 notebook shipped only its 14 flag cards, not the daily series. `backend/tools/simulate_vitals.py` rebuilds
the series: it uses the medians and MADs printed in the cards, places every flagged value on its mission day, and
keeps the SIM-A HRV dip and the SIM-C data gap from the notebook plots. It then picks seeds until the rule reproduces
**exactly the notebook's 14 flags and no others** (checked by a test). The individual z-values differ slightly from
the notebook (for example 4.44 instead of 4.99), because the surrounding noise is regenerated. To use your real
notebook series, export it as `backend/data/m9/m9_vitals_daily.csv` with the columns
`crew_id, mission_day, date, measure, value` (measure = hr / hrv / spo2 / rr).

---

## Architecture

```
astrocare/
├── run.py                       start here (FastAPI if installed, else built-in server)
├── requirements.txt             optional: fastapi, uvicorn, numpy
├── backend/
│   ├── app/
│   │   ├── config.py            app name, paths, port  (rename the product here)
│   │   ├── routes.py            ONE route table used by both servers
│   │   ├── server_fastapi.py    FastAPI app (/docs)
│   │   ├── server_stdlib.py     zero-install server
│   │   ├── provenance.py        indicator record + the 7 status types
│   │   ├── indicators.py        every displayed value for a subject
│   │   ├── store.py             cached file loading, runtime storage
│   │   ├── modules/
│   │   │   ├── m1_storm.py      calibrated logistic regression (coefficients exported from joblib)
│   │   │   ├── m2_dose.py       physics estimate
│   │   │   ├── m3_blood.py      pure-Python port of m3_predict.py + window rule
│   │   │   ├── m9_vitals.py     M9-FLAG-v1, M9-MULTI-v1, M9-Q01
│   │   │   ├── i4_lab.py        M7-DEV-v1 and M6-TRAJ-v2 rules on the lab panels
│   │   │   ├── inspiration4.py  M4, M5, M6, M7, M8 pages
│   │   │   ├── body_mind.py     self-report, reaction test, bone
│   │   │   └── context.py       mission timeline, cabin CO2
│   │   └── rules/action_engine.py   R01–R99 recommendations
│   ├── data/
│   │   ├── reference/           rules_v1.json, evidence_registry.json, mission.json
│   │   ├── m1/ m3/ m4/ m9/      your delivered files (originals kept)
│   │   ├── i4/                  Inspiration4 lab panels (OSD-575, OSD-569) + SOURCES.md + checksums
│   │   ├── cards/               optional notebook cards m6/m7/m8 (shown next to the app's own result)
│   │   └── runtime/             self-reports, scans, reaction tests (created at run time)
│   ├── tools/simulate_vitals.py
│   └── tests/test_system.py     26 tests
└── frontend/
    ├── index.html               12 pages, same design as the prototype
    ├── css/app.css
    ├── js/core.js charts.js hero3d.js app.js
    ├── js/views/*.js            one file per page
    ├── js/vendor/three.min.js   Three.js r149 (from the prototype)
    └── assets/img/              M4 and M9 notebook figures
```

Flow: data files → module (model / rule / context) → indicator record with status_type → explanation → action engine → page.

### API (all GET unless marked)
| Endpoint | Returns |
|---|---|
| `/api/meta`, `/api/crew`, `/api/health` | App info, personas, Inspiration4 crew |
| `/api/mission/{persona}/context?day=` | Phase, gravity, isolation, cabin CO2 |
| `/api/vitals/{persona}?day=` | Daily series, baseline bands, flags, data-quality notes |
| `/api/vitals/{persona}/flags`, `/live`, `/api/vitals/rules` | Flag cards, live HR samples, rule table |
| `/api/radiation/m1/summary`, `/storms`, `/timeline?around=` | Real M1 metrics, 21 test storms, replay |
| `POST /api/radiation/m1/predict` `{"flare_class":"X1.0"}` | Live M1 forecast |
| `/api/radiation/forecast?day=`, `/api/radiation/{persona}/dose?day=&location=` | Mission M1 and M2 |
| `/api/blood/info`, `POST /api/blood/predict` | M3 validation data; prediction (demo profile or your own JSON) |
| `/api/microbiome/{crew}`, `/api/immune/{crew}`, `/api/telomere/{crew}`, `/api/recovery/{crew}`, `/api/brain` | Inspiration4 modules |
| `/api/selfreport/{persona}` (GET/POST), `POST /api/reaction/{persona}`, `/api/bone/{persona}` (GET/POST) | Body & Mind |
| `/api/actions/{subject}?day=` | Recommendations with rule ID and reason |
| `/api/indicators/{subject}?day=` | All provenance records |
| `/api/evidence`, `/api/evidence/{id}`, `/api/rules`, `/api/about` | Registry, rule set, evidence gate |

### Rules
- **M9-FLAG-v1**: modified z = 0.6745 × (today − median of the previous 30 days) ÷ MAD; flag at |z| ≥ 3.5 with ≥ 21 valid days (Iglewicz & Hoaglin 1993). SpO2 flags are shown but never alert.
- **M9-MULTI-v1**: two or more alert-enabled vitals flagged on the same day.
- **M3 window rule (R02)**: estimates only at 1 h, 2 h or 6 h (±0.5 h), or 20–28 h, and only with the person's own baseline sample. The 24 h model resolves 0.1–2 Gy; readings are X-ray-equivalent (neutrons over-read about 2.6×).
- **M7-DEV-v1**: per panel, z = (value − own pre-flight mean) ÷ (pooled within-person pre-flight SD × √(1 + 1/n)). The threshold k is the 95th percentile of leave-one-out pre-flight |z|, so about 5% of pre-flight samples would be flagged (measured: 5.0–5.6%). A crew × timepoint counts as changed when more analytes are flagged than expected (one-sided binomial p < 0.05). Eve panels use log2 concentrations; NULISA NPQ is already log2, and its zero values are treated as missing. The race-coded eGFR fields are not used.
- **M6-TRAJ-v2**: every analyte flagged at R+1 is followed to R+45, R+82 and R+194; it counts as back when |z| ≤ k.
- **Action rules R01–R99**: texts and triggers in `backend/data/reference/rules_v1.json`. A test checks that no recommendation contains diagnostic or medication wording.

### Comparison with the team notebooks
| Result | Notebook | This app |
|---|---|---|
| M7: Eve panel above chance at R+82 | C001 and C002 only (11/71 vs 3.6) | C001 13/71 and C002 12/71; C003/C004 not above chance |
| M7: other panels | not reported above chance | also above chance: C002 Eve R+194; NULISA C001 R+1 and R+82, C003 R+194; Eve cardiovascular C002 R+1; CMP C003 R+45 (several are borderline, p ≈ 0.04–0.05) |
| NULISA zero values | 137 | 4 in this serum file (the notebook may have included urine or another file version) |
| M6: R+1 changes back | 35 of 39 | 34 of 46 by R+82 (74%) |

### Points for the team to check
1. M1 in these files is the **flare-size baseline model** (test 2024–2026: 14 of 21 storms, 247 false alerts). That replaces the 3-feature model described in the 6 Nov progress log.
2. M2's storm coefficient and shielding factors are placeholders until calibrated against MSL/RAD storm data.
3. The Inspiration4 lab files came from public GitHub mirrors (cross-checked, see `backend/data/i4/SOURCES.md`); please compare with your own OSDR downloads.
4. Telomere paper: first author confirmed as Garcia-Medina (Precision Clinical Medicine 2024).
5. The urine panel (OSD-656) is not included.
6. The product name is set in `backend/app/config.py` (`APP_NAME`).

Not for clinical use. Nothing is diagnosed.
