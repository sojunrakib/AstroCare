"""Recreate the M9 demo telemetry (SIMULATED_DEMO) so the console can replay it.

The team's M9 notebook shipped only the flag cards (data/m9/m9_cards.json), not the daily series.
This script rebuilds 4 personas x 4 vitals x 90 mission days with:
  * baseline level and spread taken from the medians / MADs printed in the cards,
  * every flagged value from the cards placed on its exact mission day,
  * the scripted SIM-A HRV dip (days 20-23) and the SIM-C data gap (days 4-17) seen in the notebook plots.
It then searches for random seeds until the M9 rule reproduces exactly the notebook's 14 flags.

Run:  python backend/tools/simulate_vitals.py
If you export the real notebook series (columns: crew_id, mission_day, date, measure, value),
save it as backend/data/m9/m9_vitals_daily.csv and skip this script.
"""
import csv
import json
import os
import random
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))

from app.modules import context as ctx  # noqa: E402
from app.modules import m9_vitals as m9  # noqa: E402
from app.config import data_path  # noqa: E402

# level (median) and MAD per persona and measure; values from m9_cards.json where printed, else read off the notebook plot
PARAMS = {
    "SIM-A": {"hr": (58.5, 1.6), "hrv": (62.4, 3.9), "spo2": (97.33, 0.25), "rr": (13.4, 0.47)},
    "SIM-B": {"hr": (65.03, 1.37), "hrv": (45.0, 3.6), "spo2": (96.74, 0.23), "rr": (15.0, 0.45)},
    "SIM-C": {"hr": (72.0, 1.8), "hrv": (37.8, 2.41), "spo2": (96.8, 0.35), "rr": (16.16, 0.31)},
    "SIM-D": {"hr": (61.0, 1.3), "hrv": (57.0, 3.5), "spo2": (97.65, 0.27), "rr": (13.0, 0.5)},
}
OFFSET = {"SIM-A": 11, "SIM-B": 23, "SIM-C": 37, "SIM-D": 41}
GAPS = {"SIM-C": range(4, 18)}
SCRIPTED = {("SIM-A", "hrv", 22): 39.3, ("SIM-A", "hrv", 23): 38.9}  # recovery after the injected dip (not flagged)


def card_targets():
    cards = json.load(open(data_path("m9", "m9_cards.json"), encoding="utf-8"))
    t = {}
    for c in cards:
        key = m9.NAME_TO_KEY[c["measure"]]
        t[(c["crew_id"], key, int(c["mission_day"]))] = float(c["value"].split()[0])
    return t


def build(persona, seed, targets):
    r = random.Random(seed)
    out = {}
    for k, (level, md) in PARAMS[persona].items():
        sd = md / 0.6745
        s = {}
        for d in ctx.mission_days():
            if persona in GAPS and d in GAPS[persona]:
                s[d] = None
                continue
            v = level + sd * r.gauss(0, 1)
            v = max(level - 2.9 * sd, min(level + 2.9 * sd, v))  # keep noise inside the normal range
            s[d] = round(v, 2)
        for (p, kk, d), v in list(targets.items()) + list(SCRIPTED.items()):
            if p == persona and kk == k:
                s[d] = v
        out[k] = s
    return out


def matches(persona, data, targets):
    want = {(k, d) for (p, k, d) in targets if p == persona}
    got = set()
    for k, s in data.items():
        for d, res in m9.evaluate(s).items():
            if res["flag"]:
                got.add((k, d))
    return got == want, got, want


def main():
    targets = card_targets()
    rows = []
    for persona in PARAMS:
        for seed in range(1, 20000):
            data = build(persona, seed * 97 + OFFSET[persona], targets)
            ok, got, want = matches(persona, data, targets)
            if ok:
                print(f"{persona}: seed {seed} reproduces {len(want)} notebook flags")
                break
        else:
            raise SystemExit(f"no seed found for {persona}")
        for k, s in data.items():
            for d in ctx.mission_days():
                v = s[d]
                rows.append({"crew_id": persona, "mission_day": d, "date": ctx.date_for_day(d), "measure": k,
                             "value": "" if v is None else round(v, 2), "is_simulated": True})
    path = data_path("m9", "m9_vitals_daily.csv")
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)
    print("wrote", path, len(rows), "rows")


if __name__ == "__main__":
    main()
