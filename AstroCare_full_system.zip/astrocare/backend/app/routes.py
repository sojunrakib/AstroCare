"""One route table, used by both the FastAPI server and the zero-install standard-library server.

Each handler gets (path_params, query, body) and returns a JSON-serialisable dict or list.
"""
import re

from . import config, indicators, store
from .provenance import STATUS_TYPES
from .modules import body_mind, context as ctx, inspiration4 as i4, m1_storm, m2_dose, m3_blood, m9_vitals
from .rules import action_engine


class ApiError(Exception):
    def __init__(self, status, message):
        super().__init__(message)
        self.status = status
        self.message = message


def _persona(pid):
    if pid not in m9_vitals.persona_ids():
        raise ApiError(404, f"unknown mission persona {pid} (expected one of {m9_vitals.persona_ids()})")
    return pid


def _i4(cid):
    if cid not in i4.CREW:
        raise ApiError(404, f"unknown Inspiration4 crew id {cid} (expected one of {i4.CREW})")
    return cid


def _day(q):
    try:
        return ctx.clamp_day(q.get("day"))
    except (TypeError, ValueError):
        raise ApiError(400, "day must be an integer mission day")


# ---------------------------------------------------------------- handlers
def meta(p, q, b):
    m = store.mission()
    return {"app": config.APP_NAME, "subtitle": config.APP_SUBTITLE, "project": config.PROJECT_NAME, "version": config.VERSION,
            "mission": m, "mission_days": ctx.mission_days(), "personas": m["personas"], "i4_crew": m["i4_crew"],
            "status_types": STATUS_TYPES, "rules_version": store.rules()["version"]}


def health(p, q, b):
    return {"status": "ok", "app": config.APP_NAME, "version": config.VERSION}


def crew(p, q, b):
    m = store.mission()
    return {"mission_personas": [{**x, "is_simulated": True, "kind": "mission"} for x in m["personas"]],
            "inspiration4_crew": [{**x, "is_simulated": False, "kind": "inspiration4"} for x in m["i4_crew"]]}


def mission_context(p, q, b):
    return ctx.context(_persona(p["crew_id"]), _day(q))


def vitals(p, q, b):
    return m9_vitals.daily(_persona(p["crew_id"]), _day(q))


def vitals_flags(p, q, b):
    pid = _persona(p["crew_id"])
    upto = _day(q) if q.get("day") is not None else None
    return {"crew_id": pid, "flags": m9_vitals.flags(pid, upto), "multi_flags": m9_vitals.multi_flags(pid, upto)}


def vitals_live(p, q, b):
    return m9_vitals.live(_persona(p["crew_id"]), _day(q))


def vitals_rules(p, q, b):
    return {"rules": m9_vitals.rules_table(), "notebook_cards": store.load_json("m9", "m9_cards.json")}


def m1_summary(p, q, b):
    return m1_storm.summary()


def m1_storms(p, q, b):
    return {"storms": m1_storm.storms()}


def m1_timeline(p, q, b):
    return m1_storm.timeline(q.get("start"), q.get("end"), q.get("around"), int(q.get("days", 4)))


def m1_predict(p, q, b):
    b = b or {}
    try:
        return m1_storm.predict(flare=b.get("flare_class") or q.get("flare_class"),
                                log10_flux=b.get("log10_peak_flux") if b.get("log10_peak_flux") is not None else None)
    except (ValueError, TypeError) as e:
        raise ApiError(400, str(e))


def m1_mission(p, q, b):
    return m1_storm.mission_forecast(_day(q))


def dose(p, q, b):
    try:
        return m2_dose.estimate(_persona(p["crew_id"]), _day(q), q.get("location", "habitat"))
    except ValueError as e:
        raise ApiError(400, str(e))


def blood_info(p, q, b):
    return {**m3_blood.validation(), "demo_profiles": m3_blood.demo_profiles()}


def blood_predict(p, q, b):
    b = b or {}
    hours = b.get("hours_since_exposure", q.get("hours"))
    try:
        hours = float(hours)
    except (TypeError, ValueError):
        raise ApiError(400, "hours_since_exposure (number) is required")
    if b.get("demo_profile"):
        try:
            return m3_blood.predict_demo(b["demo_profile"], hours)
        except KeyError:
            raise ApiError(404, "unknown blood profile")
    exposed, baseline = b.get("exposed"), b.get("baseline")
    if not isinstance(exposed, dict):
        raise ApiError(400, "send exposed {probe_id: log2 value} and baseline {probe_id: log2 value}, or demo_profile")
    res = m3_blood.predict(exposed, baseline or {}, hours)
    res["is_simulated"] = False
    return res


def i4_microbiome(p, q, b):
    return i4.microbiome(_i4(p["crew_id"]))


def i4_immune(p, q, b):
    return i4.immune(_i4(p["crew_id"]))


def i4_telomere(p, q, b):
    return i4.telomere(_i4(p["crew_id"]))


def i4_calibration(p, q, b):
    from .modules import i4_lab
    return {"panels": i4_lab.calibration_report(), "m6_all_crew": {k: v for k, v in i4_lab.m6().items() if k != "changes"}}


def i4_recovery(p, q, b):
    return i4.recovery(_i4(p["crew_id"]))


def brain(p, q, b):
    return i4.brain_context()


def selfreport_get(p, q, b):
    return body_mind.behaviour(_persona(p["crew_id"]))


def selfreport_post(p, q, b):
    try:
        return body_mind.add_entry(_persona(p["crew_id"]), b or {})
    except (ValueError, TypeError) as e:
        raise ApiError(400, str(e))


def reaction_post(p, q, b):
    try:
        return body_mind.add_reaction(_persona(p["crew_id"]), (b or {}).get("trials_ms", []))
    except (ValueError, TypeError) as e:
        raise ApiError(400, str(e))


def bone_get(p, q, b):
    return body_mind.bone(_persona(p["crew_id"]), _day(q))


def bone_post(p, q, b):
    b = b or {}
    pid = _persona(p["crew_id"])
    if b.get("clear"):
        return body_mind.clear_bone(pid)
    try:
        return body_mind.set_bone(pid, b.get("site", "Lumbar spine"), b.get("preflight"), b.get("latest"))
    except (ValueError, TypeError) as e:
        raise ApiError(400, str(e))


def actions(p, q, b):
    try:
        return action_engine.actions(p["subject_id"], q.get("day"), q.get("location", "habitat"))
    except KeyError:
        raise ApiError(404, "unknown subject")


def indicator_records(p, q, b):
    try:
        return indicators.indicators(p["subject_id"], q.get("day"), q.get("location", "habitat"))
    except KeyError:
        raise ApiError(404, "unknown subject")


def evidence_list(p, q, b):
    return {"evidence": store.evidence(), "status_types": STATUS_TYPES}


def evidence_one(p, q, b):
    e = next((x for x in store.evidence() if x["id"] == p["evidence_id"]), None)
    if not e:
        raise ApiError(404, "unknown evidence id")
    return e


def rules_all(p, q, b):
    return store.rules()


def about(p, q, b):
    gate = [
        ["Solar storm forecasting", "DONKI + GOES event history (2010-2026)", "Tier 1 · ML", "M1"],
        ["Crew dose", "MSL/RAD background rate; storm term uncalibrated", "Estimate", "M2"],
        ["Blood radiation response", "OSD-1012 (24 h), OSD-410 (1/2/6 h); OSD-71 external test failed", "Tier 1 · ML", "M3"],
        ["Microbiome", "OSD-572 swabs (4 crew), Tier A sites", "Tier 2 · trend", "M4"],
        ["Brain", "Mouse OSD-611/374/479 only", "Tier 3 · context", "M5"],
        ["Recovery", "OSD-575 + OSD-569 lab panels to R+194 (rule M6-TRAJ-v2)", "Tier 2 · trend", "M6"],
        ["Immunology", "OSD-575 Eve + NULISA, OSD-569 CBC (4 crew; rule M7-DEV-v1); urine OSD-656 not included", "Tier 2 · trend", "M7"],
        ["Telomere", "Garcia-Medina et al. 2024; no per-crew values", "Tier 3 · context", "M8"],
        ["Vitals", "Mission telemetry; rule from Iglewicz & Hoaglin 1993", "Tier 4 · rules", "M9"],
        ["Bone", "Published recovery parameters; scans if entered", "Tier 3 · context", "Bone panel"],
        ["Behaviour", "Self-report + in-app reaction test", "Tier 4 · self-report", "Behaviour panel"],
    ]
    return {"evidence_gate": gate, "evidence": store.evidence()}


# ---------------------------------------------------------------- table
ROUTES = [
    ("GET", "/api/health", health), ("GET", "/api/meta", meta), ("GET", "/api/crew", crew),
    ("GET", "/api/mission/{crew_id}/context", mission_context),
    ("GET", "/api/vitals/rules", vitals_rules),
    ("GET", "/api/vitals/{crew_id}", vitals), ("GET", "/api/vitals/{crew_id}/flags", vitals_flags),
    ("GET", "/api/vitals/{crew_id}/live", vitals_live),
    ("GET", "/api/radiation/m1/summary", m1_summary), ("GET", "/api/radiation/m1/storms", m1_storms),
    ("GET", "/api/radiation/m1/timeline", m1_timeline), ("POST", "/api/radiation/m1/predict", m1_predict),
    ("GET", "/api/radiation/forecast", m1_mission), ("GET", "/api/radiation/{crew_id}/dose", dose),
    ("GET", "/api/blood/info", blood_info), ("POST", "/api/blood/predict", blood_predict),
    ("GET", "/api/microbiome/{crew_id}", i4_microbiome), ("GET", "/api/immune/{crew_id}", i4_immune),
    ("GET", "/api/telomere/{crew_id}", i4_telomere), ("GET", "/api/recovery/{crew_id}", i4_recovery),
    ("GET", "/api/brain", brain), ("GET", "/api/i4/calibration", i4_calibration),
    ("GET", "/api/selfreport/{crew_id}", selfreport_get), ("POST", "/api/selfreport/{crew_id}", selfreport_post),
    ("POST", "/api/reaction/{crew_id}", reaction_post),
    ("GET", "/api/bone/{crew_id}", bone_get), ("POST", "/api/bone/{crew_id}", bone_post),
    ("GET", "/api/actions/{subject_id}", actions), ("GET", "/api/indicators/{subject_id}", indicator_records),
    ("GET", "/api/evidence", evidence_list), ("GET", "/api/evidence/{evidence_id}", evidence_one),
    ("GET", "/api/rules", rules_all), ("GET", "/api/about", about),
]

_COMPILED = [(m, re.compile("^" + re.sub(r"\{(\w+)\}", r"(?P<\1>[^/]+)", path) + "$"), h, path) for m, path, h in ROUTES]


def match(method, path):
    """Returns (handler, path_params) or raises ApiError. Literal routes win over parameter routes (table order)."""
    allowed = False
    for m, rx, h, _ in _COMPILED:
        mm = rx.match(path)
        if mm:
            if m == method:
                return h, mm.groupdict()
            allowed = True
    raise ApiError(405 if allowed else 404, "method not allowed" if allowed else f"no route {path}")


def dispatch(method, path, query, body):
    h, params = match(method, path)
    return h(params, query, body)
