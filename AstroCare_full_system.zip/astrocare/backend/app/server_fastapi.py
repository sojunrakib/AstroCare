"""FastAPI server (recommended). Interactive API docs at /docs. Start with:  python run.py
or:  uvicorn backend.app.server_fastapi:app --reload
"""
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from . import config
from .routes import ROUTES, ApiError

app = FastAPI(title=f"{config.APP_NAME} API", version=config.VERSION,
              description="Crew health console backend: M1-M9 modules, rule engine, provenance. "
                          "Every response carries status_type / is_simulated.")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])


def _make_endpoint(handler, method):
    async def endpoint(request: Request):
        body = None
        if method == "POST":
            try:
                body = await request.json()
            except Exception:  # noqa: BLE001
                body = {}
        try:
            return handler(dict(request.path_params), dict(request.query_params), body)
        except ApiError as e:
            return JSONResponse({"detail": e.message}, status_code=e.status)
    endpoint.__name__ = f"{method.lower()}_{handler.__name__}"
    endpoint.__doc__ = handler.__doc__
    return endpoint


for _method, _path, _handler in ROUTES:
    app.add_api_route(_path, _make_endpoint(_handler, _method), methods=[_method], name=_handler.__name__)


@app.get("/", include_in_schema=False)
def index():
    return FileResponse(f"{config.FRONTEND_DIR}/index.html")


app.mount("/", StaticFiles(directory=config.FRONTEND_DIR, html=True), name="frontend")
