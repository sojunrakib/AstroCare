"""Provenance: every value the console shows is one indicator record with a status type."""

STATUS_TYPES = {
    "MEASURED": "Directly measured",
    "DERIVED": "Computed from measured values",
    "ML_PREDICTED": "Trained model output (M1, M3)",
    "ESTIMATED": "Physics or approximation",
    "CONTEXT": "Timeline or published parameter",
    "SELF_REPORTED": "Entered by the astronaut",
    "TELEMETRY": "Crew vitals and cabin telemetry stream",
}


def record(indicator, value, status_type, source, method, window="-", unit="", module="", subject="",
           is_simulated=False, rule_id=None, evidence_id=None):
    if status_type not in STATUS_TYPES:
        raise ValueError(f"unknown status type {status_type}")
    if status_type == "TELEMETRY":
        is_simulated = True
    return {
        "indicator": indicator, "value": value, "unit": unit, "status_type": status_type,
        "source": source, "method": method, "validity_window": window, "module": module,
        "subject": subject, "is_simulated": bool(is_simulated), "rule_id": rule_id, "evidence_id": evidence_id,
    }
