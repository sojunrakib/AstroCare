"""Collects every displayed value for a subject as provenance records (the Evidence page table)."""
from .modules import body_mind, context as ctx, inspiration4 as i4, m1_storm, m2_dose, m3_blood, m9_vitals


def indicators(subject_id, day=None, location="habitat"):
    recs = []
    if subject_id in m9_vitals.persona_ids():
        day = ctx.clamp_day(day)
        recs += m9_vitals.daily(subject_id, day)["provenance"]
        recs += ctx.context(subject_id, day)["provenance"]
        recs += m1_storm.mission_forecast(day)["provenance"]
        recs += m2_dose.estimate(subject_id, day, location)["provenance"]
        recs += m3_blood.predict_demo("eva" if m2_dose.persona_by_id(subject_id).get("eva_during_storm") else "habitat", 24)["provenance"]
        recs += body_mind.behaviour(subject_id)["provenance"]
        recs += body_mind.bone(subject_id, day)["provenance"]
        kind = "mission"
    elif subject_id in i4.CREW:
        recs += i4.recovery(subject_id)["provenance"]
        recs += i4.immune(subject_id)["provenance"]
        recs += i4.telomere(subject_id)["provenance"]
        kind = "inspiration4"
    else:
        raise KeyError(subject_id)
    return {"subject": subject_id, "kind": kind, "day": day, "records": recs, "n": len(recs),
            "n_simulated": sum(r["is_simulated"] for r in recs)}
