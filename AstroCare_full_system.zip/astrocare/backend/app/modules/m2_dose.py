"""M2 crew dose estimate (ESTIMATED · physics approximation, not ML).

dose-equivalent rate (mSv/day) = GCR background + SEP term
  * GCR background: 1.8 mSv/day, MSL/RAD cruise measurement (Zeitlin et al. 2013, EV-RAD-MSL)
  * SEP term: k x (>=10 MeV proton flux in pfu) x shielding factor, with k a DEMO coefficient
The SEP coefficient and shielding factors are placeholders until calibrated against MSL/RAD storm data;
the storm flux profile is TELEMETRY. Both are stated on screen.
"""
import math

from .. import store
from ..provenance import record
from . import context as ctx

GCR_MSV_PER_DAY = 1.8
SEP_MSV_PER_PFU_DAY = 0.0006       # DEMO coefficient (uncalibrated): ~1.4 mSv/day at 2400 pfu behind habitat
SHIELD = {"habitat": 1.0, "shelter": 0.35, "eva": 3.5}
SHIELD_LABEL = {"habitat": "Habitat module", "shelter": "Storm shelter", "eva": "EVA (outside)"}
CAREER_LIMIT_MSV = 600


def flux_pfu(day_float):
    """Simulated >=10 MeV proton flux (pfu) on a fractional mission day."""
    st = store.mission()["storm"]
    bg = 0.4
    t = (day_float - st["onset_day"]) * 24.0  # hours since onset
    if t < 0 or day_float <= 0:
        return bg
    return bg + st["peak_pfu"] * (t / 10) ** 2 * math.exp(-t / 10) / 0.54


def hourly_flux(day_from=None, day_to=None):
    st = store.mission()["storm"]
    a = day_from if day_from is not None else st["onset_day"] - 2
    b = day_to if day_to is not None else st["onset_day"] + st["duration_days"] + 1
    pts = []
    h = 0
    while a + h / 24 <= b:
        d = a + h / 24
        pts.append({"day": round(d, 3), "label": f"D{int(math.floor(d))} {int(round((d % 1) * 24)) % 24:02d}h", "pfu": round(flux_pfu(d), 3)})
        h += 2
    return pts


def location_on(persona, day, default):
    st = store.mission()["storm"]
    if persona.get("eva_during_storm") and day == st["onset_day"]:
        return "eva"
    return default


def daily_dose(persona, day, location):
    if day <= 0:
        return 0.0
    loc = location_on(persona, day, location)
    sep_pfu_day = sum(flux_pfu(day + h / 24) for h in range(24)) / 24
    sep = SEP_MSV_PER_PFU_DAY * max(0.0, sep_pfu_day - 0.4) * SHIELD[loc]
    return GCR_MSV_PER_DAY + sep


def series(persona, location="habitat"):
    cum = 0.0
    out = []
    for d in ctx.mission_days():
        dd = daily_dose(persona, d, location)
        cum += dd
        out.append({"day": d, "daily_msv": round(dd, 3), "cumulative_msv": round(cum, 2),
                    "location": SHIELD_LABEL[location_on(persona, d, location)] if d > 0 else "Earth"})
    return out


def persona_by_id(pid):
    for p in store.mission()["personas"]:
        if p["id"] == pid:
            return p
    raise KeyError(pid)


def estimate(persona_id, day, location="habitat"):
    if location not in SHIELD:
        raise ValueError("location must be habitat, shelter or eva")
    p = persona_by_id(persona_id)
    day = ctx.clamp_day(day)
    s = series(p, location)
    today = next(x for x in s if x["day"] == day)
    st = store.mission()["storm"]
    noon = day + 0.5
    f = flux_pfu(noon) if day > 0 else None
    loc_today = location_on(p, day, location)
    rate_usv_h = None if day <= 0 else (GCR_MSV_PER_DAY + SEP_MSV_PER_PFU_DAY * max(0, f - 0.4) * SHIELD[loc_today]) * 1000 / 24
    if f is not None and f >= 10:
        status = {"cls": "st-serious", "text": "Elevated: particle event in progress (S1+)"}
    elif st["onset_day"] - 2 <= day < st["onset_day"]:
        status = {"cls": "st-warn", "text": "Watch: M1 alert for the coming 48 h"}
    else:
        status = {"cls": "st-good", "text": "Background (galactic cosmic rays)" if day > 0 else "On Earth"}
    all_crew = {q["id"]: series(q, location) for q in store.mission()["personas"]}
    prov = [
        record("Dose rate", round(rate_usv_h, 1) if rate_usv_h else None, "ESTIMATED", "M2 (GCR from MSL/RAD + SEP term)",
               "GCR 1.8 mSv/day + k x flux x shielding", "Today", "µSv/h", "M2", persona_id, True, "M2-DOSE-v1", "EV-RAD-MSL"),
        record("Mission dose", today["cumulative_msv"], "ESTIMATED", "M2", "Sum of daily dose since launch", "Mission to date",
               "mSv", "M2", persona_id, True, "M2-DOSE-v1", "EV-RAD-MSL"),
        record("Proton flux >=10 MeV", round(f, 2) if f else None, "TELEMETRY", "Mission storm profile", "Storm profile",
               "Today 12:00", "pfu", "M2", persona_id),
    ]
    return {"persona_id": persona_id, "day": day, "location": location, "location_today": SHIELD_LABEL[loc_today] if day > 0 else "Earth",
            "flux_pfu_noon": round(f, 2) if f else None, "dose_rate_usv_h": round(rate_usv_h, 1) if rate_usv_h else None,
            "daily_msv": today["daily_msv"], "cumulative_msv": today["cumulative_msv"],
            "pct_career_limit": round(today["cumulative_msv"] / CAREER_LIMIT_MSV * 100, 2), "career_limit_msv": CAREER_LIMIT_MSV,
            "storm_dose_msv": round(sum(x["daily_msv"] - GCR_MSV_PER_DAY for x in s if st["onset_day"] <= x["day"] < st["onset_day"] + st["duration_days"]), 2),
            "status": status, "storm": st, "flux": hourly_flux(), "crew_series": all_crew,
            "eva_persona": [q["id"] for q in store.mission()["personas"] if q.get("eva_during_storm")],
            "method": {"gcr_msv_per_day": GCR_MSV_PER_DAY, "sep_coefficient": SEP_MSV_PER_PFU_DAY, "shielding": SHIELD,
                       "note": "SEP coefficient and shielding factors await calibration against MSL/RAD storm data."},
            "status_type": "ESTIMATED", "is_simulated": True, "evidence_id": "EV-RAD-MSL", "provenance": prov}
