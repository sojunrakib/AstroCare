"""M9 Crew Health Console: daily vitals vs each persona's own 30-day baseline.

Rule M9-FLAG-v1 (from the team's M9 notebook):
    modified z = 0.6745 x (today - median of previous 30 days) / MAD
    flag when |z| >= 3.5 and at least 21 valid baseline days exist.
    SpO2 flags are shown but never raise an alert (readings barely vary).

Telemetry is TELEMETRY. It is read from data/m9/m9_vitals_daily.csv.
Replace that file with your notebook's export (same columns) to use your own series.
"""
import math
import random
import time
from functools import lru_cache

from .. import store
from ..provenance import record
from . import context as ctx

MEASURES = {
    "hr": {"name": "Resting heart rate", "unit": "bpm", "dec": 1},
    "hrv": {"name": "HRV (RMSSD)", "unit": "ms", "dec": 1},
    "spo2": {"name": "SpO2", "unit": "%", "dec": 1},
    "rr": {"name": "Respiratory rate", "unit": "breaths/min", "dec": 1},
}
NAME_TO_KEY = {v["name"]: k for k, v in MEASURES.items()}


def median(a):
    s = sorted(a)
    n = len(s)
    if not n:
        return None
    m = n // 2
    return s[m] if n % 2 else (s[m - 1] + s[m]) / 2


def mad(a):
    m = median(a)
    return median([abs(x - m) for x in a]) if a else None


@lru_cache(maxsize=1)
def telemetry():
    """{persona: {measure: {day: value or None}}}"""
    out = {}
    for row in store.load_csv("m9", "m9_vitals_daily.csv"):
        p, k, d = row["crew_id"], row["measure"], int(row["mission_day"])
        v = row["value"].strip()
        out.setdefault(p, {}).setdefault(k, {})[d] = float(v) if v not in ("", "nan", "NA") else None
    return out


def personas():
    return store.mission()["personas"]


def persona_ids():
    return [p["id"] for p in personas()]


def evaluate(series, cfg=None):
    """Run M9-FLAG-v1 over one measure. series: {day: value|None}. Returns {day: result}."""
    cfg = cfg or store.rules()["m9"]
    days = ctx.mission_days()
    idx = {d: i for i, d in enumerate(days)}
    out = {}
    flagged = set()
    for d in days:
        v = series.get(d)
        i = idx[d]
        prev = days[max(0, i - cfg["window_days"]):i]
        base = [series[k] for k in prev if series.get(k) is not None
                and not (cfg["exclude_flagged_days_from_baseline"] and k in flagged)]
        n = len(base)
        res = {"day": d, "value": v, "n": n, "median": None, "mad": None, "z": None, "lo": None, "hi": None,
               "flag": False, "direction": None, "quality": "ok"}
        if n >= cfg["min_baseline_days"]:
            m, md = median(base), mad(base)
            res["median"], res["mad"] = m, md
            if md and md > 0:
                half = cfg["z_threshold"] * md / cfg["z_constant"]
                res["lo"], res["hi"] = m - half, m + half
                if v is not None:
                    z = cfg["z_constant"] * (v - m) / md
                    res["z"] = z
                    if abs(z) >= cfg["z_threshold"]:
                        res["flag"] = True
                        res["direction"] = "above" if z > 0 else "below"
                        flagged.add(d)
            else:
                res["quality"] = "zero_mad"
        else:
            res["quality"] = "insufficient_baseline"
        if v is None:
            res["quality"] = "missing"
        out[d] = res
    return out


@lru_cache(maxsize=None)
def evaluated(persona_id):
    tel = telemetry().get(persona_id)
    if tel is None:
        raise KeyError(persona_id)
    return {k: evaluate(tel.get(k, {})) for k in MEASURES}


def _fmt(v, dec=1):
    return None if v is None else round(v, dec)


@lru_cache(maxsize=1)
def _notebook_index():
    idx = {}
    for c in store.load_json_optional("m9", "m9_cards.json") or []:
        idx[(c["crew_id"], NAME_TO_KEY.get(c["measure"]), int(c["mission_day"]))] = c
    return idx


def flag_card(persona_id, key, r):
    cfg = store.rules()["m9"]
    nb = _notebook_index().get((persona_id, key, r["day"]))
    meta = MEASURES[key]
    enabled = key not in cfg["alert_disabled_measures"]
    return {
        "module": "M9", "domain": "Crew vitals vs own baseline",
        "crew_id": persona_id, "date": ctx.date_for_day(r["day"]), "mission_day": r["day"], "measure": meta["name"],
        "measure_key": key, "value": f"{r['value']:.1f} {meta['unit']}", "value_num": r["value"], "unit": meta["unit"],
        "status": f"Changed from baseline ({r['direction']} own 30-day range)",
        "why": f"|z| = {abs(r['z']):.2f} >= {cfg['z_threshold']} vs own median {r['median']:.2f}, MAD {r['mad']:.2f}, n {r['n']}",
        "z": round(r["z"], 2), "median": round(r["median"], 3), "mad": round(r["mad"], 3), "n": r["n"],
        "rule_id": cfg["rule_id"], "evidence_id": cfg["evidence_id"], "status_type": "TELEMETRY",
        "confidence": "statistical rule, not a clinical finding",
        "action": cfg["action"] if enabled else cfg["alert_disabled_reason"],
        "alert_enabled": enabled, "is_simulated": True,
        "cabin_co2": ctx.cabin_co2(r["day"]),
        "demo_injected_event": bool(nb and nb.get("demo_injected_event")),
        "in_notebook_output": nb is not None,
    }


def flags(persona_id, upto_day=None):
    ev = evaluated(persona_id)
    out = []
    for k in MEASURES:
        for d, r in ev[k].items():
            if r["flag"] and (upto_day is None or d <= upto_day):
                out.append(flag_card(persona_id, k, r))
    out.sort(key=lambda c: (c["mission_day"], c["measure"]))
    return out


def multi_flags(persona_id, upto_day=None):
    """M9-MULTI-v1: two or more alert-enabled measures flagged on the same day."""
    cfg = store.rules()["m9_multi"]
    by_day = {}
    for c in flags(persona_id, upto_day):
        if c["alert_enabled"]:
            by_day.setdefault(c["mission_day"], []).append(c["measure"])
    return [{"rule_id": cfg["rule_id"], "mission_day": d, "measures": m, "action": cfg["action"],
             "evidence_id": cfg["evidence_id"], "status_type": "TELEMETRY", "is_simulated": True}
            for d, m in sorted(by_day.items()) if len(m) >= cfg["min_measures"]]


def daily(persona_id, day):
    day = ctx.clamp_day(day)
    ev = evaluated(persona_id)
    series = {}
    for k, meta in MEASURES.items():
        series[k] = [{"day": d, "date": ctx.date_for_day(d), "value": _fmt(r["value"], 2) if d <= day else None,
                      "median": _fmt(r["median"], 3) if d <= day else None, "lo": _fmt(r["lo"], 3) if d <= day else None,
                      "hi": _fmt(r["hi"], 3) if d <= day else None,
                      "z": _fmt(r["z"], 2) if d <= day else None, "flag": r["flag"] and d <= day,
                      "n": r["n"], "quality": r["quality"]} for d, r in ev[k].items()]
    today = {}
    prov = []
    qual = []
    for k, meta in MEASURES.items():
        r = ev[k][day]
        today[k] = {"name": meta["name"], "unit": meta["unit"], "value": _fmt(r["value"], 1), "median": _fmt(r["median"], 2),
                    "z": _fmt(r["z"], 2), "flag": r["flag"], "quality": r["quality"],
                    "alert_enabled": k not in store.rules()["m9"]["alert_disabled_measures"]}
        prov.append(record(meta["name"], today[k]["value"] if r["value"] is not None else "missing", "TELEMETRY",
                           "Mission telemetry (M9)", "Daily value; modified z vs own previous 30 days",
                           "Rolling 30 days", meta["unit"], "M9", persona_id, rule_id="M9-FLAG-v1",
                           evidence_id="EV-STAT-IGLEWICZ1993"))
        if r["quality"] in ("insufficient_baseline", "missing"):
            qual.append({"rule_id": "M9-Q01", "measure": meta["name"], "day": day,
                         "why": "no reading today" if r["quality"] == "missing" else f"only {r['n']} valid days in the previous 30 (need 21)"})
    fl = flags(persona_id, day)
    return {"persona_id": persona_id, "day": day, "date": ctx.date_for_day(day), "measures": MEASURES,
            "today": today, "series": series, "flags": fl, "multi_flags": multi_flags(persona_id, day),
            "active_flags": [f for f in fl if f["mission_day"] == day], "quality": qual,
            "cabin_co2": [{"day": d, "co2": ctx.cabin_co2(d) if d <= day else None} for d in ctx.mission_days()],
            "is_simulated": True, "provenance": prov}


def live(persona_id, day):
    """Ten 1-second heart-rate samples around today's resting HR (display only)."""
    day = ctx.clamp_day(day)
    hr = telemetry()[persona_id]["hr"].get(day)
    now = time.time()
    if hr is None:
        return {"persona_id": persona_id, "day": day, "samples": [], "status_type": "TELEMETRY", "is_simulated": True}
    base = hr + 8  # awake vs resting
    rnd = random.Random(int(now))
    samples = [{"t": round(now - 9 + i, 1),
                "hr": round(base + 2.5 * math.sin((now - 9 + i) * 0.9) + 1.2 * math.sin((now - 9 + i) * 3.1) + rnd.uniform(-0.8, 0.8), 1)}
               for i in range(10)]
    return {"persona_id": persona_id, "day": day, "samples": samples, "status_type": "TELEMETRY", "is_simulated": True}


def rules_table():
    r = store.rules()
    return [
        {"rule_id": r["m9"]["rule_id"], "name": r["m9"]["name"], "fires_when": r["m9"]["fires_when"],
         "applies_to": ", ".join(m["name"] for m in MEASURES.values()),
         "alert": "Yes, except SpO2 (shown, no alert)", "action": r["m9"]["action"], "evidence_id": r["m9"]["evidence_id"]},
        {"rule_id": r["m9_multi"]["rule_id"], "name": r["m9_multi"]["name"], "fires_when": "2 or more alert-enabled measures flagged on the same day",
         "applies_to": "Resting HR, HRV, respiratory rate", "alert": "Yes", "action": r["m9_multi"]["action"], "evidence_id": r["m9_multi"]["evidence_id"]},
        {"rule_id": r["m9_quality"]["rule_id"], "name": r["m9_quality"]["name"], "fires_when": r["m9_quality"]["fires_when"],
         "applies_to": "All measures", "alert": "No (pauses M9-FLAG-v1)", "action": "Collect another measurement", "evidence_id": None},
    ]
