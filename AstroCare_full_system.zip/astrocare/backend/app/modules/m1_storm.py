"""M1 solar-particle-event forecaster (Tier 1 · ML).

Chosen model (team notebook): logistic regression on flare size (log10 GOES X-ray peak flux),
Platt-calibrated, alert threshold 0.05 (= flares of class ~M5 or larger).
The coefficients were exported from m1_model.joblib + m1_calibrator.joblib, so no scikit-learn is
needed at run time. The test-set predictions (2024-2026) are the team's own output and are replayed as-is.
"""
import math
import re
from collections import defaultdict
from functools import lru_cache

from .. import store
from ..provenance import record

CLASS_BASE = {"A": 1e-8, "B": 1e-7, "C": 1e-6, "M": 1e-5, "X": 1e-4}


def model():
    return store.load_json("m1", "m1_model_export.json")


def info():
    return store.load_json("m1", "m1_model_info.json")


def parse_flare_class(s):
    """'X1.2' -> log10 peak flux (W/m^2)."""
    m = re.fullmatch(r"\s*([ABCMX])\s*([0-9]*\.?[0-9]+)?\s*", str(s).upper())
    if not m:
        raise ValueError("flare class must look like C3.2, M5 or X1.0")
    return math.log10(CLASS_BASE[m.group(1)] * float(m.group(2) or 1.0))


def flare_class(log10_flux):
    f = 10 ** log10_flux
    for letter in "XMCBA":
        if f >= CLASS_BASE[letter]:
            return f"{letter}{f / CLASS_BASE[letter]:.1f}"
    return f"A{f / 1e-8:.1f}"


def probability(log10_flux):
    m = model()
    z = (log10_flux - m["scaler_mean"]) / m["scaler_scale"]
    d = m["intercept"] + m["coef"] * z
    a, b = m["calibration"]["a"], m["calibration"]["b"]
    return 1 / (1 + math.exp(-(a * d + b)))


def predict(flare=None, log10_flux=None):
    if log10_flux is None:
        log10_flux = parse_flare_class(flare)
    log10_flux = float(log10_flux)
    p = probability(log10_flux)
    thr = model()["threshold"]
    return {"model_id": model()["model_id"], "flare_class": flare_class(log10_flux), "log10_peak_flux": round(log10_flux, 3),
            "sep_probability_48h": round(p, 3), "alert": p >= thr, "threshold": thr, "status_type": "ML_PREDICTED",
            "why": f"Flare {flare_class(log10_flux)}: calibrated probability {p:.3f} {'>=' if p >= thr else '<'} alert threshold {thr}",
            "caveat": "Probabilities are over-stated about 3x on recent data (storm rate lower in test than in training).",
            "evidence_id": "EV-SEP-DONKI", "is_simulated": False}


@lru_cache(maxsize=1)
def test_rows():
    feats = {r["event_key"]: r for r in store.load_csv("m1", "m1_test.csv")}
    rows = []
    for r in store.load_csv("m1", "m1_test_predictions.csv"):
        f = feats.get(r["event_key"], {})
        lf = float(f.get("flare_log10_peak_flux", "nan"))
        rows.append({
            "event_key": r["event_key"], "time": r["time"][:16].replace(" ", "T") + "Z",
            "forecast_point": "flare + CME" if "B_flare_plus_cme" in r["event_key"] else "flare peak",
            "flare_class": flare_class(lf) if lf == lf else None, "log10_peak_flux": round(lf, 3),
            "lon": float(f.get("flare_lon_deg") or "nan"), "lat": float(f.get("flare_lat_deg") or "nan"),
            "sep_probability_48h": float(r["sep_probability_48h"]), "alert": r["alert"] == "True",
            "storm": float(r["target"]) == 1.0, "status_type": r["status_type"],
        })
    rows.sort(key=lambda x: x["time"])
    return rows


def storms():
    out = []
    for r in test_rows():
        if r["storm"]:
            out.append({**r, "caught": r["alert"], "date": r["time"][:10]})
    return out


def summary():
    i = info()
    rows = test_rows()
    months = defaultdict(lambda: {"flares": 0, "alerts": 0, "storms": 0, "caught": 0})
    for r in rows:
        k = r["time"][:7]
        months[k]["flares"] += 1
        months[k]["alerts"] += r["alert"]
        months[k]["storms"] += r["storm"]
        months[k]["caught"] += r["storm"] and r["alert"]
    n_months = len(months) or 1
    tr = i["test_results"]
    return {"model": i["model"], "model_id": model()["model_id"], "features": i["features"], "threshold": i["threshold"],
            "alert_rule_plain": i["alert_rule_plain"], "target": i["target"], "train": i["train"], "test": i["test"],
            "cv_comparison": i["cv_comparison"], "test_results": tr, "test_pr_auc_95ci": i["test_pr_auc_95ci"],
            "test_recall_95ci": i["test_recall_95ci"], "excluded": i["excluded"], "limitations": i["limitations"],
            "false_alerts_per_month": round(tr["false_alerts"] / n_months, 1), "n_months": n_months,
            "monthly": [{"month": k, **v} for k, v in sorted(months.items())],
            "coefficients": model(), "status_type": "ML_PREDICTED", "evidence_id": "EV-SEP-DONKI", "is_simulated": False}


def timeline(start=None, end=None, around=None, days=4):
    rows = test_rows()
    if around:
        import datetime as dt
        c = dt.datetime.fromisoformat(around.replace("Z", "")[:16])
        start = (c - dt.timedelta(days=days)).isoformat()[:16]
        end = (c + dt.timedelta(days=days)).isoformat()[:16]
    start = start or rows[0]["time"]
    end = end or rows[-1]["time"]
    sel = [r for r in rows if start[:16] <= r["time"][:16] <= end[:16]]
    return {"start": start, "end": end, "flares": sel, "threshold": model()["threshold"], "status_type": "ML_PREDICTED",
            "is_simulated": False}


def mission_forecast(day):
    """M1 applied to the simulated mission's demo flare (input TELEMETRY, output from the real model)."""
    st = store.mission()["storm"]
    onset = st["onset_day"]
    if onset - 2 <= day <= onset:
        res = predict(flare="X2.0")
        res.update({"input_status_type": "TELEMETRY", "why": "X2.0 flare on mission day %d: " % (onset - 2) + res["why"]})
    else:
        res = predict(flare="C2.0")
        res.update({"input_status_type": "TELEMETRY", "why": "Quiet sun (largest flare C2.0): " + res["why"]})
    res["day"] = day
    res["provenance"] = [record("SEP probability 48 h", res["sep_probability_48h"], "ML_PREDICTED",
                                "M1-SEP-v1 on the mission flare", "Calibrated logistic regression on flare size",
                                "48 h", "", "M1", "mission", is_simulated=True, rule_id="M1 threshold 0.05",
                                evidence_id="EV-SEP-DONKI")]
    return res
