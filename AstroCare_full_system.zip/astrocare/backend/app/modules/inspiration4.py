"""Inspiration4 replay modules (real, de-identified crew C001-C004): M4, M5, M6, M7, M8.

M4: team notebook cards (data/m4).
M7, M6: computed in the app by rules M7-DEV-v1 and M6-TRAJ-v2 from the OSDR lab panels (see i4_lab.py).
M8: published-context card (data/reference/m8_context.json).
Optional: notebook card files m6/m7/m8_cards.json in data/cards/ are shown next to the app's own result.
"""
from .. import store
from ..provenance import record
from . import i4_lab

CREW = ["C001", "C002", "C003", "C004"]

PENDING = {
    "M6": {"title": "Recovery after landing", "summary": "M6-TRAJ-v2 (proposed): 35 of 39 R+1 changes back within variation; descriptive only. Old trajectory labels were at chance level (47.7% vs 45.8%).",
           "file": "m6_cards.json", "evidence_id": "EV-I4-IMMUNE", "rule_id": "R70"},
    "M7": {"title": "Immune monitoring", "summary": "Pre-flight-calibrated thresholds (5% false flags). 137 NULISA zero values treated as missing. Only C001 and C002, Eve panel, R+82 exceed chance (11/71 vs 3.6 expected).",
           "file": "m7_cards.json", "evidence_id": "EV-I4-IMMUNE", "rule_id": "R20"},
    "M8": {"title": "Telomere trajectory", "summary": "No per-crew values available (decision D3): context card only, 12 published statements.",
           "file": "m8_cards.json", "evidence_id": "EV-I4-TELOMERE", "rule_id": "R40"},
}


def _crew_cards(cards, crew_id):
    if cards is None:
        return None
    if isinstance(cards, dict):
        cards = cards.get("cards", [cards])
    own = [c for c in cards if c.get("crew_id") in (crew_id, None, "ALL", "all")]
    return own


def module_cards(module, crew_id):
    if crew_id not in CREW:
        raise KeyError(crew_id)
    meta = PENDING[module]
    cards = store.load_json_optional("cards", meta["file"])
    own = _crew_cards(cards, crew_id)
    prov = []
    if own is None:
        return {"module": module, "crew_id": crew_id, "loaded": False, "title": meta["title"], "file_expected": f"backend/data/cards/{meta['file']}",
                "team_summary": meta["summary"], "summary_source": "HomeBound progress log, 6 Nov 2026 (team result; card file not loaded)",
                "status_type": "CONTEXT", "evidence_id": meta["evidence_id"], "rule_id": meta["rule_id"], "cards": [], "is_simulated": False,
                "provenance": [record(meta["title"], "card file not loaded", "CONTEXT", "Team progress log", "Summary text only", "-",
                                      "", module, crew_id, evidence_id=meta["evidence_id"])]}
    for c in own:
        prov.append(record(f"{module} {c.get('domain') or c.get('measure') or c.get('title') or ''}".strip(),
                           c.get("value", c.get("status")), c.get("status_type", "DERIVED"), c.get("source", meta["file"]),
                           c.get("rule_id", "-"), c.get("trend", "-"), "", module, crew_id, c.get("is_simulated", False),
                           c.get("rule_id"), c.get("evidence_id", meta["evidence_id"])))
    return {"module": module, "crew_id": crew_id, "loaded": True, "title": meta["title"], "cards": own,
            "evidence_id": meta["evidence_id"], "rule_id": meta["rule_id"], "is_simulated": False, "provenance": prov}


def microbiome(crew_id):
    if crew_id not in CREW:
        raise KeyError(crew_id)
    cards = store.load_json("m4", "m4_cards.json")
    card = next(c for c in cards if c["crew_id"] == crew_id)
    clf = store.load_json("m4", "m4_classifier_summary.json")
    prov = [record("Microbiome distance (Tier A, in flight)", card["value"], card["status_type"], card["source"],
                   "Median in-flight distance / own pre-flight spread", card["trend"], card["value_label"], "M4", crew_id,
                   False, card["rule_id"], "EV-OSD-572")]
    return {"crew_id": crew_id, "card": card, "all_cards": cards, "classifier": clf,
            "figures": [{"src": "assets/img/m4_plots.png", "caption": "Tier A change from own baseline per crew, and Tier A vs Tier B (team notebook)."},
                        {"src": "assets/img/m4_inflight_taxa.png", "caption": "QC: three environmental taxa seen almost only in in-flight swabs (likely contamination, not verified)."},
                        {"src": "assets/img/m4_classifier_auroc.png", "caption": "Exploratory classifier collapses to chance once a few in-flight-only taxa are removed."}],
            "evidence_id": "EV-OSD-572", "rule_id": "R30", "is_simulated": False, "provenance": prov}


def brain_context():
    return {"module": "M5", "title": "Brain evidence (context only)", "status_type": "CONTEXT",
            "text": "Mouse studies in NASA OSDR (OSD-611, OSD-374, OSD-479) report hippocampal gene-expression and behaviour changes after ground-based exposure to space-type radiation. These are animal results: AstroCare shows them as context and makes no prediction for any crew member. Not processed in this build.",
            "evidence_id": "EV-M5-MOUSE", "is_simulated": False}


def _notebook(module, crew_id):
    r = module_cards(module, crew_id)
    return r["cards"] if r["loaded"] else None


def immune(crew_id):
    if crew_id not in CREW:
        raise KeyError(crew_id)
    r = i4_lab.m7(crew_id)
    r1 = [x for x in r["rows"] if x["timepoint"] == "R+1"]
    prov = [record(f"M7 {x['label']} · {x['timepoint']}", f"{x['n_flagged']}/{x['n_tested']} flagged", "DERIVED",
                   f"NASA OSDR {x['osd']}", f"M7-DEV-v1, |z| > k (5% pre-flight false flags), expected {x['expected']}",
                   x["timepoint"], "analytes", "M7", crew_id, False, "M7-DEV-v1", "EV-I4-IMMUNE") for x in r["rows"]]
    r.update({"title": "Immune monitoring", "notebook_cards": _notebook("M7", crew_id), "provenance": prov,
              "r1_summary": r1, "rule_id": "M7-DEV-v1"})
    return r


def telomere(crew_id):
    if crew_id not in CREW:
        raise KeyError(crew_id)
    c = store.load_json("reference", "m8_context.json")
    return {**c, "crew_id": crew_id, "is_simulated": False, "notebook_cards": _notebook("M8", crew_id),
            "provenance": [record("Telomere length", "published context only", "CONTEXT", "Garcia-Medina et al. 2024",
                                  "Published statements; no per-crew values", "-", "", "M8", crew_id, evidence_id="EV-I4-TELOMERE")]}


def recovery(crew_id):
    if crew_id not in CREW:
        raise KeyError(crew_id)
    m4 = microbiome(crew_id)
    m7 = i4_lab.m7(crew_id)
    m6 = i4_lab.m6(crew_id)
    rows = [{"indicator": "Microbiome distance (M4, Tier A)", "status": m4["card"]["status"],
             "detail": f"in flight {m4['card']['value']}; {m4['card']['trend']}", "status_type": "DERIVED", "source": "OSD-572", "loaded": True}]
    for ev in m7["panels"] + [{k: v for k, v in i4_lab.evaluate(p).items() if k not in ("per_analyte", "summary")} for p in ("eve_cv", "cmp")]:
        summ = i4_lab.evaluate(ev["panel"])["summary"][crew_id]
        cells = {t: summ[t] for t in i4_lab.POST}
        rows.append({"indicator": ev["label"], "status": "Changed beyond chance at " + ", ".join(t for t, x in cells.items() if x["above_chance"])
                     if any(x["above_chance"] for x in cells.values()) else "Within own variation (no change beyond chance)",
                     "detail": " · ".join(f"{t} {x['n_flagged']}/{x['n_tested']}" for t, x in cells.items()),
                     "cells": cells, "status_type": "DERIVED", "source": ev["osd"], "loaded": True})
    tel = store.load_json("reference", "m8_context.json")
    rows.append({"indicator": "Telomere length (M8)", "status": "Published context only", "detail": tel["statements"][3]["text"],
                 "status_type": "CONTEXT", "source": "Garcia-Medina et al. 2024", "loaded": True})
    rows.append({"indicator": "Bone density", "status": "No measurement", "detail": "Context only: lost bone is regained slowly after long missions (EV-BONE).",
                 "status_type": "CONTEXT", "source": "Published context", "loaded": True})
    t = m6["totals"]
    prov = m4["provenance"] + [record("M6 R+1 changes back within variation by R+82", f"{t['back_r82']} of {t['followed_r82']}", "DERIVED",
                                      "NASA OSDR OSD-575, OSD-569", "M6-TRAJ-v2", "R+1 to R+194", "changes", "M6", crew_id, False,
                                      "M6-TRAJ-v2", "EV-I4-IMMUNE")]
    return {"crew_id": crew_id, "rows": rows, "m6": m6, "m6_all": {k: v for k, v in i4_lab.m6().items() if k != "changes"},
            "timepoints": i4_lab.POST, "notebook_cards": _notebook("M6", crew_id), "is_simulated": False, "provenance": prov}
