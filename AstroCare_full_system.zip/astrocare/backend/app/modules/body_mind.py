"""Behaviour self-reports, in-app reaction-time test and bone scans (no model on purpose).

Entries are stored in backend/data/runtime/*.json. The first 7 self-report entries of each persona
are their personal baseline; rule R50 fires when 2 or more items are worse in the last 7 entries.
Each persona starts with 14 TELEMETRY history entries so the trend charts are not empty.
"""
import datetime as dt
import random

from .. import store
from ..provenance import record
from . import context as ctx

ITEMS = {"sleep": ("Sleep last night", "h", 3, 10), "stress": ("Stress", "1-5", 1, 5),
         "mood": ("Mood", "1-5", 1, 5), "fatigue": ("Fatigue", "1-5", 1, 5)}
def _now():
    return dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


WORSE = {"sleep": lambda d: d < -0.5, "stress": lambda d: d > 0.7, "mood": lambda d: d < -0.7, "fatigue": lambda d: d > 0.7}


def _seed_history(pid):
    r = random.Random(sum(map(ord, pid)) * 11)
    late_change = pid == "SIM-A"  # mirrors the scripted HRV dip
    h = []
    for i in range(14):
        late = late_change and i >= 10
        h.append({"sleep": round(6.8 + 0.3 * r.gauss(0, 1) - (1.0 if late else 0), 1), "stress": 2 + round(r.random()) + (2 if late else 0),
                  "mood": 4 - round(r.random()) - (1 if late else 0), "fatigue": 2 + round(r.random()) + (1 if late else 0),
                  "entry": i + 1, "status_type": "SELF_REPORTED", "saved_at": None})
    return h


def _all():
    return store.runtime_read("selfreports.json", {})


def history(pid):
    data = _all()
    if pid not in data:
        data[pid] = _seed_history(pid)
        store.runtime_write("selfreports.json", data)
    return data[pid]


def add_entry(pid, entry):
    clean = {}
    for k, (_, _, lo, hi) in ITEMS.items():
        if k not in entry:
            raise ValueError(f"missing field {k}")
        v = float(entry[k])
        if not lo <= v <= hi:
            raise ValueError(f"{k} must be between {lo} and {hi}")
        clean[k] = v
    data = _all()
    h = data.get(pid) or _seed_history(pid)
    clean.update({"entry": len(h) + 1, "status_type": "SELF_REPORTED", "saved_at": _now()})
    h.append(clean)
    data[pid] = h[-60:]
    store.runtime_write("selfreports.json", data)
    return behaviour(pid)


def behaviour(pid):
    h = history(pid)
    base, recent = h[:7], h[-7:]
    avg = lambda a, k: sum(x[k] for x in a) / len(a)
    delta = {k: round(avg(recent, k) - avg(base, k), 2) for k in ITEMS}
    worse = [k for k in ITEMS if WORSE[k](delta[k])]
    changed = len(worse) >= 2
    rec = None
    if changed:
        rec = {"rule_id": "R50", "text": next(r["text"] for r in store.rules()["action_rules"] if r["id"] == "R50")}
    return {"persona_id": pid, "items": ITEMS, "history": h, "delta_vs_baseline": delta, "worse_items": worse,
            "status": "Behavioural indicators changed from baseline" if changed else "Stable vs own baseline",
            "status_cls": "st-warn" if changed else "st-good", "recommendation": rec,
            "status_type": "SELF_REPORTED", "includes_simulated_history": any(x["status_type"] == "TELEMETRY" for x in h),
            "reaction": reaction(pid),
            "provenance": [record("Behaviour status", "changed" if changed else "stable", "SELF_REPORTED", "In-app self-report",
                                  "Mean of last 7 entries vs first 7 entries", "Rolling", "", "Behaviour", pid,
                                  any(x["status_type"] == "TELEMETRY" for x in recent), "R50")]}


def add_reaction(pid, trials_ms):
    trials = [float(t) for t in trials_ms]
    if not 3 <= len(trials) <= 20 or any(t < 80 or t > 3000 for t in trials):
        raise ValueError("send 3-20 reaction times between 80 and 3000 ms")
    s = sorted(trials)
    med = s[len(s) // 2] if len(s) % 2 else (s[len(s) // 2 - 1] + s[len(s) // 2]) / 2
    data = store.runtime_read("reaction.json", {})
    data.setdefault(pid, []).append({"median_ms": round(med), "trials": trials, "saved_at": _now()})
    store.runtime_write("reaction.json", data)
    return reaction(pid)


def reaction(pid):
    runs = store.runtime_read("reaction.json", {}).get(pid, [])
    first = runs[:3]
    base = sorted(r["median_ms"] for r in first)[len(first) // 2] if first else None
    last = runs[-1]["median_ms"] if runs else None
    return {"runs": runs[-10:], "baseline_ms": base, "latest_ms": last,
            "change_ms": (last - base) if (last is not None and base is not None and len(runs) > 3) else None,
            "status_type": "MEASURED", "note": "Compared with your own first 3 runs; not a clinical cognitive test."}


def bone(pid, day=None):
    scans = store.runtime_read("bone.json", {}).get(pid)
    day = ctx.clamp_day(day)
    if not scans:
        return {"persona_id": pid, "status": "No quantitative bone assessment", "status_cls": "st-none", "scan": None,
                "microgravity_days": max(0, day), "rule_id": "R60" if day > 30 else None, "evidence_id": "EV-BONE", "status_type": "CONTEXT",
                "provenance": [record("Bone density", "no scan", "CONTEXT", "Mission protocol", "Scan entry only", "-", "", "Bone", pid,
                                      evidence_id="EV-BONE")]}
    pct = (scans["latest"] - scans["preflight"]) / scans["preflight"] * 100
    return {"persona_id": pid, "status": "Change from own pre-flight scan", "status_cls": "st-warn" if pct < -1 else "st-good",
            "scan": scans, "pct_change": round(pct, 2), "microgravity_days": max(0, day), "rule_id": None, "evidence_id": "EV-BONE",
            "status_type": "MEASURED", "note": "Trend only; no fracture-risk prediction.",
            "provenance": [record("BMD change", round(pct, 2), "DERIVED", "Entered DXA scans", "% change vs pre-flight scan", "-", "%",
                                  "Bone", pid, evidence_id="EV-BONE")]}


def set_bone(pid, site, preflight, latest):
    pre, now = float(preflight), float(latest)
    if not (0.3 <= pre <= 2.0 and 0.3 <= now <= 2.0):
        raise ValueError("BMD values must be between 0.3 and 2.0 g/cm2")
    data = store.runtime_read("bone.json", {})
    data[pid] = {"site": site, "preflight": pre, "latest": now, "saved_at": _now()}
    store.runtime_write("bone.json", data)
    return bone(pid)


def clear_bone(pid):
    data = store.runtime_read("bone.json", {})
    data.pop(pid, None)
    store.runtime_write("bone.json", data)
    return bone(pid)
