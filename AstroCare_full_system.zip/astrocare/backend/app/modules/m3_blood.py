"""M3 blood radiation biodosimeter (Tier 1 · ML). Pure-Python port of the team's m3_predict.py.

Models (all real, trained on ex vivo irradiated human blood, never pooled across studies):
  M3-24h-v2       OSD-1012 X-ray, 20-28 h, regression on log2(Gy + 0.1), valid 0.1-2 Gy
  M3-early-1h/2h/6h-v2   OSD-410 gamma, dose class 0 / 0.15 / 0.30 / 1.5 Gy, one model per time point
Inputs are log2 expression values keyed by probe ID for the exposed sample AND the person's own baseline.
Outside a validated time window, or without a baseline / with missing genes, no dose is returned (rule R02).
"""
import math
from functools import lru_cache

from .. import store
from ..provenance import record

EARLY = {1: "1h", 2: "2h", 6: "6h"}


@lru_cache(maxsize=None)
def load_model(name):
    return store.load_json("m3", "models", f"m3_{name}_model_v2.json")


def cards():
    return store.load_json("m3", "m3_cards_v2.json")


def _features(m):
    return [g for g in m["features"] if g != "time_after_exposure_hours"]


def _change(m, exposed, baseline):
    feats = _features(m)
    missing = [g for g in feats if g not in exposed or g not in baseline]
    if missing:
        return None, missing
    return [float(exposed[g]) - float(baseline[g]) for g in feats], []


def _z(m, x):
    return [(xi - mu) / sc for xi, mu, sc in zip(x, m["scaler_mean"], m["scaler_scale"])]


def window_for(hours):
    """Which model (if any) is valid for this many hours since exposure."""
    if hours is None:
        return None
    h = float(hours)
    lo, hi = load_model("24h")["valid_time_window_hours"]
    if lo <= h <= hi:
        return "24h"
    tp = int(round(h))
    if tp in EARLY and abs(h - tp) <= 0.5:
        return "early_" + EARLY[tp]
    return None


def predict_24h_from_change(x):
    m = load_model("24h")
    z = _z(m, x)
    pred = m["intercept"] + sum(c * zi for c, zi in zip(m["coef"], z))
    dose = max(0.0, 2 ** pred - 0.1)
    vlo, vhi = m["valid_dose_range_gy"]
    return {"status": "ML_PREDICTED", "model_id": m["model_id"], "dose_gy_xray_equivalent": round(dose, 2),
            "within_validated_range": vlo <= dose <= vhi, "valid_dose_range_gy": [vlo, vhi],
            "below_validated_range": dose < vlo, "above_validated_range": dose > vhi,
            "interval_gy": [round(max(0, dose - m["validation"]["exposed"]["MAE_gy"]), 2), round(dose + m["validation"]["exposed"]["MAE_gy"], 2)],
            "evidence": m["study_id"], "evidence_id": "EV-OSD-1012",
            "caveat": "X-ray-equivalent; neutron exposure is over-read about %.1fx" % m["neutron_slope"]}


def predict_early_from_change(tp, x):
    m = load_model("early_" + tp)
    z = _z(m, x)
    logits = [b + sum(c * zi for c, zi in zip(row, z)) for row, b in zip(m["coef"], m["intercept"])]
    mx = max(logits)
    e = [math.exp(v - mx) for v in logits]
    s = sum(e)
    p = [v / s for v in e]
    k = max(range(len(p)), key=lambda i: p[i])
    return {"status": "ML_PREDICTED", "model_id": m["model_id"], "dose_class_gy": m["classes_dose_gy"][k],
            "probabilities": {str(c): round(q, 3) for c, q in zip(m["classes_dose_gy"], p)},
            "evidence": m["study_id"], "evidence_id": "EV-OSD-410",
            "reliability": "exploratory (not reproduced in OSD-71)" if tp == "1h" else
            ("study-specific - only 5 donors, result uncertain" if tp == "6h" else "study-specific")}


def predict(exposed, baseline, hours):
    """Main entry point (same contract as m3_predict.py, plus the window rule)."""
    w = window_for(hours)
    base = {"hours_since_exposure": hours, "rule_id": "R02"}
    if not baseline:
        return {**base, "status": "NO_BASELINE", "message": "No own baseline sample: no estimate (R02)."}
    if w is None:
        return {**base, "status": "OUTSIDE_VALIDATED_WINDOW",
                "message": "Outside validated window (1 h, 2 h, 6 h or 20-28 h after exposure): no estimate (R02)."}
    m = load_model(w)
    x, missing = _change(m, exposed, baseline)
    if x is None:
        return {**base, "status": "MISSING_GENES", "model_id": m["model_id"], "missing": missing[:20], "n_missing": len(missing),
                "message": f"{len(missing)} model genes missing from the sample: no estimate."}
    res = predict_24h_from_change(x) if w == "24h" else predict_early_from_change(w.split("_")[1], x)
    res["window"] = w
    res["hours_since_exposure"] = hours
    res["n_genes"] = len(x)
    return res


# ---------------- demo profiles (TELEMETRY) ----------------
# No real astronaut blood exists for this mission, so demo inputs are built in model space:
# change-from-baseline = training mean + t x scale x sign(weight), with t solved so the 24 h model
# reads the stated dose. Labelled TELEMETRY everywhere; they show the screen, not a result.

def _demo_change_24h(target_gy):
    m = load_model("24h")
    goal = math.log2(target_gy + 0.1)
    w = m["coef"]
    norm = sum(abs(c) for c in w) or 1
    t = (goal - m["intercept"]) / norm
    return [mu + t * sc * (1 if c >= 0 else -1) for mu, sc, c in zip(m["scaler_mean"], m["scaler_scale"], w)]


def _demo_change_early(tp, cls_index, strength=1.2):
    m = load_model("early_" + tp)
    row = m["coef"][cls_index]
    mx = max(abs(c) for c in row) or 1
    return [mu + strength * sc * (c / mx) * 2.0 for mu, sc, c in zip(m["scaler_mean"], m["scaler_scale"], row)]


DEMO_PROFILES = [
    {"id": "habitat", "label": "SIM-A · habitat during storm", "physical": "storm dose about 1-2 mSv (M2, habitat)", "target_gy": 0.002, "early_class": 0},
    {"id": "eva", "label": "SIM-D · EVA during storm", "physical": "storm dose about 5 mSv (M2, EVA)", "target_gy": 0.006, "early_class": 0},
    {"id": "large", "label": "Very large storm, unshielded", "physical": "hypothetical 0.5 Gy", "target_gy": 0.5, "early_class": 3},
    {"id": "reference", "label": "Pre-flight reference draw", "physical": "background only", "target_gy": 0.0, "early_class": 0},
]


def demo_profiles():
    return [{k: v for k, v in p.items() if k not in ("target_gy", "early_class")} for p in DEMO_PROFILES]


def demo_sample(profile_id, hours):
    """Returns (exposed, baseline) dicts keyed by probe ID for the model valid at `hours`."""
    p = next((q for q in DEMO_PROFILES if q["id"] == profile_id), None)
    if p is None:
        raise KeyError(profile_id)
    w = window_for(hours)
    if w is None:
        w = "24h"
    m = load_model(w)
    feats = _features(m)
    x = _demo_change_24h(p["target_gy"]) if w == "24h" else _demo_change_early(w.split("_")[1], p["early_class"])
    baseline = {g: 8.0 for g in feats}
    exposed = {g: 8.0 + xi for g, xi in zip(feats, x)}
    return exposed, baseline, p


def predict_demo(profile_id, hours):
    exposed, baseline, p = demo_sample(profile_id, hours)
    res = predict(exposed, baseline, hours)
    res["profile"] = {k: v for k, v in p.items() if k not in ("target_gy", "early_class")}
    res["input_status_type"] = "TELEMETRY"
    res["is_simulated"] = True
    status_val = res.get("dose_gy_xray_equivalent", res.get("dose_class_gy", "withheld"))
    res["provenance"] = [record("M3 blood response", status_val, "ML_PREDICTED", f"{res.get('model_id', 'M3')} on the blood profile",
                                "Elastic-net vs own baseline sample", res.get("window") or "1/2/6 h or 20-28 h", "Gy",
                                "M3", profile_id, True, "R02", res.get("evidence_id"))]
    res["comparison"] = compare(p, res)
    return res


def compare(profile, res):
    """Physical (M2) vs biological (M3) consistency check -> R11 / R12 / R99."""
    if res["status"] != "ML_PREDICTED":
        return {"text": "Comparison unavailable until a sample falls inside a validated window.", "rule_id": "R02", "cls": "st-none"}
    bio_high = (res.get("dose_gy_xray_equivalent") or 0) >= 0.1 or (res.get("dose_class_gy") or 0) > 0
    phys_high = profile["target_gy"] >= 0.1
    if bio_high and phys_high:
        return {"text": "Consistent: both elevated", "cls": "st-serious", "rule_id": "R11",
                "action": "Seek medical review: review the blood-response result with the flight surgeon."}
    if bio_high != phys_high:
        return {"text": "Physical and biological estimates disagree", "cls": "st-warn", "rule_id": "R12",
                "action": "Repeat the blood assessment at the next validated window."}
    return {"text": "Consistent: both low (below the 0.1 Gy the model can resolve)", "cls": "st-good", "rule_id": "R99",
            "action": "Continue scheduled monitoring."}


def validation():
    d = {}
    for name in ("24h_lodo_predictions", "early_1h_lodo_predictions", "early_2h_lodo_predictions",
                 "early_6h_lodo_predictions", "neutron_test_v2", "24h_genes_v2"):
        d[name] = store.load_csv("m3", "validation", f"m3_{name}.csv")
    models = {}
    for n in ("24h", "early_1h", "early_2h", "early_6h"):
        m = load_model(n)
        models[n] = {k: m[k] for k in m if k not in ("coef", "scaler_mean", "scaler_scale", "features")}
        models[n]["n_features"] = len(_features(m))
        models[n]["top_genes"] = _top_genes(m)
    return {"models": models, "data": d, "cards": cards(), "is_simulated": False}


def _top_genes(m, n=8):
    if isinstance(m["coef"][0], list):
        w = [max(abs(row[i]) for row in m["coef"]) for i in range(len(m["gene_symbols"]))]
    else:
        w = [abs(c) for c in m["coef"]]
    order = sorted(range(len(w)), key=lambda i: -w[i])
    return [{"gene": m["gene_symbols"][i], "weight": round(w[i], 3)} for i in order[:n] if w[i] > 0]
