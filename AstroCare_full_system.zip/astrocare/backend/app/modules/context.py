"""Mission timeline and context (gravity, isolation, cabin CO2). Context only, never a cause."""
import datetime as dt
import math
import random

from .. import store
from ..provenance import record


def mission_days():
    m = store.mission()
    return [d for d in range(m["first_day"], m["last_day"] + 1) if not (m["no_day_zero"] and d == 0)]


def date_for_day(day):
    m = store.mission()
    launch = dt.date.fromisoformat(m["launch_date"])  # = mission day 1
    offset = day - 1 if day > 0 else day
    return (launch + dt.timedelta(days=offset)).isoformat()


def clamp_day(day):
    days = mission_days()
    if day is None:
        return store.mission()["default_day"]
    day = int(day)
    if day == 0:
        day = 1
    return max(days[0], min(days[-1], day))


def phase(day):
    return "pre-flight" if day < 0 else "in flight"


def cabin_co2(day):
    """Simulated cabin CO2 (mmHg), deterministic per day."""
    c = store.mission()["cabin_co2"]
    r = random.Random(7000 + day)
    v = c["base_mmHg"] + c["sd"] * r.gauss(0, 1)
    lo, hi = c["bump_days"]
    if lo <= day <= hi:
        v += c["bump_mmHg"] * math.sin(math.pi * (day - lo + 1) / (hi - lo + 2))
    return round(max(1.5, v), 2) if day > 0 else None


def context(persona_id, day):
    day = clamp_day(day)
    in_flight = day > 0
    co2 = cabin_co2(day)
    tiles = [
        {"label": "Mission phase", "value": phase(day), "status_type": "CONTEXT"},
        {"label": "Mission day", "value": day, "status_type": "CONTEXT", "date": date_for_day(day)},
        {"label": "Gravity environment", "value": "Microgravity" if in_flight else "1 g (Earth)", "status_type": "CONTEXT"},
        {"label": "Microgravity exposure", "value": f"{day if in_flight else 0} days", "status_type": "CONTEXT"},
        {"label": "Isolation", "value": f"{day if in_flight else 0} days · crew of 4", "status_type": "CONTEXT"},
        {"label": "Cabin CO2", "value": f"{co2} mmHg" if co2 is not None else "n/a (on Earth)", "status_type": "CONTEXT"},
    ]
    prov = [
        record("Microgravity exposure", day if in_flight else 0, "CONTEXT", "Mission timeline", "Timeline", unit="days",
               module="Context", subject=persona_id),
        record("Cabin CO2", co2, "TELEMETRY", "Cabin environment telemetry", "Daily mean (context only)",
               unit="mmHg", module="Context", subject=persona_id),
    ]
    return {"persona_id": persona_id, "day": day, "date": date_for_day(day), "in_flight": in_flight,
            "tiles": tiles, "cabin_co2_series": [{"day": d, "co2": cabin_co2(d)} for d in mission_days()],
            "provenance": prov}
