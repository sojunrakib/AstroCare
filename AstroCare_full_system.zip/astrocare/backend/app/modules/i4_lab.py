"""Inspiration4 laboratory panels -> M7 immune rule and M6 recovery rule (pure Python, deterministic).

Data (real, de-identified, NASA OSDR; see data/i4/SOURCES.md):
  Eve immune 71-plex, Alamar NULISA 203-target, Eve cardiovascular (OSD-575 serum),
  CBC (OSD-569 whole blood), CMP (OSD-575 serum). Timepoints L-92, L-44, L-3 (baseline), R+1, R+45, R+82, R+194.

M7-DEV-v1 (per panel)
  1. Scale: cytokine concentrations (pg/mL, ng/mL) -> log2; NULISA NPQ is already log2; CBC/CMP raw.
     NULISA zero values are treated as missing (team decision).
  2. Each crew member's baseline = mean of their own pre-flight samples (2-3 points).
  3. Within-person spread per analyte = pooled pre-flight SD across the 4 crew.
  4. z = (value - own baseline mean) / (pooled SD x sqrt(1 + 1/n_baseline)).
  5. Threshold k is calibrated on pre-flight data only: leave-one-out z of every pre-flight sample
     (the left-out point is excluded from its own mean and SD); k = 95th percentile of |z|, so by
     construction about 5% of pre-flight samples would be flagged.
  6. Per crew x timepoint: n flagged vs 5% expected; one-sided binomial p. "Above chance" when p < 0.05.
     Analytes are correlated and many tests are made (4 crew x 4 timepoints x panels), so this is
     descriptive, not a significance claim.
M6-TRAJ-v2
  Every analyte flagged at R+1 is followed to R+45, R+82, R+194: "back within own variation" when |z| <= k.
"""
import csv
import math
from functools import lru_cache

from ..config import data_path

CREW = ["C001", "C002", "C003", "C004"]
PRE = ["L-92", "L-44", "L-3"]
POST = ["R+1", "R+45", "R+82", "R+194"]
TPS = PRE + POST
FALSE_FLAG_RATE = 0.05
# race-coded eGFR fields are derived from creatinine (already included) and are not used
EXCLUDE = ("egfr_african_american", "egfr_non_african_american")

PANELS = {
    "eve_immune": {"label": "Serum cytokines (Eve 71-plex)", "file": "LSDS-8_Multiplex_serum_immune_EvePanel_TRANSFORMED.csv",
                   "osd": "OSD-575", "kind": "wide", "suffix": "_concentration_", "log2": True, "module": "M7"},
    "alamar": {"label": "Serum inflammation (Alamar NULISA 203-target)", "file": "LSDS-8_Multiplex_serum.immune.AlamarPanel_TRANSFORMED.csv",
               "osd": "OSD-575", "kind": "wide", "suffix": "_concentration_npq", "log2": False, "zero_missing": True, "module": "M7"},
    "cbc": {"label": "Blood counts (CBC)", "file": "LSDS-7_CBC_cleaned.csv", "osd": "OSD-569", "kind": "long", "log2": False, "module": "M7"},
    "eve_cv": {"label": "Serum cardiovascular (Eve)", "file": "LSDS-8_Multiplex_serum_cardiovascular_EvePanel_TRANSFORMED.csv",
               "osd": "OSD-575", "kind": "wide", "suffix": "_concentration_", "log2": True, "module": "M6"},
    "cmp": {"label": "Metabolic panel (CMP)", "file": "LSDS-8_Comprehensive_Metabolic_Panel_CMP_TRANSFORMED.csv",
            "osd": "OSD-575", "kind": "wide", "suffix": "_value", "log2": False, "module": "M6"},
}
M7_PANELS = ["eve_immune", "alamar", "cbc"]
M6_PANELS = ["eve_immune", "alamar", "cbc", "eve_cv", "cmp"]


def _num(s):
    try:
        v = float(s)
    except (TypeError, ValueError):
        return None
    return v if math.isfinite(v) else None


def _split_sample(name):
    parts = name.split("_")
    return parts[0], parts[-1]


def _pretty(col, suffix):
    a, unit = col.split(suffix, 1)
    unit = unit.strip("_").replace("_", " ")
    if suffix == "_concentration_npq":
        unit = "NPQ (log2)"
    elif suffix == "_value" and not unit:
        unit = "ratio"
    name = a.replace("_", " ")
    if name.isascii():
        name = name.upper() if len(name) <= 6 else name[0].upper() + name[1:]
    else:  # Greek-letter cytokines: upper-case the Latin part only (ifnγ -> IFNγ)
        name = "".join(ch.upper() if ch.isascii() else ch for ch in name) if len(name) <= 13 else name
    return name, unit


@lru_cache(maxsize=None)
def raw(panel):
    """{analyte: {"unit":..., "values": {crew: {tp: value}}}} on the original scale."""
    p = PANELS[panel]
    out = {}
    with open(data_path("i4", p["file"]), encoding="utf-8-sig", newline="") as f:
        rows = list(csv.DictReader(f))
    if p["kind"] == "long":
        for r in rows:
            v = _num(r["VALUE"])
            a = r["ANALYTE"].title()
            d = out.setdefault(a, {"unit": r["UNITS"], "values": {}, "ref": (_num(r["RANGE_MIN"]), _num(r["RANGE_MAX"]))})
            d["values"].setdefault(r["SUBJECT_ID"], {})[r["TEST_DATE"]] = v
        return out
    key = "Sample Name" if "Sample Name" in rows[0] else "Sample ID"
    cols = [c for c in rows[0] if c != key and p["suffix"] in c and "range" not in c and not c.startswith(EXCLUDE)]
    for c in cols:
        name, unit = _pretty(c, p["suffix"])
        d = out.setdefault(name, {"unit": unit, "values": {}})
        for r in rows:
            crew, tp = _split_sample(r[key])
            v = _num(r[c])
            if v is not None and p.get("zero_missing") and v == 0:
                v = None
            d["values"].setdefault(crew, {})[tp] = v
    return out


def _scaled(panel):
    p = PANELS[panel]
    out = {}
    for a, d in raw(panel).items():
        vals = {}
        for c, tv in d["values"].items():
            vals[c] = {}
            for tp, v in tv.items():
                if v is None:
                    vals[c][tp] = None
                elif p["log2"]:
                    vals[c][tp] = math.log2(v) if v > 0 else None
                else:
                    vals[c][tp] = v
        out[a] = vals
    return out


def _pooled_sd(vals, skip=None):
    """Pooled within-person SD of pre-flight values. skip = (crew, tp) to leave out."""
    ss, dof = 0.0, 0
    for c in CREW:
        xs = [vals.get(c, {}).get(t) for t in PRE if (c, t) != skip]
        xs = [x for x in xs if x is not None]
        if len(xs) >= 2:
            m = sum(xs) / len(xs)
            ss += sum((x - m) ** 2 for x in xs)
            dof += len(xs) - 1
    return math.sqrt(ss / dof) if dof > 0 and ss > 0 else None


def _quantile(xs, q):
    s = sorted(xs)
    if not s:
        return None
    pos = (len(s) - 1) * q
    lo, hi = int(math.floor(pos)), int(math.ceil(pos))
    return s[lo] + (s[hi] - s[lo]) * (pos - lo)


def _binom_sf(k, n, p):
    """P(X >= k) for X ~ Binomial(n, p)."""
    if k <= 0:
        return 1.0
    return sum(math.comb(n, i) * p ** i * (1 - p) ** (n - i) for i in range(k, n + 1))


@lru_cache(maxsize=None)
def evaluate(panel):
    """Full M7-DEV-v1 evaluation of one panel."""
    sc = _scaled(panel)
    loo = []
    per = {}
    for a, vals in sc.items():
        sd_all = _pooled_sd(vals)
        if sd_all is None:
            continue
        # leave-one-out calibration on pre-flight samples
        for c in CREW:
            for t in PRE:
                x = vals.get(c, {}).get(t)
                others = [vals[c].get(u) for u in PRE if u != t and vals.get(c, {}).get(u) is not None]
                if x is None or not others:
                    continue
                sd = _pooled_sd(vals, skip=(c, t))
                if not sd:
                    continue
                loo.append(abs((x - sum(others) / len(others)) / (sd * math.sqrt(1 + 1 / len(others)))))
        z = {}
        for c in CREW:
            base = [vals.get(c, {}).get(t) for t in PRE]
            base = [b for b in base if b is not None]
            if len(base) < 2:
                continue
            m = sum(base) / len(base)
            z[c] = {"baseline_n": len(base), "baseline_mean": m}
            for t in POST:
                x = vals.get(c, {}).get(t)
                z[c][t] = None if x is None else (x - m) / (sd_all * math.sqrt(1 + 1 / len(base)))
        per[a] = {"sd": sd_all, "z": z}
    k = _quantile(loo, 1 - FALSE_FLAG_RATE)
    # per crew x timepoint summary
    summary = {}
    for c in CREW:
        summary[c] = {}
        for t in POST:
            tested = [(a, d["z"][c][t]) for a, d in per.items() if c in d["z"] and d["z"][c].get(t) is not None]
            flagged = [(a, zz) for a, zz in tested if abs(zz) > k]
            n, f = len(tested), len(flagged)
            pval = _binom_sf(f, n, FALSE_FLAG_RATE) if n else None
            summary[c][t] = {"n_tested": n, "n_flagged": f, "expected": round(n * FALSE_FLAG_RATE, 1),
                             "p_value": None if pval is None else round(pval, 4), "above_chance": bool(n and pval < 0.05),
                             "up": sum(1 for _, zz in flagged if zz > 0), "down": sum(1 for _, zz in flagged if zz < 0),
                             "top": [{"analyte": a, "z": round(zz, 2)} for a, zz in sorted(flagged, key=lambda x: -abs(x[1]))[:8]]}
    pre_rate = sum(1 for v in loo if v > k) / len(loo) if loo else None
    return {"panel": panel, "label": PANELS[panel]["label"], "osd": PANELS[panel]["osd"], "threshold_k": round(k, 3),
            "n_analytes": len(per), "n_calibration_points": len(loo), "preflight_false_flag_rate": round(pre_rate, 4) if pre_rate is not None else None,
            "summary": summary, "per_analyte": per}


def m7(crew_id):
    panels = [evaluate(p) for p in M7_PANELS]
    rows, changed_tps = [], []
    for ev in panels:
        for t in POST:
            s = ev["summary"][crew_id][t]
            rows.append({"panel": ev["panel"], "label": ev["label"], "osd": ev["osd"], "timepoint": t, **s})
            if s["above_chance"]:
                changed_tps.append(f"{t} ({ev['label'].split('(')[0].strip()})")
    status = ("Changed from own baseline at " + ", ".join(changed_tps)) if changed_tps else "No change beyond chance vs own baseline"
    heat = _heatmap(crew_id, "eve_immune")
    cbc = _series(crew_id, "cbc", ["Absolute Lymphocytes", "Absolute Neutrophils", "Absolute Monocytes"])
    return {"crew_id": crew_id, "module": "M7", "rule_id": "M7-DEV-v1", "status": status, "changed": bool(changed_tps),
            "rows": rows, "panels": [{k: v for k, v in ev.items() if k not in ("per_analyte", "summary")} for ev in panels],
            "heatmap": heat, "cbc": cbc, "status_type": "DERIVED", "is_simulated": False,
            "in_flight": "No in-flight blood samples (Inspiration4 serum and CBC were collected before and after flight only).",
            "evidence_id": "EV-I4-IMMUNE"}


def _heatmap(crew_id, panel, n=16):
    ev = evaluate(panel)
    k = ev["threshold_k"]
    items = []
    for a, d in ev["per_analyte"].items():
        z = d["z"].get(crew_id)
        if not z:
            continue
        zs = [z.get(t) for t in POST]
        score = max((abs(v) for v in zs if v is not None), default=0)
        items.append((score, a, zs))
    items.sort(key=lambda x: -x[0])
    return {"panel": panel, "label": ev["label"], "threshold_k": k, "timepoints": POST,
            "rows": [{"analyte": a, "z": [None if v is None else round(v, 2) for v in zs]} for _, a, zs in items[:n]]}


def _series(crew_id, panel, analytes):
    r = raw(panel)
    out = []
    for a in analytes:
        if a not in r:
            continue
        v = r[a]["values"].get(crew_id, {})
        pre = [v.get(t) for t in PRE if v.get(t) is not None]
        out.append({"analyte": a, "unit": r[a]["unit"], "values": [v.get(t) for t in TPS], "timepoints": TPS,
                    "preflight_range": [min(pre), max(pre)] if pre else None, "lab_reference": r[a].get("ref")})
    return out


def m6(crew_id=None):
    """M6-TRAJ-v2 over all panels. Returns per crew (or all) counts of R+1 changes that return within variation."""
    crews = [crew_id] if crew_id else CREW
    detail, tot = [], {"flagged_r1": 0, "back_r45": 0, "back_r82": 0, "back_r194": 0, "followed_r82": 0}
    by_panel = {}
    for p in M6_PANELS:
        ev = evaluate(p)
        k = ev["threshold_k"]
        bp = by_panel.setdefault(p, {"label": ev["label"], "flagged_r1": 0, "back_r82": 0, "followed_r82": 0})
        for a, d in ev["per_analyte"].items():
            for c in crews:
                z = d["z"].get(c)
                if not z or z.get("R+1") is None or abs(z["R+1"]) <= k:
                    continue
                later = {t: z.get(t) for t in ("R+45", "R+82", "R+194")}
                back = {t: (None if v is None else abs(v) <= k) for t, v in later.items()}
                tot["flagged_r1"] += 1
                bp["flagged_r1"] += 1
                for t, key in (("R+45", "back_r45"), ("R+82", "back_r82"), ("R+194", "back_r194")):
                    if back[t]:
                        tot[key] += 1
                if back["R+82"] is not None:
                    tot["followed_r82"] += 1
                    bp["followed_r82"] += 1
                    bp["back_r82"] += bool(back["R+82"])
                detail.append({"crew_id": c, "panel": p, "panel_label": ev["label"], "analyte": a,
                               "z": {t: (None if z.get(t) is None else round(z[t], 2)) for t in POST}, "back": back, "threshold_k": k})
    frac = tot["back_r82"] / tot["followed_r82"] if tot["followed_r82"] else None
    status = "No R+1 changes beyond own variation" if not tot["flagged_r1"] else (
        "Recovering: most R+1 changes back within own variation by R+82" if frac is not None and frac >= 0.75 else "Recovery in progress")
    detail.sort(key=lambda r: -abs(r["z"]["R+1"]))
    return {"crew_id": crew_id or "ALL", "module": "M6", "rule_id": "M6-TRAJ-v2", "status": status, "totals": tot,
            "back_fraction_r82": None if frac is None else round(frac, 3), "by_panel": by_panel, "changes": detail,
            "status_type": "DERIVED", "is_simulated": False, "evidence_id": "EV-I4-IMMUNE",
            "note": "Descriptive only: 4 crew; flags use the same pre-flight-calibrated thresholds as M7; no forecast beyond the data."}


def calibration_report():
    return [{k: v for k, v in evaluate(p).items() if k not in ("per_analyte", "summary")} for p in M6_PANELS]
