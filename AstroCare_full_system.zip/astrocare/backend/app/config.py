"""Central settings: paths, app name, version. Change APP_NAME here to rename the product."""
import os

APP_NAME = "AstroCare"
APP_SUBTITLE = "AI Health Sentinel"
PROJECT_NAME = "HomeBound"  # team / repository name used in the NASA Space Apps submission
VERSION = "1.0.0"

BACKEND_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ROOT_DIR = os.path.dirname(BACKEND_DIR)
DATA_DIR = os.path.join(BACKEND_DIR, "data")
FRONTEND_DIR = os.path.join(ROOT_DIR, "frontend")
RUNTIME_DIR = os.environ.get("ASTROCARE_RUNTIME_DIR") or os.path.join(DATA_DIR, "runtime")  # self-reports, bone scans, reaction tests (written at run time)

HOST = os.environ.get("ASTROCARE_HOST", "127.0.0.1")
PORT = int(os.environ.get("ASTROCARE_PORT", "8000"))


def data_path(*parts):
    return os.path.join(DATA_DIR, *parts)
