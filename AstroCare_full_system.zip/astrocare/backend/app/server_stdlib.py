"""Zero-install server (Python standard library only). Same API and frontend as the FastAPI server."""
import json
import mimetypes
import os
import traceback
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

from . import config
from .routes import ApiError, dispatch

mimetypes.add_type("application/javascript", ".js")
mimetypes.add_type("text/css", ".css")


class Handler(BaseHTTPRequestHandler):
    server_version = "AstroCare/1.0"

    def log_message(self, fmt, *args):
        if os.environ.get("ASTROCARE_QUIET") != "1":
            super().log_message(fmt, *args)

    def _send(self, status, payload, ctype="application/json; charset=utf-8"):
        data = payload if isinstance(payload, bytes) else json.dumps(payload, default=str).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def _api(self, method):
        u = urlparse(self.path)
        q = {k: v[-1] for k, v in parse_qs(u.query).items()}
        body = None
        if method == "POST":
            n = int(self.headers.get("Content-Length") or 0)
            raw = self.rfile.read(n) if n else b""
            try:
                body = json.loads(raw.decode("utf-8")) if raw else {}
            except json.JSONDecodeError:
                return self._send(400, {"detail": "body must be JSON"})
        try:
            self._send(200, dispatch(method, u.path, q, body))
        except ApiError as e:
            self._send(e.status, {"detail": e.message})
        except Exception as e:  # noqa: BLE001
            traceback.print_exc()
            self._send(500, {"detail": f"server error: {e}"})

    def _static(self):
        u = urlparse(self.path)
        rel = u.path.lstrip("/") or "index.html"
        full = os.path.normpath(os.path.join(config.FRONTEND_DIR, rel))
        if not full.startswith(os.path.normpath(config.FRONTEND_DIR)) or not os.path.isfile(full):
            full = os.path.join(config.FRONTEND_DIR, "index.html")
        ctype = mimetypes.guess_type(full)[0] or "application/octet-stream"
        with open(full, "rb") as f:
            self._send(200, f.read(), ctype)

    def do_GET(self):
        if self.path.startswith("/api/"):
            return self._api("GET")
        self._static()

    def do_POST(self):
        if self.path.startswith("/api/"):
            return self._api("POST")
        self._send(405, {"detail": "method not allowed"})


def serve(host=config.HOST, port=config.PORT):
    httpd = ThreadingHTTPServer((host, port), Handler)
    print(f"{config.APP_NAME} running (standard-library server) at http://{host}:{port}")
    print("Install FastAPI (pip install -r requirements.txt) to also get interactive API docs at /docs.")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
