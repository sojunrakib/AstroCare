"""Action / Recommendation engine: transparent, rule-based, non-diagnostic.

Rules run in priority order: 1 = data quality / notices, 2 = status rules, 3 = routine.
Every recommendation carries the rule ID that produced it and the reason. Texts come from rules_v1.json.
The engine never names a condition and never suggests medication; "medical review" always means the flight surgeon.
"""
from .. import store
from ..modules import body_mind, context as ctx, inspiration4 as i4, m1_storm, m2_dose, m9_vitals


def _rule(rid):
    return next(r for r in store.rules()["action_rules"] if r["id"] == rid)


def _add(out, rid, why, module, evidence_id=None, status_type="DERIVED", text=None, priority=None):
    r = _rule(rid)
    out.append({"priority": priority or r["priority"], "rule_id": rid, "rule_name": r["name"], "text": text or r["text"],
                "why": why, "module": module, "evidence_id": evidence_id, "status_type": status_type})


def mission_actions(persona_id, day, location="habitat"):
    day = ctx.clamp_day(day)
    out = []
    v = m9_vitals.daily(persona_id, day)
    for q in v["quality"]:
        _add(out, "R03", f"{q['measure']}: {q['why']} (rule {q['rule_id']}).", "M9", status_type="TELEMETRY")
    recent = [f for f in v["flags"] if day - 1 <= f["mission_day"] <= day]
    for f in recent:
        if f["alert_enabled"]:
            _add(out, "R09", f"{f['measure']} {f['value']} on day {f['mission_day']}: {f['why']} (rule {f['rule_id']}).", "M9",
                 f["evidence_id"], "TELEMETRY")
        else:
            out.append({"priority": 3, "rule_id": f["rule_id"], "rule_name": "Shown without alert", "text": f["action"],
                        "why": f"{f['measure']} {f['value']} on day {f['mission_day']}: {f['why']}.", "module": "M9",
                        "evidence_id": f["evidence_id"], "status_type": "TELEMETRY"})
    for mf in v["multi_flags"]:
        if day - 1 <= mf["mission_day"] <= day:
            _add(out, "R08", f"{' + '.join(mf['measures'])} flagged together on day {mf['mission_day']} (rule {mf['rule_id']}).", "M9",
                 mf["evidence_id"], "TELEMETRY")
    f1 = m1_storm.mission_forecast(day)
    dose = m2_dose.estimate(persona_id, day, location)
    st = store.mission()["storm"]
    if f1["alert"] or (dose["flux_pfu_noon"] or 0) >= 10:
        why = []
        if f1["alert"]:
            why.append(f"M1 SEP probability {f1['sep_probability_48h']:.2f} >= {f1['threshold']} ({f1['flare_class']} flare)")
        if (dose["flux_pfu_noon"] or 0) >= 10:
            why.append(f"proton flux {dose['flux_pfu_noon']:.0f} pfu >= 10 pfu; dose rate {dose['dose_rate_usv_h']} µSv/h (M2 estimate)")
        _add(out, "R10", "; ".join(why) + ".", "M1/M2", "EV-SEP-DONKI", "ESTIMATED")
    if st["onset_day"] + 1 <= day <= st["onset_day"] + 2:
        persona = m2_dose.persona_by_id(persona_id)
        out.append({"priority": 3, "rule_id": "R02", "rule_name": "Validated blood window", "module": "M3", "evidence_id": "EV-OSD-1012",
                    "status_type": "DERIVED", "text": "A blood draw 20-28 h after the storm peak is inside the M3-24h validated window.",
                    "why": f"Storm onset day {st['onset_day']}; {'EVA' if persona.get('eva_during_storm') else 'habitat'} during the storm. M3 resolves doses of 0.1 Gy and above only."})
    b = body_mind.behaviour(persona_id)
    if b["recommendation"]:
        _add(out, "R50", "Last 7 entries vs own first 7: " + ", ".join(f"{k} {v:+.1f}" for k, v in b["delta_vs_baseline"].items()) + f"; worse: {', '.join(b['worse_items'])}.", "Behaviour",
             None, "SELF_REPORTED")
    bone = body_mind.bone(persona_id, day)
    if bone["rule_id"] == "R60":
        _add(out, "R60", f"{bone['microgravity_days']} days of microgravity; no bone density scan entered.", "Bone", "EV-BONE", "CONTEXT")
    if not any(a["priority"] == 2 for a in out):
        _add(out, "R99", "No status rule is active for this persona today.", "All")
    out.sort(key=lambda a: (a["priority"], a["rule_id"]))
    return out


def i4_actions(crew_id):
    out = []
    m4 = i4.microbiome(crew_id)["card"]
    _add(out, "R30", f"M4 Tier A: {m4['status']} (in flight {m4['value']}, {m4['trend']}); confidence {m4['confidence']}.", "M4", "EV-OSD-572", "DERIVED")
    m7 = i4.immune(crew_id)
    above = [x for x in m7["rows"] if x["above_chance"]]
    if above:
        why = "; ".join(f"{x['label']} {x['timepoint']}: {x['n_flagged']} of {x['n_tested']} analytes outside own pre-flight variation (expected {x['expected']} by chance, p {'< 0.0001' if x['p_value'] < 0.0001 else '= ' + str(x['p_value'])})" for x in above)
        _add(out, "R20", why + " (rule M7-DEV-v1).", "M7", "EV-I4-IMMUNE")
    m6 = i4.recovery(crew_id)["m6"]
    t = m6["totals"]
    if t["flagged_r1"]:
        _add(out, "R70", f"{t['flagged_r1']} analytes changed at R+1; {t['back_r82']} of {t['followed_r82']} back within own variation by R+82 (rule M6-TRAJ-v2).", "M6", "EV-I4-IMMUNE")
    else:
        _add(out, "R70", "No analyte changed beyond own variation at R+1 (rule M6-TRAJ-v2).", "M6", "EV-I4-IMMUNE")
    _add(out, "R40", "Published context: telomeres lengthened in flight in all 4 crew and shortened after return in 3 of 4; no per-crew values.", "M8", "EV-I4-TELOMERE", "CONTEXT")
    if not any(a["priority"] == 2 for a in out):
        _add(out, "R99", "No status rule is active for this crew member.", "All")
    out.sort(key=lambda a: (a["priority"], a["rule_id"]))
    return out


def actions(subject_id, day=None, location="habitat"):
    if subject_id in i4.CREW:
        return {"subject": subject_id, "kind": "inspiration4", "actions": i4_actions(subject_id), "is_simulated": False}
    if subject_id in m9_vitals.persona_ids():
        return {"subject": subject_id, "kind": "mission", "day": ctx.clamp_day(day),
                "actions": mission_actions(subject_id, day, location), "is_simulated": True}
    raise KeyError(subject_id)


def check_wording(text):
    """Returns banned words found in a text (used by tests)."""
    t = text.lower()
    return [w for w in store.rules()["banned_words"] if w in t]
