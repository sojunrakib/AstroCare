"""File loading with caching. Everything is read from backend/data; nothing needs the internet."""
import csv
import json
import os
import threading
from functools import lru_cache

from .config import data_path, RUNTIME_DIR

_lock = threading.Lock()


@lru_cache(maxsize=None)
def load_json(*parts):
    with open(data_path(*parts), encoding="utf-8") as f:
        return json.load(f)


def load_json_optional(*parts):
    """Returns None if the file is missing (used for module cards not yet delivered)."""
    if not os.path.exists(data_path(*parts)):
        return None
    return load_json(*parts)


@lru_cache(maxsize=None)
def load_csv(*parts):
    with open(data_path(*parts), encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f))


def exists(*parts):
    return os.path.exists(data_path(*parts))


def rules():
    return load_json("reference", "rules_v1.json")


def mission():
    return load_json("reference", "mission.json")


def evidence():
    return load_json("reference", "evidence_registry.json")


# ---- runtime storage (self-reports, bone scans, reaction tests) ----
def _runtime_file(name):
    os.makedirs(RUNTIME_DIR, exist_ok=True)
    return os.path.join(RUNTIME_DIR, name)


def runtime_read(name, default):
    p = _runtime_file(name)
    with _lock:
        if not os.path.exists(p):
            return default
        with open(p, encoding="utf-8") as f:
            return json.load(f)


def runtime_write(name, obj):
    p = _runtime_file(name)
    with _lock:
        tmp = p + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(obj, f, indent=2)
        os.replace(tmp, p)
