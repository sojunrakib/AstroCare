"""AstroCare test suite. Run from the project root:  python -m unittest discover -s backend/tests -v

Checks the validation criteria of the implementation plan (section 4.5):
  * M1 reproduces the notebook's test-set probabilities and storm counts exactly
  * M3 port matches the team's original numpy predictor and refuses outside validated windows
  * M9 rule reproduces exactly the 14 flags of the M9 notebook (and is deterministic)
  * action engine: every recommendation has a rule ID and reason, and no diagnostic / drug wording
  * provenance: every record has a known status type; simulated values always carry is_simulated
"""
import json
import os
import sys
import tempfile
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
os.environ["ASTROCARE_RUNTIME_DIR"] = tempfile.mkdtemp(prefix="astrocare_test_")

from app import store  # noqa: E402
from app.config import data_path  # noqa: E402
from app.modules import i4_lab, m1_storm, m3_blood, m9_vitals, inspiration4 as i4  # noqa: E402
from app.provenance import STATUS_TYPES  # noqa: E402
from app.routes import ApiError, ROUTES, dispatch  # noqa: E402
from app.rules import action_engine  # noqa: E402


class TestM1(unittest.TestCase):
    def test_reproduces_notebook_probabilities(self):
        feats = {r["event_key"]: float(r["flare_log10_peak_flux"]) for r in store.load_csv("m1", "m1_test.csv")}
        worst = 0
        for r in store.load_csv("m1", "m1_test_predictions.csv"):
            p = m1_storm.probability(feats[r["event_key"]])
            worst = max(worst, abs(round(p, 3) - float(r["sep_probability_48h"])))
        self.assertLessEqual(worst, 0.0011)

    def test_storm_counts_match_model_info(self):
        st = m1_storm.storms()
        info = store.load_json("m1", "m1_model_info.json")["test_results"]
        self.assertEqual(sum(s["caught"] for s in st), info["storms_caught"])
        self.assertEqual(sum(not s["caught"] for s in st), info["storms_missed"])

    def test_flare_class_parser(self):
        self.assertAlmostEqual(m1_storm.parse_flare_class("X1.0"), -4.0)
        self.assertTrue(m1_storm.predict(flare="X2")["alert"])
        self.assertFalse(m1_storm.predict(flare="C1.0")["alert"])
        with self.assertRaises(ValueError):
            m1_storm.parse_flare_class("Z9")


class TestM3(unittest.TestCase):
    def test_port_matches_original_numpy_predictor(self):
        try:
            import numpy  # noqa: F401
        except ImportError:
            self.skipTest("numpy not installed")
        import importlib.util
        spec = importlib.util.spec_from_file_location("orig", data_path("m3", "original_m3_predict.py"))
        orig = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(orig)
        orig.MODEL_DIR = data_path("m3", "models")
        for prof in ("habitat", "eva", "large", "reference"):
            for h in (1, 2, 6, 24):
                ex, base, _ = m3_blood.demo_sample(prof, h)
                mine = m3_blood.predict(ex, base, h)
                theirs = orig.predict_dose_24h(ex, base, h) if h == 24 else orig.predict_dose_class_early(ex, base, h)
                if h == 24:
                    self.assertEqual(mine["dose_gy_xray_equivalent"], theirs["dose_gy_xray_equivalent"])
                else:
                    self.assertEqual(mine["dose_class_gy"], theirs["dose_class_gy"])
                    self.assertEqual(mine["probabilities"], theirs["probabilities"])

    def test_window_rule(self):
        ex, base, _ = m3_blood.demo_sample("large", 24)
        for h in (0, 3, 4.6, 12, 19.9, 28.1, 48):
            self.assertEqual(m3_blood.predict(ex, base, h)["status"], "OUTSIDE_VALIDATED_WINDOW", h)
        for h in (0.6, 1, 2, 6.4, 20, 24, 28):
            self.assertIsNotNone(m3_blood.window_for(h), h)
        self.assertEqual(m3_blood.predict(ex, {}, 24)["status"], "NO_BASELINE")
        partial = dict(list(ex.items())[:3])
        self.assertEqual(m3_blood.predict(partial, base, 24)["status"], "MISSING_GENES")

    def test_one_hour_model_is_exploratory(self):
        r = m3_blood.predict_demo("large", 1)
        self.assertIn("exploratory", r["reliability"])


class TestM9(unittest.TestCase):
    def test_reproduces_notebook_flags_exactly(self):
        cards = store.load_json("m9", "m9_cards.json")
        want = {(c["crew_id"], c["measure"], c["mission_day"], c["alert_enabled"]) for c in cards}
        got = {(f["crew_id"], f["measure"], f["mission_day"], f["alert_enabled"])
               for p in m9_vitals.persona_ids() for f in m9_vitals.flags(p)}
        self.assertEqual(got, want)

    def test_deterministic(self):
        a = [m9_vitals.flags(p) for p in m9_vitals.persona_ids()]
        m9_vitals.evaluated.cache_clear()
        b = [m9_vitals.flags(p) for p in m9_vitals.persona_ids()]
        self.assertEqual(a, b)

    def test_spo2_never_alerts(self):
        for p in m9_vitals.persona_ids():
            for f in m9_vitals.flags(p):
                if f["measure_key"] == "spo2":
                    self.assertFalse(f["alert_enabled"])

    def test_insufficient_baseline_no_flag(self):
        ev = m9_vitals.evaluated("SIM-A")
        for k in ev:
            for d, r in ev[k].items():
                if r["n"] < 21:
                    self.assertFalse(r["flag"])


class TestInspiration4Rules(unittest.TestCase):
    def test_data_files_unchanged(self):
        import hashlib
        for line in open(data_path("i4", "SHA256SUMS.txt"), encoding="utf-8"):
            digest, name = line.split()
            with open(data_path("i4", name), "rb") as f:
                self.assertEqual(hashlib.sha256(f.read()).hexdigest(), digest, name)

    def test_all_crew_and_timepoints_present(self):
        for p in i4_lab.PANELS:
            for a, d in i4_lab.raw(p).items():
                self.assertEqual(set(d["values"]), set(i4_lab.CREW), (p, a))
            first = next(iter(i4_lab.raw(p).values()))["values"]
            for c in i4_lab.CREW:
                self.assertTrue(set(i4_lab.POST) <= set(first[c]), (p, c))

    def test_threshold_calibrated_to_5_percent(self):
        for r in i4_lab.calibration_report():
            self.assertAlmostEqual(r["preflight_false_flag_rate"], 0.05, delta=0.01, msg=r["panel"])
            self.assertGreater(r["threshold_k"], 1.5)

    def test_agrees_with_notebook_eve_r82(self):
        """Team notebook: only C001 and C002, Eve panel, R+82 exceed chance (11/71 vs 3.6 expected)."""
        ev = i4_lab.evaluate("eve_immune")
        for c in ("C001", "C002"):
            s = ev["summary"][c]["R+82"]
            self.assertTrue(s["above_chance"], c)
            self.assertGreaterEqual(s["n_flagged"], 9)
            self.assertEqual(s["n_tested"], 71)
        for c in ("C003", "C004"):
            self.assertFalse(ev["summary"][c]["R+82"]["above_chance"], c)

    def test_no_race_coded_fields(self):
        self.assertFalse([a for a in i4_lab.raw("cmp") if "african" in a.lower()])

    def test_nulisa_zero_is_missing(self):
        for d in i4_lab.raw("alamar").values():
            for tv in d["values"].values():
                self.assertNotIn(0.0, [v for v in tv.values() if v is not None])

    def test_m6_counts_consistent(self):
        m = i4_lab.m6()
        t = m["totals"]
        self.assertGreater(t["flagged_r1"], 0)
        self.assertLessEqual(t["back_r82"], t["followed_r82"])
        self.assertEqual(sum(i4_lab.m6(c)["totals"]["flagged_r1"] for c in i4_lab.CREW), t["flagged_r1"])

    def test_m8_is_context_only(self):
        r = i4.telomere("C001")
        self.assertEqual(r["status_type"], "CONTEXT")
        self.assertIn("Garcia-Medina", r["citation"])


class TestActionsAndProvenance(unittest.TestCase):
    subjects = ["SIM-A", "SIM-B", "SIM-C", "SIM-D", "C001", "C002", "C003", "C004"]

    def test_every_action_has_rule_reason_and_safe_wording(self):
        for s in self.subjects:
            for day in (-30, -21, 5, 20, 21, 25, 32, 33, 34, 45):
                for a in action_engine.actions(s, day)["actions"]:
                    self.assertTrue(a["rule_id"])
                    self.assertTrue(a["why"])
                    self.assertEqual(action_engine.check_wording(a["text"]), [], a["text"])
                    self.assertEqual(action_engine.check_wording(a["why"]), [], a["why"])

    def test_actions_sorted_by_priority(self):
        a = action_engine.actions("SIM-B", 25)["actions"]
        self.assertEqual([x["priority"] for x in a], sorted(x["priority"] for x in a))
        self.assertIn("R09", [x["rule_id"] for x in a])

    def test_provenance_records_complete(self):
        for s in self.subjects:
            res = dispatch("GET", f"/api/indicators/{s}", {"day": "34"}, None)
            self.assertGreater(res["n"], 0)
            for r in res["records"]:
                self.assertIn(r["status_type"], STATUS_TYPES)
                if r["status_type"] == "TELEMETRY":
                    self.assertTrue(r["is_simulated"])
            if s.startswith("SIM"):
                self.assertTrue(all(r["is_simulated"] for r in res["records"]
                                    if r["status_type"] in ("TELEMETRY",)))

    def test_i4_data_not_marked_simulated(self):
        for c in i4.CREW:
            self.assertFalse(i4.microbiome(c)["card"]["is_simulated"])


class TestApi(unittest.TestCase):
    def test_all_get_routes_respond(self):
        fill = {"crew_id": "SIM-A", "subject_id": "SIM-A", "evidence_id": "EV-OSD-410"}
        i4_paths = ("/api/microbiome", "/api/immune", "/api/telomere", "/api/recovery")
        for m, path, _ in ROUTES:
            if m != "GET":
                continue
            p = path
            for k, v in fill.items():
                if path.startswith(i4_paths) and k == "crew_id":
                    v = "C001"
                p = p.replace("{" + k + "}", v)
            self.assertIsNotNone(dispatch("GET", p, {"day": "21"}, None), p)

    def test_errors(self):
        with self.assertRaises(ApiError):
            dispatch("GET", "/api/vitals/NOPE", {}, None)
        with self.assertRaises(ApiError):
            dispatch("GET", "/api/microbiome/SIM-A", {}, None)
        with self.assertRaises(ApiError):
            dispatch("POST", "/api/blood/predict", {}, {"hours_since_exposure": "x"})

    def test_selfreport_roundtrip(self):
        r = dispatch("POST", "/api/selfreport/SIM-B", {}, {"sleep": 7, "stress": 2, "mood": 4, "fatigue": 2})
        self.assertEqual(r["history"][-1]["status_type"], "SELF_REPORTED")
        with self.assertRaises(ApiError):
            dispatch("POST", "/api/selfreport/SIM-B", {}, {"sleep": 70, "stress": 2, "mood": 4, "fatigue": 2})

    def test_bone_roundtrip(self):
        r = dispatch("POST", "/api/bone/SIM-C", {}, {"site": "Total hip", "preflight": 1.0, "latest": 0.97})
        self.assertAlmostEqual(r["pct_change"], -3.0)
        r = dispatch("POST", "/api/bone/SIM-C", {}, {"clear": True})
        self.assertIsNone(r["scan"])


if __name__ == "__main__":
    unittest.main()
