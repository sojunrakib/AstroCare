"""HomeBound M3 - blood radiation response prediction (no sklearn needed, only numpy)."""
import json, os
import numpy as np

MODEL_DIR = os.path.join(os.path.dirname(__file__), 'models', 'm3')

def _load(name):
    with open(os.path.join(MODEL_DIR, name)) as f:
        return json.load(f)

def _change_vs_baseline(model, exposed_sample, baseline_sample):
    missing = [g for g in model['features'] if g != 'time_after_exposure_hours'
               and (g not in exposed_sample or g not in baseline_sample)]
    if missing:
        return None, missing
    x = [exposed_sample[g] - baseline_sample[g] for g in model['features'] if g != 'time_after_exposure_hours']
    return np.array(x, dtype=float), []

def predict_dose_24h(exposed_sample, baseline_sample, hours_since_exposure):
    """exposed_sample / baseline_sample: {probe_id: log2 expression}. Returns an X-ray-equivalent dose in Gy."""
    m = _load('m3_24h_model_v2.json')
    lo, hi = m['valid_time_window_hours']
    if not (lo <= hours_since_exposure <= hi):
        return {'status': 'OUTSIDE_VALIDATED_WINDOW', 'dose_gy_xray_equivalent': None, 'model_id': m['model_id']}
    x, missing = _change_vs_baseline(m, exposed_sample, baseline_sample)
    if x is None:
        return {'status': 'MISSING_GENES', 'missing': missing, 'dose_gy_xray_equivalent': None, 'model_id': m['model_id']}
    z = (x - np.array(m['scaler_mean'])) / np.array(m['scaler_scale'])
    dose = max(0.0, 2 ** (m['intercept'] + float(np.dot(m['coef'], z))) - 0.1)
    vlo, vhi = m['valid_dose_range_gy']
    return {'status': 'ML_PREDICTED', 'dose_gy_xray_equivalent': round(dose, 2),
            'within_validated_range': vlo <= dose <= vhi, 'valid_dose_range_gy': [vlo, vhi],
            'model_id': m['model_id'], 'evidence': m['study_id'],
            'caveat': 'X-ray-equivalent; neutron exposure is over-read about %.1fx' % m['neutron_slope']}

def predict_dose_class_early(exposed_sample, baseline_sample, hours_since_exposure):
    """Uses the 1 h, 2 h or 6 h model (within +/- 0.5 h). Returns a dose class and class probabilities."""
    tp = {1: '1h', 2: '2h', 6: '6h'}.get(int(round(hours_since_exposure)))
    if tp is None or abs(hours_since_exposure - round(hours_since_exposure)) > 0.5:
        return {'status': 'OUTSIDE_VALIDATED_WINDOW', 'dose_class_gy': None}
    m = _load(f'm3_early_{tp}_model_v2.json')
    x, missing = _change_vs_baseline(m, exposed_sample, baseline_sample)
    if x is None:
        return {'status': 'MISSING_GENES', 'missing': missing, 'dose_class_gy': None, 'model_id': m['model_id']}
    z = (x - np.array(m['scaler_mean'])) / np.array(m['scaler_scale'])
    logits = np.array(m['intercept']) + np.array(m['coef']) @ z
    p = np.exp(logits - logits.max()); p = p / p.sum()
    k = int(np.argmax(p))
    return {'status': 'ML_PREDICTED', 'dose_class_gy': m['classes_dose_gy'][k],
            'probabilities': {str(c): round(float(q), 3) for c, q in zip(m['classes_dose_gy'], p)},
            'model_id': m['model_id'], 'evidence': m['study_id'],
            'reliability': 'exploratory (not reproduced in OSD-71)' if tp == '1h' else 'study-specific'}
