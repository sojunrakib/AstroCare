# Card drop-in folder (M6, M7, M8)

Put the card files from your Colab notebooks here:

- `m6_cards.json` (Recovery)
- `m7_cards.json` (Immune)
- `m8_cards.json` (Telomere context)

Each file is a JSON list of card objects, like `m4_cards.json`. These fields are used if they exist:
`crew_id` (C001–C004, or "ALL"), `domain`, `value`, `status`, `trend`, `why`, `status_type`, `source`,
`rule_id`, `evidence_id`, `confidence`, `action`, `is_simulated`. Any other fields are shown as key/value rows.

Optional. M7 and M6 are already computed in the app from the lab panels in `data/i4/`, and M8 uses
`data/reference/m8_context.json`. If you add your notebook's card files here, they are shown next to the app's own result
so the two can be compared. Restart `python run.py` after adding a file.
