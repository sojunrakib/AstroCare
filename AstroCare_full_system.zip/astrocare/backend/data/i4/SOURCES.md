# Inspiration4 crew data (real, de-identified, NASA OSDR)

Public NASA OSDR "TRANSFORMED" files for the SpaceX Inspiration4 crew (C001–C004), timepoints L-92, L-44, L-3, R+1, R+45, R+82, R+194.
OSDR itself could not be reached from the build environment, so the files were taken from public GitHub mirrors and cross-checked.

| File | OSDR study | Mirror it came from |
|---|---|---|
| LSDS-8_Comprehensive_Metabolic_Panel_CMP_TRANSFORMED.csv | OSD-575 (serum CMP, 16 analytes) | github.com/JustAnn1234/AstroKestrel (data/Raw) |
| LSDS-8_Multiplex_serum_immune_EvePanel_TRANSFORMED.csv | OSD-575 (Eve 71-plex cytokines) | same |
| LSDS-8_Multiplex_serum.immune.AlamarPanel_TRANSFORMED.csv | OSD-575 (Alamar NULISA 203-target, NPQ) | same |
| LSDS-8_Multiplex_serum_cardiovascular_EvePanel_TRANSFORMED.csv | OSD-575 (Eve cardiovascular, 9 analytes) | same |
| LSDS-7_CBC_cleaned.csv | OSD-569 (CBC, 20 analytes; long format, cleaned) | github.com/TechJas/git-anomaly_detection_pipeline (data/processed/cbc_cleaned.csv) |

Checks done on 7 Nov 2026:
- The CMP file in the second mirror (cmp_cleaned.csv) matches the OSDR-named CMP file above in all 28 samples x 44 numeric columns.
- C003 R+1 potassium 3.0 mmol/L and glucose 103 mg/dL match an independent third project (KayKay9/aahms-test PR #17).
- Analyte counts match the OSDR descriptions (203-target NULISA, 71-plex Eve).
- Known gaps: Alamar has 27 samples (C003 L-44 missing); urine panel (OSD-656) not included.
- The team's notebook reported 137 zero NULISA values; this serum file has 4. Please compare with the Drive copy.

To use your own OSDR downloads instead, replace these files with the same names and re-run the tests.
