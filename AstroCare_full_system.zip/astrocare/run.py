"""Start AstroCare:  python run.py   then open http://127.0.0.1:8000

Uses FastAPI + uvicorn if they are installed (pip install -r requirements.txt), otherwise a
built-in standard-library server with the same API, so it also runs with no installs at all.
Options:  python run.py --port 8080   |   python run.py --stdlib  (force the built-in server)
"""
import argparse
import os
import sys
import webbrowser

ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(ROOT, "backend"))

from app import config  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--host", default=config.HOST)
    ap.add_argument("--port", type=int, default=config.PORT)
    ap.add_argument("--stdlib", action="store_true", help="use the built-in server even if FastAPI is installed")
    ap.add_argument("--no-browser", action="store_true")
    a = ap.parse_args()
    url = f"http://{a.host}:{a.port}"
    if not a.no_browser:
        try:
            webbrowser.open(url)
        except Exception:  # noqa: BLE001
            pass
    if not a.stdlib:
        try:
            import uvicorn  # noqa: F401
            import fastapi  # noqa: F401
        except ImportError:
            print("FastAPI not installed -> using the built-in server.")
        else:
            print(f"{config.APP_NAME} running (FastAPI) at {url}   ·   API docs: {url}/docs")
            uvicorn.run("app.server_fastapi:app", host=a.host, port=a.port, app_dir=os.path.join(ROOT, "backend"))
            return
    from app.server_stdlib import serve
    serve(a.host, a.port)


if __name__ == "__main__":
    main()
